/*!
jQuery integration v3.0 / Intégration jQuery v3.0
Web Experience Toolkit (WET) / Boîte à outils de l'expérience Web (BOEW)
www.tbs.gc.ca/ws-nw/wet-boew/terms / www.sct.gc.ca/ws-nw/wet-boew/conditions
*/
(function($) {
  var pe;
  pe = {
    /*
    @property - pe.language
    @returns - page language, defaults to fra is not available
    */
    language: ($("html").attr("lang") ? ($("html").attr("lang").indexOf("en") === 0 ? "eng" : "fra") : $("meta[name='dc.language'], meta[name='dcterms.language']").attr("content")),
    /*
    @property - pe.ie
    @returns - ie major number if browser is IE, 0 if not
    */
    ie: $.browser.msie ? $.browser.version : 0,
    /*
    @property - pe.mobile
    @returns - true/false if mobile device
    */
    mobile: /iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()),
    /*
    @property : cssenabled
    @returns : true/false
    */
    cssenabled: function() {
      return !$('link').get(0).disabled;
    },
    /*
    @property: pagecontainer
    @returns : the WET aware page query to append items to
    */
    pagecontainer: function() {
      return $('#cn-body-inner-3col,#cn-body-inner-2col,#cn-body-inner-1col').add('body').eq(0);
    },
    /*
    @property: liblocation
    @returns: location of JS framework for WET-BOEW
    */
    liblocation: $("script[id='progressive']").attr('src').replace(/pe-ap.(dev.)?js.*$/i, ""),
    /*
    @property : browser
    @returns : a generic plugin detection system to test for plugins
    @todo : utilize localstorage to reduce redundant checks
    */
    browser: {
      /*
      @property : browser.flash
      @returns : major version of flash or 0 if uninstalled
      @todo : the returns values of the plugin are comma delimited. This needs to be converted to float notation to stay consistant.
      */
      flash: (function() {
        var a;
        try {
          try {
            a = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
            try {
              a.AllowScriptAccess = "always";
            } catch (e) {
              return 6;
            }
          } catch (_error) {}
          return new ActiveXObject("ShockwaveFlash.ShockwaveFlash").GetVariable("$version").replace(/\D+/g, ",").match(/^,?(.+),?$/)[1];
        } catch (e) {
          try {
            if (navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin) {
              return (navigator.plugins["Shockwave Flash 2.0"] || navigator.plugins["Shockwave Flash"]).description.replace(/\D+/g, ",").match(/^,?(.+),?$/)[1];
            }
          } catch (_error) {}
        }
        return 0;
      })(),
      /*
      @property : browser.silverlight
      @returns : major version of silverlight or 0 if uninstalled
      */
      silverlight: (function() {
        var a, b, c;
        a = 0;
        try {
          try {
            b = new ActiveXObject("AgControl.AgControl");
            if (b.IsVersionSupported("5.0")) {
              a = 5;
            } else if (b.IsVersionSupported("4.0")) {
              a = 4;
            } else if (b.IsVersionSupported("3.0")) {
              a = 3;
            } else if (b.IsVersionSupported("2.0")) {
              a = 2;
            } else {
              a = 1;
            }
            b = null;
          } catch (e) {
            c = navigator.plugins["Silverlight Plug-In"];
            if (c) {
              if (c.description === "1.0.30226.2") {
                a = 2;
              } else {
                a = parseInt(c.description[0]);
              }
            } else {
              a = 0;
            }
          }
        } catch (e) {
          a = 0;
        }
        return a;
      })()
    },
    /*
    @property - pe.url
    @returns - url.properties helper function for developers
    */
    url: function(uri) {
      var a;
      a = document.createElement('a');
      a.href = uri;
      return {
        source: uri,
        protocol: a.protocol.replace(':', ''),
        host: a.hostname,
        port: a.port,
        query: a.search,
        params: (function() {
          var key, ret, s, seg, _i, _len;
          ret = {};
          seg = a.search.replace(/^\?/, '').split('&');
          for (_i = 0, _len = seg.length; _i < _len; _i++) {
            key = seg[_i];
            if (!key) continue;
            s = key.split('=');
            ret[s[0]] = s[1];
          }
          return ret;
        })(),
        file: a.pathname.match(/\/([^\/?#]+)$/i) ? a.pathname.match(/\/([^\/?#]+)$/i)[1] : '',
        hash: a.hash.replace('#', ''),
        path: a.pathname.replace(/^([^\/])/, '/$1'),
        relative: a.href.match(/tps?:\/\/[^\/]+(.+)/) ? a.href.match(/tps?:\/\/[^\/]+(.+)/)[1] : '',
        segments: a.pathname.replace(/^\//, '').split('/')
      };
    },
    /*
    @property: defaultfontsize
    @returns : default numeric only version of the font size
    */
    defaultfontsize: function() {
      var elm, fontsize;
      elm = $("<div>M</div>").css({
        "font-size": "1em",
        position: "absolute",
        "line-height": "1",
        padding: "0",
        margin: "0",
        visibility: "hidden"
      });
      $("body").append(elm);
      fontsize = elm.height();
      elm.remove();
      return fontsize;
    },
    /*
    @returns: true/false of object restriction and defaults to true if not restriction passed
    */
    should: function(plugin) {
      if (plugin.hasOwnProperty('restrict')) {
        if (typeof plugin.restrict === 'function') {
          return plugin.restrict();
        } else {
          return plugin.restrict;
        }
      } else {
        return true;
      }
    },
    /*
    @function: pe.limit
    @returns: returns a class-based set limit count on plugins (0 if none found which means the plugin default )
    */
    limit: function(elm) {
      var count;
      count = $(elm).attr("class").match(/\blimit-\d+/);
      if (!count) return 0;
      return count[0].replace(/limit-/i, "");
    },
    /*
    @function: pe.focus -  a generic function to focus elements in the DOM in a screen reader compatible way / selector or object
    @returns: the jQuery reference for the element
    */
    focus: function(elm) {
      setTimeout(function() {
        return elm.focus();
      }, 0);
      return elm;
    },
    /*
    @function exec pe objects in development mode
    */
    exec: function(plugin) {
      if (plugin.scope === "global") {
        plugin.exec();
      } else {
        $(".wet-boew-" + plugin.id).each(function() {
          plugin.exec(this);
          return;
        });
      }
      return plugin;
    },
    /*
    @function patch for overriding third-party plugins
    */
    patch: function(plugin) {
      if (plugin.hasOwnProperty("patch")) {
        plugin.patch();
        delete plugin.patch;
      }
      return plugin;
    },
    /*
    @function to bind a function to a resize event
    */
    resize: function(fn) {
      ResizeEvents.eventElement.bind("x-text-resize x-zoom-resize x-window-resize", function() {
        return fn();
      });
      return;
    },
    /*
    @function to mobilize the page
    */
    mobilize: function() {
      $(".wet-boew-mobile").each(function() {
        var node;
        node = $(this);
        if (node.hasClass('page')) node.attr('data-role', 'page');
        if (node.hasClass('header')) node.attr('data-role', 'header');
        if (node.hasClass('content')) node.attr('data-role', 'content');
        return;
      });
      return;
    },
    /*
    @property : widget
    @returns : a set of widget specific helper functions
    */
    widget: {
      /*
      @property : widget.sanitize
      @returns : true  - removes all non-widget based classes from the element to reduce potential style clashes
      @todo : this should be matured as a function to allow the for dynamic class switching as well to better adhere with UXWG design patterns
      */
      sanitize: function(elm) {
        return elm.find("[class]").attr("class", function(i, c) {
          var ac, n;
          ac = c.split(" ");
          n = [];
          i = 0;
          while (i < ac.length) {
            if (ac[i].toLowerCase().indexOf("widget-") > -1) n.push(ac[i]);
            i++;
          }
          return n.join(" ");
        });
      }
    },
    /*
    @property : string handler
    @returns : a set of string specific helper functions
    */
    string: {
      /*
      @function : pe.string.ify.clean(text)
      @returns : modified text with htmlified text into a HTML links ( mailto, anchors, etc )
      @credits : Dustin Diaz | http://www.dustindiaz.com/basement/ify.html
      @license : public BSD
      */
      ify: (function() {
        return {
          "link": function(t) {
            return t.replace(/[a-z]+:\/\/[a-z0-9-_]+\.[a-z0-9-_@:~%&\?\+#\/.=]+[^:\.,\)\s*$]/ig, function(m) {
              var _ref;
              return '<a href="' + m + '">' + ((_ref = m.length > 25) != null ? _ref : m.substr(0, 24) + {
                '...': m
              }) + '</a>';
            });
          },
          "at": function(t) {
            return t.replace(/(^|[^\w]+)\@([a-zA-Z0-9_]{1,15}(\/[a-zA-Z0-9-_]+)*)/g, function(m, m1, m2) {
              return m1 + '@<a href="http://twitter.com/' + m2 + '">' + m2 + '</a>';
            });
          },
          "hash": function(t) {
            return t.replace(/(^|[^&\w'"]+)\#([a-zA-Z0-9_]+)/g, function(m, m1, m2) {
              return m1 + '#<a href="http://search.twitter.com/search?q=%23' + m2 + '">' + m2 + '</a>';
            });
          },
          "clean": function(tweet) {
            return this.hash(this.at(this.link(tweet)));
          }
        };
      })(),
      /*
      @function : pe.string.pad(i, l, s)
      @params : i - original string, l - leading padding required, s - padding character
      @returns : pads numeric string with appropiate leading characters
      */
      pad: function(number, length) {
        var str;
        str = "" + number;
        while (str.length < length) {
          str = "0" + str;
        }
        return str;
      }
    },
    /*
    @property : date
    @function : a suite of date related functions for easier parsing of dates
    */
    date: {
      /*
      Converts the date in d to a date-object. The input can be:
      a date object: returned without modification
      an array      : Interpreted as [year,month,day]. NOTE: month is 0-11.
      a number     : Interpreted as number of milliseconds
                   since 1 Jan 1970 (a timestamp)
      a string     : Any format supported by the javascript engine, like
                   "YYYY/MM/DD", "MM/DD/YYYY", "Jan 31 2009" etc.
      an object     : Interpreted as an object with year, month and date
                  attributes.  **NOTE** month is 0-11.
      */
      convert: function(d) {
        if (d.constructor === Date) {
          return d;
        } else {
          if (d.constructor === Array) {
            return new Date(d[0], d[1], d[2]);
          } else {
            if (d.constructor === Number) {
              return new Date(d);
            } else {
              if (d.constructor === String) {
                return new Date(d);
              } else {
                if (typeof d === "object") {
                  return new Date(d.year, d.month, d.date);
                } else {
                  return NaN;
                }
              }
            }
          }
        }
      },
      /*
      Compare two dates (could be of any type supported by the convert function above) and returns:
       -1 : if a < b
       0 : if a = b
       1 : if a > b
       NaN : if a or b is an illegal date
       NOTE: The code inside isFinite does an assignment (=).
      */
      compare: function(a, b) {
        if (isFinite(a = this.convert(a).valueOf()) && isFinite(b = this.convert(b).valueOf())) {
          return (a > b) - (a < b);
        } else {
          return NaN;
        }
      },
      /*
      Checks if date in d is between dates in start and end.
       Returns a boolean or NaN:
        true  : if d is between start and end (inclusive)
        false : if d is before start or after end
        NaN   : if one or more of the dates is illegal.
      NOTE: The code inside isFinite does an assignment (=).
      */
      in_range: function(d, start, end) {
        if (isFinite(d = this.convert(d).valueOf()) && isFinite(start = this.convert(start).valueOf()) && isFinite(end = this.convert(end).valueOf())) {
          return start <= d && d <= end;
        } else {
          return NaN;
        }
      },
      to_iso_format: function(d, timepresent) {
        var date;
        date = this.convert(d);
        if (timepresent) {
          return date.getFullYear() + "-" + pe.string.pad(date.getMonth() + 1, 2, "0") + "-" + pe.string.pad(date.getDate() + 1, 2, "0") + " " + pe.string.pad(date.getHours(), 2, "0") + ":" + pe.string.pad(date.getMinutes(), 2, "0");
        } else {
          return date.getFullYear() + "-" + pe.string.pad(date.getMonth() + 1, 2, "0") + "-" + pe.string.pad(date.getDate() + 1, 2, "0");
        }
      }
    },
    /*
    @property - pe.progress
    @returns - main swarming function for the pe 3.0
    */
    swarm: function(elm) {
      var context, dmode, fcn, node;
      context = elm || document;
      ResizeEvents.initialise();
      node = $(context);
      dmode = $("script[src*=\"pe.fn.\"]", node).filter(function() {
        return /\.js$/.test(this.src);
      }).map(function() {
        return this.src.replace(/^.*\.([^\.]+)\.js$/i, "$1");
      }).toArray();
      for (fcn in pe.fn) {
        if (pe.fn.hasOwnProperty(fcn) && pe.fn[fcn].scope === "global") {
          if (pe.should(pe.fn[fcn])) {
            if (!(jQuery.inArray(fcn, dmode) > -1)) pe.fn[fcn].exec();
          }
        }
      }
      $("[class^=\"wet-boew-\"]", node).each(function() {
        var _fcall, _node;
        _node = $(this);
        _fcall = _node.attr("class").replace(/^wet-boew-(\S*).*/i, "$1".toLowerCase());
        if (pe.fn.hasOwnProperty(_fcall) && pe.fn[_fcall].scope !== "global") {
          if (!(jQuery.inArray(_fcall, dmode) > -1)) {
            if (pe.fn[_fcall].stransition) {
              _node.css({
                opacity: "0"
              });
              pe.patch(pe.fn[_fcall]).exec(_node);
              _node.attr("class", _node.attr("class").replace(/\bwidget-style-/, "style-"));
              _node.animate({
                opacity: "1"
              });
            } else {
              pe.patch(pe.fn[_fcall]).exec(_node);
            }
          }
        }
        return;
      });
      return;
    },
    /*
        -------- Dictionary Section --------
    */
    dic: {
      get: function(key, state) {
        if (state != null) {
          return this.ind[key][state][pe.language];
        } else {
          return this.ind[key][pe.language];
        }
      },
      ind: {
        "%top-of-page": {
          eng: "Top of Page",
          fra: "Haut de la page"
        },
        "%archived-page": {
          eng: "This Web page has been archived on the Web.",
          fra: "Cette page Web a été archivée dans le Web."
        },
        "%sub-menu-help": {
          eng: "(open the submenu with the down arrow key)",
          fra: "(ouvrir le sous-menu avec la touche de la fleche descendante)"
        },
        "%tab-rotation": {
          "disable": {
            eng: "Stop tab rotation",
            fra: "Arrêter la rotation d'onglets"
          },
          "enable": {
            eng: "Start tab rotation",
            fra: "Lancer la rotation d'onglets"
          }
        },
        "%play": {
          eng: "Play",
          fra: "Jouer"
        },
        "%stop": {
          eng: "Pause",
          fra: "Pause"
        },
        "%close": {
          eng: "Close",
          fra: "Fermer"
        },
        "%rewind": {
          eng: "Rewind ",
          fra: "Reculer "
        },
        "%fast-forward": {
          eng: "Fast forward ",
          fra: "Avancer "
        },
        "%mute": {
          "enable": {
            eng: "Mute",
            fra: "Activer le mode muet"
          },
          "disable": {
            eng: "Unmute",
            fra: "Désactiver le mode muet"
          }
        },
        "%closed-caption": {
          "disable": {
            eng: "Hide Closed captioning",
            fra: "Masquer le sous-titrage"
          },
          "enable": {
            eng: "Show Closed captioning",
            fra: "Afficher le sous-titrage"
          }
        },
        "%audio-description": {
          "enable": {
            eng: "Enable Audio Description",
            fra: "Activer l'audiodescription"
          },
          "disable": {
            eng: "Disable Audio Description",
            fra: "Désactiver l'audiodescription"
          }
        },
        "%progress-bar": {
          eng: "use LEFT ARROW and RIGHT ARROW keys to advance and rewind the media's progress",
          fra: "utilisez les touches GAUCHE ou DROITE pour avancer ou reculer le progrès des médias"
        },
        "%no-video": {
          eng: "Your browser does not appear to have the capabilities to play this video, please download the video below",
          fra: "Votre navigateur ne semble pas avoir les capacité nécessaires pour lire cette vidéo, s'il vous plaît télécharger la vidéo ci-dessous"
        },
        "%position": {
          eng: "Current Position:",
          fra: "Position actuelle : "
        },
        "%duration": {
          eng: "Total Time: ",
          fra: "Temps total : "
        },
        "%buffered": {
          eng: "Buffered: ",
          fra: "Mis en mémoire-tampon : "
        }
      },
      /*
              @dictionary function : pe.dic.ago()
              @returns: a human readable time difference text
      */
      ago: function(time_value) {
        var delta, parsed_date, r, relative_to;
        parsed_date = pe.date.convert(time_value);
        relative_to = (arguments.length > 1 ? arguments[1] : new Date());
        delta = parseInt((relative_to.getTime() - parsed_date) / 1000);
        delta = delta + (relative_to.getTimezoneOffset() * 60);
        r = "";
        if (delta < 60) {
          r = (pe.language === "eng" ? "a minute ago" : "il ya une minute");
        } else if (delta < 120) {
          r = (pe.language === "eng" ? "couple of minutes ago" : "il ya quelques minutes");
        } else if (delta < (45 * 60)) {
          r = (pe.language === "eng" ? (parseInt(delta / 60)).toString() + " minutes ago" : "il ya " + (parseInt(delta / 60)).toString() + " minutes");
        } else if (delta < (90 * 60)) {
          r = (pe.language === "eng" ? "an hour ago" : "il ya une heure");
        } else if (delta < (24 * 60 * 60)) {
          r = (pe.language === "eng" ? "" + (parseInt(delta / 3600)).toString() + " hours ago" : "il ya " + (parseInt(delta / 3600)).toString() + " heures");
        } else if (delta < (48 * 60 * 60)) {
          r = (pe.language === "eng" ? " yesterday" : " hier");
        } else {
          r = (pe.language === "eng" ? (parseInt(delta / 86400)).toString() + " days ago" : "il ya " + (parseInt(delta / 86400)).toString() + " jours");
        }
        return r;
      }
    },
    /*
        -------- Function / Module Section --------
    */
    fn: {
      jsaware: {
        scope: 'global',
        exec: function(elm) {
          $('body').addClass('js');
          return;
        }
      },
      menubar: {
        scope: 'plugin',
        exec: function(elm) {
          /*
          @notes: the mega menu will use custom events to better manage its events.
          .: Events :.
          - close : this will close open menu
          - reset : this will clear all the menu's to closed state
          - open : this will open the child menu item
          */
          /* bind plugin scope element
          */
          var $bcLinks, $menu, $menuBoundary, $results, $scope, $vbrumbs, correctheight, gotosubmenu, hideallsubmenus, hidesubmenu, i, match, showsubmenu, type;
          $scope = $(elm);
          /* functions that would be nessecary for helpers
          */
          showsubmenu = function(toplink) {
            var _node, _sm;
            _node = $(toplink).closest("li");
            _node.addClass("mb-active");
            hideallsubmenus();
            _sm = _node.find(".mb-sm");
            _sm.attr("aria-expanded", "true").attr("aria-hidden", "false").toggleClass("mb-sm mb-sm-open");
            if ((Math.floor(_sm.offset().left + _sm.width()) - Math.floor($menuBoundary.offset().left + $menuBoundary.width())) >= -1) {
              _sm.css("right", "0px");
            }
            return;
          };
          /* action function to go to menu
          */
          gotosubmenu = function(toplink) {
            var _node, _submenu;
            showsubmenu(toplink);
            _node = $(toplink);
            _submenu = _node.closest("li").find(".mb-sm-open");
            pe.focus(_subMenu.find("a[href]:first"));
            return;
          };
          /* hidemenu worker function
          */
          hidesubmenu = function(toplink) {
            var _node, _sm;
            _node = $(toplink);
            _sm = _node.closest("li").removeClass("mb-active").find(".mb-sm-open");
            _sm.attr("aria-expanded", "false").attr("aria-hidden", "true").toggleClass("mb-sm mb-sm-open").css("right", "auto");
            return;
          };
          /* hide all the submenus
          */
          hideallsubmenus = function() {
            $menu.find(".mb-sm-open").each(function() {
              var _menu;
              _menu = $(this).closest("li");
              return hidesubmenu(_menu);
            });
            return;
          };
          /* function to correct the hieght of the menu on resize
          */
          correctheight = function() {
            var newouterheight, _lastmenuli;
            _lastmenuli = $menu.children("li:last");
            newouterheight = (_lastmenuli.offset().top + _lastmenuli.outerHeight()) - $scope.offset().top;
            return $scope.css("min-height", newouterheight);
          };
          /*
          /// End of Functions ///
          */
          /* define the menu type
          */
          type = {
            megamenu: $scope.hasClass("mb-megamenu"),
            hsubmenu: $scope.hasClass("mb-hsubmenu")
          };
          /* establish bounderies
          */
          $menuBoundary = $scope.children("div");
          $menu = $menuBoundary.children("ul");
          /* ARIA additions
          */
          $scope.attr("role", "application");
          $menu.attr("role", "menubar");
          /* if CSS is enabled we want to ensure a correct tabbing response
          */
          if (pe.cssenabled()) {
            $menu.find("a").attr("tabindex", "-1").attr("role", "menuitem");
            $menu.find("li:first a:first").removeAttr("tabindex");
          }
          pe.resize(correctheight);
          /* bind all custom events and triggers to menu
          */
          $scope.on("focusoutside mouseoutside", function() {
            return hideallsubmenus();
          });
          $scope.on("keydown focus section-next section-previous item-next item-previous close", "li", function(e) {
            var next, _elm, _id;
            _elm = $(e.target);
            _id = $.map(/\bknav-(\d+)-(\d+)/.exec(_elm.attr('class')), function(n, i) {
              return parseInt(n);
            });
            if (e.type === "keydown") {
              if (!(e.ctrlKey || e.altKey || e.metaKey)) {
                switch (e.keyCode) {
                  case 27:
                    _elm.trigger('close');
                    break;
                  case 37:
                    _elm.trigger('section-previous');
                    false;
                    break;
                  case 38:
                    _elm.trigger('item-previous');
                    false;
                    break;
                  case 39:
                    _elm.trigger('section-next');
                    false;
                    break;
                  case 40:
                    _elm.trigger('item-next');
                    false;
                }
              }
            }
            if (e.type === "close") {
              pe.focus($scope.find(".knav-" + _id[1] + "-0"));
              hideallsubmenus();
            }
            if (e.type === "section-previous") {
              next = $scope.find(".knav-" + (_id[1] - 1) + "-0");
              if (next.length > 0) {
                pe.focus(next);
              } else {
                pe.focus($scope.find('ul.mb-menu > li:last').find('a:eq(0)'));
              }
            }
            if (e.type === "section-next") {
              next = $scope.find(".knav-" + (_id[1] + 1) + "-0");
              if (next.length > 0) {
                pe.focus(next);
              } else {
                pe.focus($scope.find(".knav-0-0"));
              }
            }
            if (e.type === "item-next") {
              next = $scope.find(".knav-" + _id[1] + "-" + (_id[2] + 1));
              if (next.length > 0) {
                pe.focus(next);
              } else {
                pe.focus($scope.find(".knav-" + _id[1] + "-1"));
              }
            }
            if (e.type === "item-previous") {
              next = $scope.find(".knav-" + _id[1] + "-" + (_id[2] - 1));
              if (next.length > 0) {
                pe.focus(next);
              } else {
                pe.focus($scope.find(".knav-" + _id[1] + "-0"));
              }
            }
            if (e.type === "focusin" && _id[2] === 0) {
              hideallsubmenus();
              if (_elm.find('.expandicon').length > 0) showsubmenu(e.target);
              return;
            }
          });
          /* [Main] parse mega menu and establish all ARIA and Navigation classes
          */
          $scope.find('ul.mb-menu > li').find('a:eq(0)').each(function(index, value) {
            var $childmenu, $elm;
            $elm = $(this);
            $elm.addClass("knav-" + index + "-0");
            $childmenu = $elm.closest("li").find(".mb-sm");
            if ($childmenu.size() > 0) {
              $elm.attr("aria-haspopup", "true").addClass("mb-has-sm").wrapInner("<span class=\"expandicon\"><span class=\"sublink\"></span></span>");
              $childmenu.attr("role", "menu").attr("aria-expanded", "false").attr("aria-hidden", "true").find(":has(:header) ul").attr("role", "menu");
              $elm.append("<span class=\"cn-invisible\">" + (pe.dic.get('%sub-menu-help')) + "</span>");
              $elm.closest("li").hoverIntent(function() {
                return showsubmenu(this);
              }, function() {
                return hidesubmenu(this);
              });
              /* now recurse all focusable to be able to navigate
              */
              $childmenu.find("a").each(function(i, v) {
                $(this).addClass("knav-" + index + "-" + (i + 1));
                return;
              });
            }
            return;
          });
          /*
          Breadcrumb indexer
          */
          $vbrumbs = $("#cn-bc, #cn-bcrumb");
          if ($vbrumbs.size() > 0 && !$scope.hasClass("page-match-off")) {
            $results = $menu.children("li").find("a[href=\"" + window.location.pathname + "\"]");
            if ($results.size() > 0) {
              $results.eq(0).addClass("nav-current");
            } else {
              match = false;
              $bcLinks = $vbrumbs.find("li a:not([href^=\"#\"])");
              if ($bcLinks.size() > 0) {
                i = 0;
                while (i <= $bcLinks.size()) {
                  $results = $menu.children("li").find("a[href=\"" + $bcLinks.eq(i).attr("href") + "\"]");
                  if ($results.size() > 0) {
                    $results.eq(0).addClass("nav-current");
                    match = true;
                    break;
                  }
                  i++;
                }
              }
              if (!match) {
                $results = $menu.children("li").find("a:contains(\"" + $vbrumbs.find("li:last-child").text() + "\")");
                if ($results.size() > 0) $results.eq(0).addClass("nav-current");
              }
            }
          }
          correctheight();
          return $scope;
        }
      },
      charts: {
        scope: "plugin",
        id: "charts",
        exec: function(elm) {
          var $elm, cols, data, rows, _canvas, _table;
          $elm = $(elm);
          _canvas = $elm.find(".chart-canvas");
          if (!_canvas.hasClass("fixed-size")) {
            _canvas.height(Math.round(_canvas.width() / 1.61663));
          }
          _table = $(elm).find("table").eq(0);
          data = [];
          cols = rows = [];
          _table.find("thead td, thead th").each(function() {
            return cols.push($(this).text());
          });
          _table.find("tbody tr").each(function() {
            var _data;
            _data = {
              label: "",
              data: []
            };
            _data.label = $(this).find("th").eq(0).text();
            $(this).find("td").each(function(index) {
              return _data.data.push([cols[index + 1], $(this).text()]);
            });
            return data.push(_data);
          });
          $.plot(_canvas, data, {
            xaxis: {
              tickDecimals: 0
            }
          });
          return;
        }
      },
      tabbedinterface: {
        scope: "plugin",
        id: "tabbedinterface",
        stransition: true,
        exec: function(elm) {
          var $default_tab, $nav, $panels, $tabs, $this, $toggleButton, $toggleRow, cycle, opts, selectNext, selectPrev, start, stop, stopCycle, toggleCycle;
          $this = $(elm);
          opts = {
            panelActiveClass: "active",
            tabActiveClass: "active",
            defaultTab: (($this.find(".default").length) ? ".default" : "li:first-child"),
            autoHeight: ($this.hasClass("no-auto-height") ? false : true),
            cycle: ($this.hasClass("cycle-slow") ? 8000 : ($this.hasClass("cycle-fast") ? 2000 : 6000)),
            autoPlay: ($this.hasClass("no-autoplay") ? false : true),
            animate: ($this.hasClass("animate") || $this.hasClass("animate-slow") || $this.hasClass("animate-fast") ? true : false),
            animationSpeed: ($this.hasClass("animate-slow") ? "slow" : ($this.hasClass("animate-fast") ? "fast" : "normal"))
          };
          $nav = $this.find(".tabs");
          $tabs = $nav.find("li > a");
          $panels = $this.find(".tabs-panel").children();
          $default_tab = ($nav.find(".default").length > 0 ? $nav.find(".default") : $nav.find("li:first-child"));
          $nav.attr("role", "tablist");
          $nav.find("li").each(function() {
            $(this).attr("role", "presentation");
            return $(this).children("a").each(function() {
              return $(this).attr("role", "tab").attr("aria-selected", "false").attr("id", $(this).attr("href").substring(1) + "-link").bind("click", function(evt) {
                $(this).parent().parent().children(".active").children("a").each(function() {
                  $(this).attr("aria-selected", "false");
                  return $("#" + $(this).attr("href").substring(1)).attr("aria-hidden", "true");
                });
                $(this).attr("aria-selected", "true");
                return $("#" + $(this).attr("href").substring(1)).attr("aria-hidden", "false");
              });
            });
          });
          $panels.each(function() {
            return $(this).attr("role", "tabpanel").attr("aria-hidden", "true").attr("aria-labelledby", $("a[href*=\"#" + $(this).attr("id") + "\"]").attr("id"));
          });
          $default_tab.children("a").each(function() {
            $(this).attr("aria-selected", "true");
            return $("#" + $(this).attr("href").substring(1)).attr("aria-hidden", "false");
          });
          $(this).bind("keydown", "ctrl+left ctrl+up", function(evt) {
            selectPrev($tabs, $panels, opts);
            if (evt.stopPropagation) {
              return evt.stopImmediatePropagation();
            } else {
              return evt.cancelBubble = true;
            }
          });
          $(this).bind("keydown", "ctrl+right ctrl+down", function(evt) {
            selectNext($tabs, $panels, opts);
            if (evt.stopPropagation) {
              return evt.stopImmediatePropagation();
            } else {
              return evt.cancelBubble = true;
            }
          });
          $nav.find("li a").bind("focus", function() {
            return $(this).click();
          });
          $nav.find("li a").bind("keydown", function(e) {
            var $current;
            if (e.keyCode === 13 || e.keyCode === 32) {
              $current = $panels.filter(function() {
                return $(this).is(".active");
              });
              $current.attr("tabindex", "0");
              return setTimeout((function() {
                return $current.focus();
              }), 0);
            }
          });
          selectPrev = function($tabs, $panels, opts, keepFocus) {
            var $current, $prev, cycleButton;
            $current = $tabs.filter(function() {
              return $(this).is(".active");
            });
            $prev = $tabs.eq(($tabs.index($current) - 1) + $tabs.size() % $tabs.size());
            if (opts.animate) {
              $panels.filter("." + opts.panelActiveClass).removeClass(opts.panelActiveClass).attr("aria-hidden", "true").fadeOut(opts.animationSpeed, function() {
                return $panels.filter("#" + $next.attr("href").substr(1)).fadeIn(opts.animationSpeed, function() {
                  return $(this).addClass(opts.panelActiveClass).attr("aria-hidden", "false");
                });
              });
            } else {
              $panels.removeClass(opts.panelActiveClass).attr("aria-hidden", "true").hide();
              $panels.filter("#" + $prev.attr("href").substr(1)).show().addClass(opts.panelActiveClass).attr("aria-hidden", "false");
            }
            $tabs.parent().removeClass(opts.tabActiveClass).children().removeClass(opts.tabActiveClass).filter("a").attr("aria-selected", "false");
            $prev.parent().addClass(opts.tabActiveClass).children().addClass(opts.tabActiveClass).filter("a").attr("aria-selected", "true");
            cycleButton = $current.parent().siblings(".tabs-toggle");
            if (!keepFocus && (cycleButton.length === 0 || cycleButton.data("state") === "stopped")) {
              return $prev.focus();
            }
          };
          selectNext = function($tabs, $panels, opts, keepFocus) {
            var $current, $next, cycleButton;
            $current = $tabs.filter(function() {
              return $(this).is(".active");
            });
            $next = $tabs.eq(($tabs.index($current) + 1) % $tabs.size());
            if (opts.animate) {
              $panels.filter("." + opts.panelActiveClass).removeClass(opts.panelActiveClass).attr("aria-hidden", "true").fadeOut(opts.animationSpeed, function() {
                return $panels.filter("#" + $next.attr("href").substr(1)).fadeIn(opts.animationSpeed, function() {
                  return $(this).addClass(opts.panelActiveClass).attr("aria-hidden", "false");
                });
              });
            } else {
              $panels.removeClass(opts.panelActiveClass).attr("aria-hidden", "true").hide();
              $panels.filter("#" + $next.attr("href").substr(1)).show().addClass(opts.panelActiveClass).attr("aria-hidden", "false");
            }
            $tabs.parent().removeClass(opts.tabActiveClass).children().removeClass(opts.tabActiveClass).filter("a").attr("aria-selected", "false");
            $next.parent().addClass(opts.tabActiveClass).children().addClass(opts.tabActiveClass).filter("a").attr("aria-selected", "true");
            cycleButton = $current.parent().siblings(".tabs-toggle");
            if (!keepFocus && (cycleButton.length === 0 || cycleButton.data("state") === "stopped")) {
              return $next.focus();
            }
          };
          if (opts.autoHeight) {
            $panels.show();
            $(".tabs-panel", $this).equalHeights(true);
          }
          $this.easyTabs($.extend({}, opts, {
            cycle: false
          }));
          if (opts.cycle) {
            cycle = function($tabs, $panels, opts) {
              var $current, $pbar;
              $current = $tabs.filter(function() {
                return $(this).is(".active");
              });
              $pbar = $current.siblings(".tabs-roller");
              $this.find(".tabs-toggle").data("state", "started");
              return $pbar.show().animate({
                width: $current.parent().width()
              }, opts.cycle - 200, "linear", function() {
                $(this).width(0).hide();
                selectNext($tabs, $panels, opts, true);
                return $this.data("interval", setTimeout(function() {
                  return cycle($tabs, $panels, opts);
                }, 0));
              });
            };
            stopCycle = function(opts) {
              clearTimeout($this.data("interval"));
              $this.find(".tabs-roller").width(0).hide().stop();
              $this.find(".tabs-toggle").data("state", "stopped");
              $toggleButton.removeClass(stop["class"]).addClass(start["class"]).html(start["text"] + "<span class='cn-invisible'>" + start["hidden-text"] + "</span>").attr("aria-pressed", false);
              return $(".cn-invisible", $toggleButton).text(start["hidden-text"]);
            };
            $toggleRow = $("<li class='tabs-toggle'>");
            stop = {
              "class": "tabs-stop",
              text: pe.dic.get('%stop'),
              "hidden-text": pe.dic.get('%tab-rotation', 'disable')
            };
            start = {
              "class": "tabs-start",
              text: pe.dic.get('%play'),
              "hidden-text": pe.dic.get('%tab-rotation', 'enable')
            };
            $toggleButton = $("<a class='" + stop["class"] + "' href='javascript:;' role='button' aria-pressed='true'>" + stop["text"] + "<span class='cn-invisible'>" + stop["hidden-text"] + "</span></a>");
            $nav.append($toggleRow.append($toggleButton));
            toggleCycle = function() {
              if ($toggleRow.data("state") === "stopped") {
                selectNext($tabs, $panels, opts, true);
                cycle($tabs, $panels, opts);
                $toggleButton.removeClass(start["class"]).addClass(stop["class"]).html(stop["text"] + "<span class='cn-invisible'>" + stop["hidden-text"] + "</span>").attr("aria-pressed", true);
                return $(".cn-invisible", $toggleButton).text(stop["hidden-text"]);
              } else {
                if ($toggleRow.data("state") === "started") return stopCycle(opts);
              }
            };
            $toggleRow.click(toggleCycle).bind("keydown", function(e) {
              if (e.keyCode === 32) {
                toggleCycle();
                return e.preventDefault();
              }
            });
            $nav.find("li a").not($toggleRow.find("a")).click(function() {
              return stopCycle(opts);
            });
            $tabs.each(function() {
              var $pbar;
              $pbar = $("<div class=\"tabs-roller\">").hide().click(function() {
                return $(this).siblings("a").click();
              }).hover(function() {
                return $(this).css("cursor", "text");
              });
              if ($.browser.msie && $.browser.version < 8) {
                $(".tabs-style-2 .tabs, .tabs-style-2 .tabs li").css("filter", "");
              }
              return $(this).parent().append($pbar);
            });
            cycle($tabs, $panels, opts);
            if (!opts.autoPlay) stopCycle(opts);
          }
          $this.find("a[href^=\"#\"]").each(function() {
            var anchor, hash;
            hash = $(this).attr("href");
            if (hash.length > 1) {
              anchor = $(hash, $panels);
              if (anchor.length) {
                console.log("anchor found:", anchor, ", for link:", $(this));
                return $(this).click(function(e) {
                  var panel, panelId;
                  panel = anchor.parents("[role=\"tabpanel\"]:hidden");
                  if (panel) {
                    e.preventDefault();
                    panelId = panel.attr("id");
                    panel.parent().siblings(".tabs").find("a[href=\"#" + panelId + "\"]").click();
                    return anchor.get(0).scrollIntoView(true);
                  }
                });
              }
            }
          });
          return $this.attr("class", $this.attr("class").replace(/\bwidget-style-/, "style-"));
        }
      },
      webwidget: {
        scope: "plugin",
        id: "webwidget",
        twitter: {
          _parse_entries: function(entries, limit, elm) {
            var cap, i, result, sorted;
            cap = (limit > 0 && limit < entries.length ? limit : entries.length);
            sorted = entries.sort(function(a, b) {
              return pe.date.compare(b.created_at.replace("+0000 ", "") + " GMT", a.created_at.replace("+0000 ", "") + " GMT");
            });
            result = "<ul class=\"widget-content\">";
            i = 0;
            while (i < cap) {
              result += "<li><a class=\"float-left\" href=\"http://www.twitter.com/";
              result += sorted[i].user.name + "/status/" + sorted[i].user.id + "\">" + "<img class=\"widget-avatar\" src=\"" + sorted[i].user.profile_image_url + "\" /></a> ";
              result += pe.string.ify.clean(sorted[i].text);
              result += " <span class=\"widget-datestamp-accent\">" + pe.dic.ago(sorted[i].created_at) + "</span></li>";
              i++;
            }
            result += "</ul>";
            return elm.replaceWith(result);
          },
          _json_request: function(url) {
            if (url.toLowerCase().indexOf("!/search/") > -1) {
              return url.replace("http://", "https://").replace(/https:\/\/twitter.com\/#!\/search\/(.+$)/, function(str, p1, offset, s) {
                return "http://search.twitter.com/search.json?q=" + encodeURI(decodeURI(p1));
              });
            }
            return url.replace("http://", "https://").replace(/https:\/\/twitter.com\/#!\/(.+$)/i, function(str, p1, offset, s) {
              return "http://twitter.com/status/user_timeline/" + encodeURI(decodeURI(p1)) + ".json?callback=?";
            });
          },
          exec: function(urls, limit, elm) {
            var entries, i, last, parse_entries, _results;
            last = urls.length - 1;
            entries = [];
            parse_entries = this._parse_entries;
            i = urls.length - 1;
            _results = [];
            while (i >= 0) {
              $.getJSON(this._json_request(urls[i]), function(data) {
                var k;
                k = 0;
                while (k < data.length) {
                  entries.push(data[k]);
                  k++;
                }
                if (!last) parse_entries(entries, limit, elm);
                return last--;
              });
              _results.push(i--);
            }
            return _results;
          }
        },
        weather: {
          _parse_entries: function(entries, limit, elm) {
            var result;
            result = "<ul class=\"widget-content\">";
            result += "<li><a href=\"" + entries[1].link + "\">" + entries[1].title + "</a><span class=\"widget-datestamp\">[" + pe.date.to_iso_format(entries[1].publishedDate, true) + "]</span></li>";
            result += "</ul>";
            return elm.replaceWith(result);
          },
          exec: function(urls, limit, elm) {
            var entries, i, last, parse_entries, _results;
            last = urls.length - 1;
            entries = [];
            parse_entries = this._parse_entries;
            i = urls.length - 1;
            _results = [];
            while (i >= 0) {
              $.getJSON(this._json_request(urls[i]), function(data) {
                var k;
                k = 0;
                while (k < data.responseData.feed.entries.length) {
                  entries.push(data.responseData.feed.entries[k]);
                  k++;
                }
                if (!last) parse_entries(entries, limit, elm);
                return last--;
              });
              _results.push(i--);
            }
            return _results;
          },
          _json_request: function(url, limit) {
            var rl;
            url = url.replace(/^.*?\.gc\.ca\/([a-z]+).+\/(.*?)_[a-z]+_([ef])\.html/i, "http://www.weatheroffice.gc.ca/rss/$1/$2_$3.xml");
            rl = "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&callback=?&q=" + encodeURI(decodeURI(url));
            if (limit > 0) rl += "&num=" + limit;
            return rl;
          }
        },
        rss: {
          _parse_entries: function(entries, limit, elm) {
            var cap, i, result, sorted;
            cap = (limit > 0 && limit < entries.length ? limit : entries.length);
            sorted = entries.sort(function(a, b) {
              return pe.date.compare(b.publishedDate, a.publishedDate);
            });
            result = "<ul class=\"widget-content\">";
            i = 0;
            while (i < cap) {
              result += "<li><a href=\"" + sorted[i].link + "\">" + sorted[i].title + "</a><span class=\"widget-datestamp\">[" + pe.date.to_iso_format(sorted[i].publishedDate, true) + "]</span></li>";
              i++;
            }
            result += "</ul>";
            return elm.replaceWith(result);
          },
          exec: function(urls, limit, elm) {
            var entries, i, last, parse_entries, _results;
            last = urls.length - 1;
            entries = [];
            parse_entries = this._parse_entries;
            i = urls.length - 1;
            _results = [];
            while (i >= 0) {
              $.getJSON(this._json_request(urls[i]), function(data) {
                var k;
                k = 0;
                while (k < data.responseData.feed.entries.length) {
                  entries.push(data.responseData.feed.entries[k]);
                  k++;
                }
                if (!last) parse_entries(entries, limit, elm);
                return last--;
              });
              _results.push(i--);
            }
            return _results;
          },
          _json_request: function(url, limit) {
            var rl;
            rl = "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&callback=?&q=" + encodeURI(decodeURI(url));
            if (limit > 0) rl += "&num=" + limit;
            return rl;
          }
        },
        exec: function(elm, type) {
          var $elm, $response, feeds, limit;
          $elm = $(elm);
          limit = pe.limit($elm);
          feeds = $elm.find("a").map(function() {
            var a;
            a = $(this).attr("href");
            if (!type && /twitter.com/i.test(a)) type = "twitter";
            if (!type && /weatheroffice.gc.ca/i.test(a)) type = "weather";
            if (!type) type = "rss";
            return $(this).attr("href");
          });
          $response = $("<ul class=\"widget-content\"><li class=\"widget-state-loading\"><img src=\"" + pe.liblocation + "/images/ajax-loader.gif" + "\" /><span class=\"cn-invisible\">" + pe.dic.loading + "</span></li></ul>");
          $elm.find(".widget-content").replaceWith($response);
          $.extend({}, this[type]).exec(feeds, limit, $response);
          return;
        }
      }
    }
  };
  $.extend(true, window.pe, pe);
  return window.pe;
})(jQuery).swarm();
