/*
Progressive enhancement Object pre-loader
@version - 1.6
@license - MIT
*/
(function(doc) {
  var pe;
  pe = {
    /*
    @property : pe.is.mobile
    @value : true/false -- regex fu for mobile devices
    */
    is: {
      mobile: /iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase())
    },
    /*
    @property : head
    @value : the head element
    */
    add: (function() {
      return {
        head: doc.getElementsByTagName('head')[0],
        liblocation: doc.getElementById('progressive').src.replace(/pe-ap.(dev.)?js.*$/i, ""),
        /* 
        @function : pe.add.set
        @params : [ name, content ] -> sets element properties
        */
        set: function(elm, name, value) {
          elm.setAttribute(name, value);
          return this;
        },
        /* 
        @function : pe.add.css
        @params : [ url] -> add a stylesheet link to the head
        */
        css: function(css) {
          var styleElement;
          styleElement = doc.createElement('link');
          this.set(styleElement, 'type', 'text/css').set(styleElement, 'rel', 'stylesheet').set(styleElement, 'href', css);
          this.head.appendChild(styleElement);
          return this;
        },
        /* 
        @function : pe.add.meta
        @params : [ name, content ] -> add a metadata element to the head of the document
        */
        meta: function(name, content) {
          var styleElement;
          styleElement = doc.createElement('meta');
          this.set(styleElement, 'name', name).set(styleElement, 'content', content);
          this.head.appendChild(styleElement);
          return this;
        }
      };
    })(),
    /*
    @function : pe.initialize
    @params: none
    */
    progress: function() {
      var liblocation;
      liblocation = this.add.liblocation;
      this.add.css("" + liblocation + "pe.loading.css");
      head.js("http://code.jquery.com/jquery-latest.min.js", "" + liblocation + "pe.third-party.js", "" + liblocation + "pe.swarm.js");
      if (this.is.mobile) {
        this.add.css("http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.css").css("" + liblocation + "mobile.style.css").meta('viewport', 'user-scalable=yes, width=device-width');
        head.js("http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.js");
      }
      return;
    }
  };
  window.pe = pe;
  return pe;
})(document).progress();
