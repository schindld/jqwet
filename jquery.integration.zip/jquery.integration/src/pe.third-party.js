/**
 *  Flash IE6/IE7 fix for safe flash unloading and loading
 *  @credits: http://www.longtailvideo.com/support/forums/jw-player/bug-reports/10374/javascript-error-with-embed
 */
(function () {
    var setRemoveCallback = function () {
            __flash__removeCallback = function (instance, name) {
                if (instance) {
                    instance[name] = null;
                }
            };
            window.setTimeout(setRemoveCallback, 10);
        };
    setRemoveCallback();
})();
/*-------------------------------------------------------------------- 
 * javascript method: "pxToEm"
 * by:
   Scott Jehl (scott@filamentgroup.com) 
   Maggie Wachs (maggie@filamentgroup.com)
   http://www.filamentgroup.com
 *
 * Copyright (c) 2008 Filament Group
 * Dual licensed under the MIT (filamentgroup.com/examples/mit-license.txt) and GPL (filamentgroup.com/examples/gpl-license.txt) licenses.
 *
 * Description: Extends the native Number and String objects with pxToEm method. pxToEm converts a pixel value to ems depending on inherited font size.  
 * Article: http://www.filamentgroup.com/lab/retaining_scalable_interfaces_with_pixel_to_em_conversion/
 * Demo: http://www.filamentgroup.com/examples/pxToEm/	 	
 *							
 * Options:  	 								
 		scope: string or jQuery selector for font-size scoping
 		reverse: Boolean, true reverses the conversion to em-px
 * Dependencies: jQuery library						  
 * Usage Example: myPixelValue.pxToEm(); or myPixelValue.pxToEm({'scope':'#navigation', reverse: true});
 *
 * Version: 2.0, 08.01.2008 
 * Changelog:
 *		08.02.2007 initial Version 1.0
 *		08.01.2008 - fixed font-size calculation for IE
--------------------------------------------------------------------*/

Number.prototype.pxToEm = String.prototype.pxToEm = function(settings){
	//set defaults
	settings = jQuery.extend({
		scope: 'body',
		reverse: false
	}, settings);
	
	var pxVal = (this == '') ? 0 : parseFloat(this);
	var scopeVal;
	var getWindowWidth = function(){
		var de = document.documentElement;
		return self.innerWidth || (de && de.clientWidth) || document.body.clientWidth;
	};	
	
	/* When a percentage-based font-size is set on the body, IE returns that percent of the window width as the font-size. 
		For example, if the body font-size is 62.5% and the window width is 1000px, IE will return 625px as the font-size. 	
		When this happens, we calculate the correct body font-size (%) and multiply it by 16 (the standard browser font size) 
		to get an accurate em value. */
				
	if (settings.scope == 'body' && $.browser.msie && (parseFloat($('body').css('font-size')) / getWindowWidth()).toFixed(1) > 0.0) {
		var calcFontSize = function(){		
			return (parseFloat($('body').css('font-size'))/getWindowWidth()).toFixed(3) * 16;
		};
		scopeVal = calcFontSize();
	}
	else { scopeVal = parseFloat(jQuery(settings.scope).css("font-size")); };
			
	var result = (settings.reverse == true) ? (pxVal * scopeVal).toFixed(2) + 'px' : (pxVal / scopeVal).toFixed(2) + 'em';
	return result;
};
/*-------------------------------------------------------------------- 
 * jQuery pixel/em conversion plugins: toEm() and toPx()
 * by Scott Jehl (scott@filamentgroup.com), http://www.filamentgroup.com
 * Copyright (c) Filament Group
 * Dual licensed under the MIT (filamentgroup.com/examples/mit-license.txt) or GPL (filamentgroup.com/examples/gpl-license.txt) licenses.
 * Article: http://www.filamentgroup.com/lab/update_jquery_plugin_for_retaining_scalable_interfaces_with_pixel_to_em_con/
 * Options:  	 								
 		scope: string or jQuery selector for font-size scoping		  
 * Usage Example: $(myPixelValue).toEm(); or $(myEmValue).toPx();
--------------------------------------------------------------------*/

(function($){
	
		$.fn.toEm = function(settings){
			settings = jQuery.extend({
				scope: 'body'
			}, settings);
			var that = parseInt(this[0],10),
				scopeTest = jQuery('<div style="display: none; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;">&nbsp;</div>').appendTo(settings.scope),
				scopeVal = scopeTest.height();
			scopeTest.remove();
			return (that / scopeVal).toFixed(8) + 'em';
		};


		$.fn.toPx = function(settings){
			settings = jQuery.extend({
				scope: 'body'
			}, settings);
			var that = parseFloat(this[0]),
				scopeTest = jQuery('<div style="display: none; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;">&nbsp;</div>').appendTo(settings.scope),
				scopeVal = scopeTest.height();
			scopeTest.remove();
			return Math.round(that * scopeVal) + 'px';
		};
})(jQuery);

/* http://keith-wood.name/bookmark.html
   Sharing bookmarks for jQuery v1.4.0.
   Written by Keith Wood (kbwood{at}iinet.com.au) March 2008.
   Dual licensed under the GPL (http://dev.jquery.com/browser/trunk/jquery/GPL-LICENSE.txt) and 
   MIT (http://dev.jquery.com/browser/trunk/jquery/MIT-LICENSE.txt) licenses. 
   Please attribute the author if you use it. */

/* Allow your page to be shared with various bookmarking sites.
   Attach the functionality with options like:
   $('div selector').bookmark({sites: ['delicious', 'digg']});
*/

(function($) { // Hide scope, no $ conflict

var PROP_NAME = 'bookmark';

/* Bookmark sharing manager. */
function Bookmark() {
	this._defaults = {
		url: '',  // The URL to bookmark, leave blank for the current page
		sourceTag: '', // Extra tag to add to URL to indicate source when it returns
		title: '',  // The title to bookmark, leave blank for the current one
		description: '',  // A longer description of the site
		sites: [],  // List of site IDs or language selectors (lang:xx) or
			// category selectors (category:xx) to use, empty for all
		iconsStyle: 'bookmark_icons', // CSS class for site icons
		icons: 'bookmarks.png', // Horizontal amalgamation of all site icons
		iconSize: 16,  // The size of the individual icons
		iconCols: 16,  // The number of icons across the combined image
		target: '_blank',  // The name of the target window for the bookmarking links
		compact: true,  // True if a compact presentation should be used, false for full
		hint: 'Send to {s}',  // Popup hint for links, {s} is replaced by display name
		popup: false, // True to have it popup on demand, false to show always
		popupText: 'Bookmark this site...', // Text for the popup trigger
		addFavorite: false,  // True to add a 'add to favourites' link, false for none
		favoriteText: 'Favorite',  // Display name for the favourites link
		favoriteIcon: 0,  // Icon for the favourites link
		addEmail: false,  // True to add a 'e-mail a friend' link, false for none
		emailText: 'E-mail',  // Display name for the e-mail link
		emailIcon: 1,  // Icon for the e-mail link
		emailSubject: 'Interesting page',  // The subject for the e-mail
		emailBody: 'I thought you might find this page interesting:\n{t} ({u})', // The body of the e-mail,
			// use '{t}' for the position of the page title, '{u}' for the page URL,
			// '{d}' for the description, and '\n' for new lines
		manualBookmark: 'Please close this dialog and\npress Ctrl-D to bookmark this page.',
			// Instructions for manually bookmarking the page
		addShowAll: false, // True to show listed sites first, then all on demand
		showAllText: 'Show all ({n})', // Display name for show all link, use '{n}' for the number of sites
		showAllIcon: 2, // Icon for show all link
		showAllTitle: 'All bookmarking sites', // Title for show all popup
		onSelect: null, // Callback on selection
		addAnalytics: false, // True to include Google Analytics for links
		analyticsName: '/share/{r}/{s}' // The "URL" that is passed to the Google Analytics,
			// use '{s}' for the site code, '{n}' for the site name,
			// '{u}' for the current full URL, '{r}' for the current relative URL,
			// or '{t}' for the current title
	};
	this._sites = {  // The definitions of the available bookmarking sites, in URL use
		// '{u}' for the page URL, '{t}' for the page title, and '{d}' for the description
		'aol': {display: 'myAOL', icon: 3, lang: 'en', category: 'bookmark',
			url: 'http://favorites.my.aol.com/ffclient/AddBookmark?url={u}&amp;title={t}'},
		'bitly': {display: 'bit.ly', icon: 4, lang: 'en', category: 'tools',
			url: 'http://bit.ly/?url={u}'},
		'blogger': {display: 'Blogger', icon: 5, lang: 'en', category: 'blog',
			url: 'http://www.blogger.com/blog_this.pyra?t=&amp;u={u}&amp;n={t}'},
		'delicious': {display: 'del.icio.us', icon: 6, lang: 'en', category: 'bookmark',
			url: 'http://del.icio.us/post?url={u}&amp;title={t}'},
		'digg': {display: 'Digg', icon: 7, lang: 'en', category: 'news',
			url: 'http://digg.com/submit?phase=2&amp;url={u}&amp;title={t}'},
		'diigo': {display: 'Diigo', icon: 8, lang: 'en', category: 'social',
			url: 'http://www.diigo.com/post?url={u}&amp;title={t}'},
		'dzone': {display: 'DZone', icon: 9, lang: 'en', category: 'bookmark',
			url: 'http://www.dzone.com/links/add.html?url={u}&amp;title={t}'},
		'facebook': {display: 'Facebook', icon: 10, lang: 'en', category: 'social',
			url: 'http://www.facebook.com/sharer.php?u={u}&amp;t={t}'},
		'fark': {display: 'Fark', icon: 11, lang: 'en', category: 'news',
			url: 'http://cgi.fark.com/cgi/fark/submit.pl?new_url={u}&amp;new_comment={t}'},
		'google': {display: 'Google', icon: 12, lang: 'en', category: 'bookmark',
			url: 'http://www.google.com/bookmarks/mark?op=edit&amp;bkmk={u}&amp;title={t}'},
		'googlereader': {display: 'Google Reader', icon: 13, lang: 'en', category: 'tools',
			url: 'http://www.google.com/reader/link?url={u}&amp;title={t}&amp;srcTitle={u}'},
		'hotmail': {display: 'Hotmail', icon: 14, lang: 'en', category: 'mail',
			url: 'http://www.hotmail.msn.com/secure/start?action=compose&amp;to=&amp;body={u}&amp;subject={t}'},
		'linkedin': {display: 'LinkedIn', icon: 15, lang: 'en', category: 'social',
			url: 'http://www.linkedin.com/shareArticle?mini=true&amp;url={u}&amp;title={t}&amp;ro=false&amp;summary={d}&amp;source='},
		'mixx': {display: 'Mixx', icon: 16, lang: 'en', category: 'news',
			url: 'http://www.mixx.com/submit/story?page_url={u}&amp;title={t}'},
		'multiply': {display: 'Multiply', icon: 17, lang: 'en', category: 'social',
			url: 'http://multiply.com/gus/journal/compose/addthis?body=&amp;url={u}&amp;subject={t}'},
		'myspace': {display: 'MySpace', icon: 18, lang: 'en', category: 'social',
			url: 'http://www.myspace.com/Modules/PostTo/Pages/?u={u}&amp;t={t}'},
		'netvibes': {display: 'Netvibes', icon: 19, lang: 'en', category: 'news',
			url: 'http://www.netvibes.com/share?url={u}&amp;title={t}'},
		'newsvine': {display: 'Newsvine', icon: 20, lang: 'en', category: 'news',
			url: 'http://www.newsvine.com/_wine/save?u={u}&amp;h={t}'},
		'reddit': {display: 'reddit', icon: 21, lang: 'en', category: 'news',
			url: 'http://reddit.com/submit?url={u}&amp;title={t}'},
		'stumbleupon': {display: 'StumbleUpon', icon: 22, lang: 'en', category: 'bookmark',
			url: 'http://www.stumbleupon.com/submit?url={u}&amp;title={t}'},
		'technorati': {display: 'Technorati', icon: 23, lang: 'en', category: 'news',
			url: 'http://www.technorati.com/faves?add={u}'},
		'tipd': {display: 'Tip\'d', icon: 24, lang: 'en', category: 'news',
			url: 'http://tipd.com/submit.php?url={u}'},
		'tumblr': {display: 'tumblr', icon: 25, lang: 'en', category: 'blog',
			url: 'http://www.tumblr.com/share?v=3&amp;u={u}&amp;t={t}'},
		'twitter':{display: 'twitter', icon: 26, lang: 'en', category: 'blog',
			url: 'http://twitter.com/home?status={t}%20{u}'},
		'windows': {display: 'Windows Live', icon: 27, lang: 'en', category: 'bookmark',
			url: 'https://favorites.live.com/quickadd.aspx?marklet=1&amp;mkt=en-us&amp;url={u}&amp;title={t}'},
		'wishlist': {display: 'Amazon WishList', icon: 28, lang: 'en', category: 'shopping',
			url: 'http://www.amazon.com/wishlist/add?u={u}&amp;t={t}'},
		'yahoo': {display: 'Yahoo Bookmarks', icon: 29, lang: 'en', category: 'bookmark',
			url: 'http://bookmarks.yahoo.com/toolbar/savebm?opener=tb&amp;u={u}&amp;t={t}'},
		'yahoobuzz': {display: 'Yahoo Buzz', icon: 30, lang: 'en', category: 'bookmark',
			url: 'http://buzz.yahoo.com/submit?submitUrl={u}&amp;submitHeadline={t}'}
	};
	this.commonSites = [];
	for (var id in this._sites) {
		this.commonSites.push(id);
	}
}

$.extend(Bookmark.prototype, {
	/* Class name added to elements to indicate already configured with bookmarking. */
	markerClassName: 'hasBookmark',

	/* Override the default settings for all bookmarking instances.
	   @param  settings  (object) the new settings to use as defaults
	   @return void */
	setDefaults: function(settings) {
		extendRemove(this._defaults, settings || {});
		return this;
	},

	/* Add a new bookmarking site to the list.
	   @param  id        (string) the ID of the new site
	   @param  display   (string) the display name for this site
	   @param  icon      (string) the location (URL) of an icon for this site (16x16), or
	                     (number) the index of the icon within the combined image
	   @param  lang      (string) the language code for this site
	   @param  category  (string) the category for this site
	   @param  url       (string) the submission URL for this site,
	                     with {u} marking where the current page's URL should be inserted,
	                     and {t} indicating the title insertion point
	   @return this singleton */
	addSite: function(id, display, icon, lang, category, url) {
		this._sites[id] = {display: display, icon: icon, lang: lang, category: category, url: url};
		return this;
	},

	/* Return the list of defined sites.
	   @return  (object[]) indexed by site id (string), each object contains
	            display (string) the display name,
	            icon    (string) the location of the icon, or
	                    (number) the icon's index in the combined image
	            lang    (string) the language code for this site
	            url     (string) the submission URL for the site */
	getSites: function() {
		return this._sites;
	},

	/* Attach the bookmarking widget to a div.
	   @param  target    (element) the bookmark container
	   @param  settings  (object) the settings for this container */
	_attachBookmark: function(target, settings) {
		target = $(target);
		if (target.hasClass(this.markerClassName)) {
			return;
		}
		target.addClass(this.markerClassName);
		this._updateBookmark(target, settings);
	},

	/* Reconfigure the settings for a bookmarking div.
	   @param  target    (element) the bookmark container
	   @param  settings  (object) the new settings for this container or
	                     (string) a single setting name
	   @param  value     (any) the single setting's value */
	_changeBookmark: function(target, settings, value) {
		target = $(target);
		if (!target.hasClass(this.markerClassName)) {
			return;
		}
		if (typeof settings == 'string') {
			var name = settings;
			settings = {};
			settings[name] = value;
		}
		this._updateBookmark(target, settings);
	},

	/* Construct the requested bookmarking links.
	   @param  target    (element) the bookmark container
	   @param  settings  (object) the settings for this container */
	_updateBookmark: function(target, settings) {
		var oldSettings = $.data(target[0], PROP_NAME) || $.extend({}, this._defaults);
		settings = extendRemove(oldSettings, settings || {});
		$.data(target[0], PROP_NAME, settings);
		var sites = settings.sites;
		if (sites.length == 0) { // All sites
			$.each($.bookmark._sites, function(id) {
				sites.push(id);
			});
			sites.sort();
		}
		else {
			$.each(sites, function(index, value) {
				var lang = value.match(/lang:(.*)/); // Select by language
				if (lang) {
					$.each($.bookmark._sites, function(id, site) {
						if (site.lang == lang[1] && $.inArray(id, sites) == -1) {
							sites.push(id);
						}
					});
				}
				var category = value.match(/category:(.*)/); // Select by category
				if (category) {
					$.each($.bookmark._sites, function(id, site) {
						if (site.category == category[1] && $.inArray(id, sites) == -1) {
							sites.push(id);
						}
					});
				}
			});
		}
		target.empty();
		var container = target;
		if (settings.popup) {
			target.append('<a href="#" class="bookmark_popup_text">' + settings.popupText + '</a>');
			container = $('<div class="bookmark_popup"></div>').appendTo(target);
		}
		var details = $.bookmark._getSiteDetails(settings);
		var list = $('<ul class="bookmark_list' +
			(settings.compact ? ' bookmark_compact' : '') + '"></ul>').appendTo(container);
		if (settings.addFavorite) {
			$.bookmark._addOneSite(settings, list, settings.favoriteText, settings.favoriteIcon, '#', function() {
					$.bookmark._addFavourite(details.url.replace(/'/g, '\\\''), details.title.replace(/'/g, '\\\''));
					return false;
				});
		}
		if (settings.addEmail) {
			$.bookmark._addOneSite(settings, list, settings.emailText, settings.emailIcon,
				'mailto:?subject=' + encodeURIComponent(settings.emailSubject) +
				'&amp;body=' + encodeURIComponent(settings.emailBody.
				replace(/\{u\}/, details.url).replace(/\{t\}/, details.title).replace(/\{d\}/, details.desc)));
		}
		$.bookmark._addSelectedSites(sites, details, settings, list);
		if (settings.addShowAll) {
			var count = 0;
			for (var n in $.bookmark._sites) {
				count++;
			}
			var showAll = settings.showAllText.replace(/\{n\}/, count);
			$.bookmark._addOneSite(settings, list, showAll, settings.showAllIcon, '#', function() {
					$.bookmark._showAll(this, settings);
					return false;
				}, showAll);
		}
		if (settings.popup) {
			target.find('.bookmark_popup_text').click(function() {
				var target = $(this).parent();
				var offset = target.offset();
				target.find('.bookmark_popup').css('left', offset.left).
					css('top', offset.top + target.outerHeight()).toggle();
				return false;
			});
			$(document).click(function(event) { // Close on external click
				target.find('.bookmark_popup').hide();
			});
		}
	},

	/* Add all the selected sites to the list.
	   @param  sites     (string[]) the IDs of the selected sites
	   @param  details   (object) details about this page
	   @param  settings  (object) the bookmark settings
	   @param  list      (jQuery) the list to add to */
	_addSelectedSites: function(sites, details, settings, list) {
		$.each(sites, function(index, id) {
			var site = $.bookmark._sites[id];
			if (site) {
				$.bookmark._addOneSite(settings, list, site.display, site.icon, (settings.onSelect ? '#' :
					site.url.replace(/\{u\}/, details.url2 + (details.sourceTag ? details.sourceTag + id : '')).
					replace(/\{t\}/, details.title2).replace(/\{d\}/, details.desc2)),
					function() {
						if (settings.addAnalytics && window.pageTracker) {
							window.pageTracker._trackPageview(settings.analyticsName.
								replace(/\{s\}/, id).replace(/\{n\}/, site.display).
								replace(/\{u\}/, details.url).replace(/\{r\}/, details.relUrl).
								replace(/\{t\}/, details.title));
						}
						$('#bookmark_all').remove();
						$(document).unbind('click.bookmark');
						if (settings.onSelect) {
							$.bookmark._selected($(this).closest('.' + $.bookmark.markerClassName)[0], id);
							return false;
						}
						return true;
					});
			}
		});
	},

	/* Add a single site to the list.
	   @param  settings  (object) the bookmark settings
	   @param  list      (jQuery) the list to add to
	   @param  display   (string) the display name for this site
	   @param  icon      (string) the location (URL) of an icon for this site (16x16), or
	                     (number) the index of the icon within the combined image
	   @param  url       (string) the URl for this site
	   @param  onclick   (function, optional) additional processing for this link
	   @param  hint      (string, optional) the hint text to use for this link */
	_addOneSite: function(settings, list, display, icon, url, onclick, hint) {
		var hintFormat = settings.hint || '{s}';
		var html = '<li><a href="' + url + '"' +
			(settings.target ? ' target="' + settings.target + '"' : '') + '>';
		if (icon != null) {
			var title = hint || hintFormat.replace(/\{s\}/, display);
			if (typeof icon == 'number') {
				html += '<span title="' + title + '" ' +
					(settings.iconsStyle ? 'class="' + settings.iconsStyle + '" ' : '') +
					'style="' + (settings.iconsStyle ? 'background-position: ' :
					'background: transparent url(' + settings.icons + ') no-repeat ') + '-' +
					((icon % settings.iconCols) * settings.iconSize) + 'px -' +
					(Math.floor(icon / settings.iconCols) * settings.iconSize) + 'px;' +
					($.browser.mozilla && $.browser.version < '1.9' ?
					' padding-left: ' + settings.iconSize + 'px; padding-bottom: ' +
					(Math.max(0, settings.iconSize - 16)) + 'px;' : '') + '"></span>';
			}
			else {
				html += '<img src="' + icon + '" alt="' + title + '" title="' +
					title + '"' + (($.browser.mozilla && $.browser.version < '1.9') ||
					($.browser.msie && $.browser.version < '7.0') ?
					' style="vertical-align: bottom;"' :
					($.browser.msie ? ' style="vertical-align: middle;"' :
					($.browser.opera || $.browser.safari ?
					' style="vertical-align: baseline;"' : ''))) + '/>';
			}
			html +=	(settings.compact ? '' : '&#xa0;');
		}
		html +=	(settings.compact ? '' : display) + '</a></li>';
		html = $(html).appendTo(list);
		if (onclick) {
			html.find('a').click(onclick);
		}
	},

	/* Remove the bookmarking widget from a div.
	   @param  target  (element) the bookmark container */
	_destroyBookmark: function(target) {
		target = $(target);
		if (!target.hasClass(this.markerClassName)) {
			return;
		}
		target.removeClass(this.markerClassName).empty();
		$.removeData(target[0], PROP_NAME);
	},

	/* Callback when selected.
	   @param  target  (element) the target div
	   @param  siteID  (string) the selected site ID */
	_selected: function(target, siteID) {
		var settings = $.data(target, PROP_NAME);
		var site = $.bookmark._sites[siteID];
		var details = $.bookmark._getSiteDetails(settings);
		settings.onSelect.apply(target, [siteID, site.display, site.url.replace(/&amp;/g,'&').
			replace(/\{u\}/, details.url2 + (details.sourceTag ? details.sourceTag + siteID : '')).
			replace(/\{t\}/, details.title2).replace(/\{d\}/, details.desc2)]);
	},

	/* Add the current page as a favourite in the browser.
	   @param  url    (string) the URL to bookmark
	   @param  title  (string) the title to bookmark */
	_addFavourite: function(url, title) {
		if ($.browser.msie) {
			window.external.addFavorite(url, title);
		}
		else {
			alert(this._defaults.manualBookmark);
		}
	},

	/* Show all sites in a popup list.
	   @param  elem      (element) the clicked 'Show all' link
	   @param  settings  (object) the bookmark settings */
	_showAll: function(elem, settings) {
		var sites = [];
		$.each($.bookmark._sites, function(id) {
			sites.push(id);
		});
		sites.sort();
		var details = $.bookmark._getSiteDetails(settings);
		var list = $('<ul class="bookmark_list"></ul>');
		var saveCompact = settings.compact;
		settings.compact = false;
		$.bookmark._addSelectedSites(sites, details, settings, list);
		settings.compact = saveCompact;
		var all = $('<div id="bookmark_all"><p>' + settings.showAllTitle + '</p></div>').
			append(list).appendTo('body');
		all.css({left: ($(window).width() - all.width()) / 2, top: ($(window).height() - all.height()) / 2}).show();
		$(document).bind('click.bookmark', function(event) {
			if ($(event.target).closest(elem).length == 0 && $(event.target).closest('#bookmark_all').length == 0) {
				$('#bookmark_all').remove();
				$(document).unbind('click.bookmark');
			}
		});
	},

	/* Retrieve details about the current site.
	   @param  settings  (object) the bookmark settings
	   @return  (object) the site details */
	_getSiteDetails: function(settings) {
		var url = settings.url || window.location.href;
		var title = settings.title || document.title || $('h1:first').text();
		var desc = settings.description || $('meta[name="description"]').attr('content') || '';
		var sourceTag = (!settings.sourceTag ? '' :
			encodeURIComponent((url.indexOf('?') > -1 ? '&' : '?') + settings.sourceTag + '='));
		return {url: url, title: title, desc: desc, relUrl: url.replace(/^.*\/\/[^\/]*\//, ''),
			sourceTag: sourceTag, url2: encodeURIComponent(url),
			title2: encodeURIComponent(title), desc2: encodeURIComponent(desc)};
	}
});

/* jQuery extend now ignores nulls! */
function extendRemove(target, props) {
	$.extend(target, props);
	for (var name in props) {
		if (props[name] == null) {
			target[name] = null;
		}
	}
	return target;
}

/* Attach the bookmarking functionality to a jQuery selection.
   @param  command  (string) the command to run (optional, default 'attach')
   @param  options  (object) the new settings to use for these bookmarking instances
   @return  (jQuery object) for chaining further calls */
$.fn.bookmark = function(options) {
	var otherArgs = Array.prototype.slice.call(arguments, 1);
	return this.each(function() {
		if (typeof options == 'string') {
			if (!$.bookmark['_' + options + 'Bookmark']) {
				throw 'Unknown operation: ' + options;
			}
			$.bookmark['_' + options + 'Bookmark'].
				apply($.bookmark, [this].concat(otherArgs));
		}
		else {
			$.bookmark._attachBookmark(this, options || {});
		}
	});
};

/* Initialise the bookmarking functionality. */
$.bookmark = new Bookmark(); // singleton instance

})(jQuery);

/**
 * jQuery Cookie plugin
 *
 * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */
jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
        options = jQuery.extend({}, options);

        if (value === null || value === undefined) {
            options.expires = -1;
        }

        if (typeof options.expires === 'number') {
            var days = options.expires, t = options.expires = new Date();
            t.setDate(t.getDate() + days);
        }

        value = String(value);

        return (document.cookie = [
            encodeURIComponent(key), '=',
            options.raw ? value : encodeURIComponent(value),
            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
            options.path ? '; path=' + options.path : '',
            options.domain ? '; domain=' + options.domain : '',
            options.secure ? '; secure' : ''
        ].join(''));
    }

    // key and possibly options given, get cookie...
    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};
/*
 * jQuery EasyTabs plugin 1.1
 *
 * Copyright (c) 2010 Steve Schwartz (JangoSteve)
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 *
 * Date: Thu Aug 24 01:02:00 2010 -0500
 */
(function($) {
  $.fn.easyTabs = function(options) {

    var opts = $.extend({}, $.fn.easyTabs.defaults, options);

    selectDefaultTab = function(tabs){
      selectedTab = tabs.find("a[href='" + window.location.hash + "']").parent();
      if(selectedTab.size() == 1){
        defaultTab = selectedTab;
        opts.cycle = false;
      }else{
        defaultTab = ( tabs.parent().find(opts.defaultTab).length ) ? $(tabs.parent().find(opts.defaultTab)) : $(tabs.parent().find('li:first-child'));
      }
      return defaultTab;
    }

    selectTab = function(tabs,panels,clicked){
      if(opts.animate){
        panels.filter("." + opts.panelActiveClass).removeClass(opts.panelActiveClass).fadeOut(opts.animationSpeed, function(){
          panels.filter("#" + $(clicked).attr("href").substr(1)).fadeIn(opts.animationSpeed, function(){ $(this).addClass(opts.panelActiveClass); });
        });
      }else{
        panels.removeClass(opts.panelActiveClass).hide();
        panels.filter("#" + $(clicked).attr("href").substr(1)).show().addClass(opts.panelActiveClass);
      }
      tabs.removeClass(opts.tabActiveClass).children().removeClass(opts.tabActiveClass);
      clicked.parent().addClass(opts.tabActiveClass).children().addClass(opts.tabActiveClass);
    }

    cycleTabs = function(tabs,panels,tabNumber){
      if(opts.cycle){
        tabNumber = tabNumber % tabs.size();
        selectTab(tabs,panels,$(tabs[tabNumber]).children("a"));
        setTimeout(function(){cycleTabs(tabs,panels,(tabNumber + 1));}, opts.cycle);
      }
    }

    return this.each(function() {
      var url = window.location;
      var container = $(this);
      var tabs = $("#" + this.id + " " + (opts.tabs));
      var panels = $();
      tabs.each(function(){
        panels = panels.add(container.find("div[id=" + $(this).children("a").attr("href").substr(1) + "]").hide());
      });
      $('a.anchor').remove().prependTo('body');
      var defaultTab = selectDefaultTab(tabs);
      $(panels.filter("#" + defaultTab.children("a").attr("href").substr(1))).show().addClass(opts.panelActiveClass);

      defaultTab.addClass(opts.tabActiveClass).children().addClass(opts.tabActiveClass);

      tabs.children("a").click(function() {
        opts.cycle = false;
        var clicked = $($(this));
        if(clicked.hasClass(opts.tabActiveClass)){ return false; }
        selectTab(tabs,panels,clicked);
        if(opts.updateHash){
          window.location = url.toString().replace((url.pathname + url.hash), (url.pathname + clicked.attr("href")));
        }
        return false;
      });

      // enabling back-button with jquery.hashchange plugin
      // http://benalman.com/projects/jquery-hashchange-plugin/
      if(typeof $(window).hashchange == 'function'){
        $(window).hashchange( function(){
          selectTab(tabs,panels,selectDefaultTab(tabs).children("a"));
        }) 
      }else if($.address && typeof $.address.change == 'function'){ // back-button with jquery.address plugin http://www.asual.com/jquery/address/docs/
        $.address.change( function(){
          selectTab(tabs,panels,selectDefaultTab(tabs).children("a"));
        })
      }

      cycleTabs(tabs,panels,0);

    });

  }

  $.fn.easyTabs.defaults = {animate: true, panelActiveClass: "active", tabActiveClass: "active", defaultTab: "li:first-child", animationSpeed: "normal", tabs: "> ul > li", updateHash: true, cycle: false}
})(jQuery);
/*-------------------------------------------------------------------- 
 * JQuery Plugin: "EqualHeights"
 * by:	Scott Jehl, Todd Parker, Maggie Costello Wachs (http://www.filamentgroup.com)
 *
 * Copyright (c) 2008 Filament Group
 * Licensed under GPL (http://www.opensource.org/licenses/gpl-license.php)
 *
 * Description: Compares the heights or widths of the top-level children of a provided element 
 		and sets their min-height to the tallest height (or width to widest width). Sets in em units 
 		by default if pxToEm() method is available.
 * Dependencies: jQuery library, pxToEm method	(article: 
		http://www.filamentgroup.com/lab/retaining_scalable_interfaces_with_pixel_to_em_conversion/)							  
 * Usage Example: $(element).equalHeights();
  		Optional: to set min-height in px, pass a true argument: $(element).equalHeights(true);
 * Version: 2.0, 08.01.2008
--------------------------------------------------------------------*/

(function ($) {

		$.fn.equalHeights = function(px) {
				$(this).each(function(){
					var currentTallest = 0;
					$(this).children().each(function(i){
						if ($(this).height() > currentTallest) { currentTallest = $(this).height(); }
					});
					if (!px || !Number.prototype.pxToEm) currentTallest = currentTallest.pxToEm(); //use ems unless px is specified
					// for ie6, set height since min-height isn't supported
					if ($.browser.msie && $.browser.version == 6.0) { $(this).children().css({'height': currentTallest}); }
					$(this).children().css({'min-height': currentTallest}); 
				});
				return this;
			};
})(jQuery)
// Copyright 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// Known Issues:
//
// * Patterns only support repeat.
// * Radial gradient are not implemented. The VML version of these look very
//   different from the canvas one.
// * Clipping paths are not implemented.
// * Coordsize. The width and height attribute have higher priority than the
//   width and height style values which isn't correct.
// * Painting mode isn't implemented.
// * Canvas width/height should is using content-box by default. IE in
//   Quirks mode will draw the canvas using border-box. Either change your
//   doctype to HTML5
//   (http://www.whatwg.org/specs/web-apps/current-work/#the-doctype)
//   or use Box Sizing Behavior from WebFX
//   (http://webfx.eae.net/dhtml/boxsizing/boxsizing.html)
// * Non uniform scaling does not correctly scale strokes.
// * Filling very large shapes (above 5000 points) is buggy.
// * Optimize. There is always room for speed improvements.

// Only add this code if we do not already have a canvas implementation
if (!document.createElement('canvas').getContext) {
	
	(function () {
		
		// alias some functions to make (compiled) code shorter
		var m = Math;
		var mr = m.round;
		var ms = m.sin;
		var mc = m.cos;
		var abs = m.abs;
		var sqrt = m.sqrt;
		
		// this is used for sub pixel precision
		var Z = 10;
		var Z2 = Z / 2;
		
		/**
		 * This funtion is assigned to the <canvas> elements as element.getContext().
		 * @this {HTMLElement}
		 * @return {CanvasRenderingContext2D_}
		 */
		function getContext() {
			return this.context_ ||
			(this.context_ = new CanvasRenderingContext2D_(this));
		}
		
		var slice = Array.prototype.slice;
		
		/**
		 * Binds a function to an object. The returned function will always use the
		 * passed in {@code obj} as {@code this}.
		 *
		 * Example:
		 *
		 *   g = bind(f, obj, a, b)
		 *   g(c, d) // will do f.call(obj, a, b, c, d)
		 *
		 * @param {Function} f The function to bind the object to
		 * @param {Object} obj The object that should act as this when the function
		 *     is called
		 * @param {*} var_args Rest arguments that will be used as the initial
		 *     arguments when the function is called
		 * @return {Function} A new function that has bound this
		 */
		function bind(f, obj, var_args) {
			var a = slice.call(arguments, 2);
			return function () {
				return f.apply(obj, a.concat(slice.call(arguments)));
			};
		}
		
		function encodeHtmlAttribute(s) {
			return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
		}
		
		function addNamespacesAndStylesheet(doc) {
			// create xmlns
			if (!doc.namespaces['g_vml_']) {
				doc.namespaces.add('g_vml_', 'urn:schemas-microsoft-com:vml',
					'#default#VML');
				
			}
			if (!doc.namespaces['g_o_']) {
				doc.namespaces.add('g_o_', 'urn:schemas-microsoft-com:office:office',
					'#default#VML');
			}
			
			// Setup default CSS.  Only add one style sheet per document
			if (!doc.styleSheets['ex_canvas_']) {
				var ss = doc.createStyleSheet();
				ss.owningElement.id = 'ex_canvas_';
				ss.cssText = 'canvas{display:inline-block;overflow:hidden;' +
					// default size is 300x150 in Gecko and Opera
					'text-align:left;width:300px;height:150px}';
			}
		}
		
		// Add namespaces and stylesheet at startup.
		addNamespacesAndStylesheet(document);
		
		var G_vmlCanvasManager_ = {
			init : function (opt_doc) {
				if (/MSIE/.test(navigator.userAgent) && !window.opera) {
					var doc = opt_doc || document;
					// Create a dummy element so that IE will allow canvas elements to be
					// recognized.
					doc.createElement('canvas');
					doc.attachEvent('onreadystatechange', bind(this.init_, this, doc));
				}
			},
			
			init_ : function (doc) {
				// find all canvas elements
				var els = doc.getElementsByTagName('canvas');
				for (var i = 0; i < els.length; i++) {
					this.initElement(els[i]);
				}
			},
			
			/**
			 * Public initializes a canvas element so that it can be used as canvas
			 * element from now on. This is called automatically before the page is
			 * loaded but if you are creating elements using createElement you need to
			 * make sure this is called on the element.
			 * @param {HTMLElement} el The canvas element to initialize.
			 * @return {HTMLElement} the element that was created.
			 */
			initElement : function (el) {
				if (!el.getContext) {
					el.getContext = getContext;
					
					// Add namespaces and stylesheet to document of the element.
					addNamespacesAndStylesheet(el.ownerDocument);
					
					// Remove fallback content. There is no way to hide text nodes so we
					// just remove all childNodes. We could hide all elements and remove
					// text nodes but who really cares about the fallback content.
					el.innerHTML = '';
					
					// do not use inline function because that will leak memory
					el.attachEvent('onpropertychange', onPropertyChange);
					el.attachEvent('onresize', onResize);
					
					var attrs = el.attributes;
					if (attrs.width && attrs.width.specified) {
						// TODO: use runtimeStyle and coordsize
						// el.getContext().setWidth_(attrs.width.nodeValue);
						el.style.width = attrs.width.nodeValue + 'px';
					} else {
						el.width = el.clientWidth;
					}
					if (attrs.height && attrs.height.specified) {
						// TODO: use runtimeStyle and coordsize
						// el.getContext().setHeight_(attrs.height.nodeValue);
						el.style.height = attrs.height.nodeValue + 'px';
					} else {
						el.height = el.clientHeight;
					}
					//el.getContext().setCoordsize_()
				}
				return el;
			}
		};
		
		function onPropertyChange(e) {
			var el = e.srcElement;
			
			switch (e.propertyName) {
			case 'width':
				el.getContext().clearRect();
				el.style.width = el.attributes.width.nodeValue + 'px';
				// In IE8 this does not trigger onresize.
				el.firstChild.style.width = el.clientWidth + 'px';
				break;
			case 'height':
				el.getContext().clearRect();
				el.style.height = el.attributes.height.nodeValue + 'px';
				el.firstChild.style.height = el.clientHeight + 'px';
				break;
			}
		}
		
		function onResize(e) {
			var el = e.srcElement;
			if (el.firstChild) {
				el.firstChild.style.width = el.clientWidth + 'px';
				el.firstChild.style.height = el.clientHeight + 'px';
			}
		}
		
		G_vmlCanvasManager_.init();
		
		// precompute "00" to "FF"
		var decToHex = [];
		for (var i = 0; i < 16; i++) {
			for (var j = 0; j < 16; j++) {
				decToHex[i * 16 + j] = i.toString(16) + j.toString(16);
			}
		}
		
		function createMatrixIdentity() {
			return [
				[1, 0, 0],
				[0, 1, 0],
				[0, 0, 1]
			];
		}
		
		function matrixMultiply(m1, m2) {
			var result = createMatrixIdentity();
			
			for (var x = 0; x < 3; x++) {
				for (var y = 0; y < 3; y++) {
					var sum = 0;
					
					for (var z = 0; z < 3; z++) {
						sum += m1[x][z] * m2[z][y];
					}
					
					result[x][y] = sum;
				}
			}
			return result;
		}
		
		function copyState(o1, o2) {
			o2.fillStyle = o1.fillStyle;
			o2.lineCap = o1.lineCap;
			o2.lineJoin = o1.lineJoin;
			o2.lineWidth = o1.lineWidth;
			o2.miterLimit = o1.miterLimit;
			o2.shadowBlur = o1.shadowBlur;
			o2.shadowColor = o1.shadowColor;
			o2.shadowOffsetX = o1.shadowOffsetX;
			o2.shadowOffsetY = o1.shadowOffsetY;
			o2.strokeStyle = o1.strokeStyle;
			o2.globalAlpha = o1.globalAlpha;
			o2.font = o1.font;
			o2.textAlign = o1.textAlign;
			o2.textBaseline = o1.textBaseline;
			o2.arcScaleX_ = o1.arcScaleX_;
			o2.arcScaleY_ = o1.arcScaleY_;
			o2.lineScale_ = o1.lineScale_;
		}
		
		var colorData = {
			aliceblue : '#F0F8FF',
			antiquewhite : '#FAEBD7',
			aquamarine : '#7FFFD4',
			azure : '#F0FFFF',
			beige : '#F5F5DC',
			bisque : '#FFE4C4',
			black : '#000000',
			blanchedalmond : '#FFEBCD',
			blueviolet : '#8A2BE2',
			brown : '#A52A2A',
			burlywood : '#DEB887',
			cadetblue : '#5F9EA0',
			chartreuse : '#7FFF00',
			chocolate : '#D2691E',
			coral : '#FF7F50',
			cornflowerblue : '#6495ED',
			cornsilk : '#FFF8DC',
			crimson : '#DC143C',
			cyan : '#00FFFF',
			darkblue : '#00008B',
			darkcyan : '#008B8B',
			darkgoldenrod : '#B8860B',
			darkgray : '#A9A9A9',
			darkgreen : '#006400',
			darkgrey : '#A9A9A9',
			darkkhaki : '#BDB76B',
			darkmagenta : '#8B008B',
			darkolivegreen : '#556B2F',
			darkorange : '#FF8C00',
			darkorchid : '#9932CC',
			darkred : '#8B0000',
			darksalmon : '#E9967A',
			darkseagreen : '#8FBC8F',
			darkslateblue : '#483D8B',
			darkslategray : '#2F4F4F',
			darkslategrey : '#2F4F4F',
			darkturquoise : '#00CED1',
			darkviolet : '#9400D3',
			deeppink : '#FF1493',
			deepskyblue : '#00BFFF',
			dimgray : '#696969',
			dimgrey : '#696969',
			dodgerblue : '#1E90FF',
			firebrick : '#B22222',
			floralwhite : '#FFFAF0',
			forestgreen : '#228B22',
			gainsboro : '#DCDCDC',
			ghostwhite : '#F8F8FF',
			gold : '#FFD700',
			goldenrod : '#DAA520',
			grey : '#808080',
			greenyellow : '#ADFF2F',
			honeydew : '#F0FFF0',
			hotpink : '#FF69B4',
			indianred : '#CD5C5C',
			indigo : '#4B0082',
			ivory : '#FFFFF0',
			khaki : '#F0E68C',
			lavender : '#E6E6FA',
			lavenderblush : '#FFF0F5',
			lawngreen : '#7CFC00',
			lemonchiffon : '#FFFACD',
			lightblue : '#ADD8E6',
			lightcoral : '#F08080',
			lightcyan : '#E0FFFF',
			lightgoldenrodyellow : '#FAFAD2',
			lightgreen : '#90EE90',
			lightgrey : '#D3D3D3',
			lightpink : '#FFB6C1',
			lightsalmon : '#FFA07A',
			lightseagreen : '#20B2AA',
			lightskyblue : '#87CEFA',
			lightslategray : '#778899',
			lightslategrey : '#778899',
			lightsteelblue : '#B0C4DE',
			lightyellow : '#FFFFE0',
			limegreen : '#32CD32',
			linen : '#FAF0E6',
			magenta : '#FF00FF',
			mediumaquamarine : '#66CDAA',
			mediumblue : '#0000CD',
			mediumorchid : '#BA55D3',
			mediumpurple : '#9370DB',
			mediumseagreen : '#3CB371',
			mediumslateblue : '#7B68EE',
			mediumspringgreen : '#00FA9A',
			mediumturquoise : '#48D1CC',
			mediumvioletred : '#C71585',
			midnightblue : '#191970',
			mintcream : '#F5FFFA',
			mistyrose : '#FFE4E1',
			moccasin : '#FFE4B5',
			navajowhite : '#FFDEAD',
			oldlace : '#FDF5E6',
			olivedrab : '#6B8E23',
			orange : '#FFA500',
			orangered : '#FF4500',
			orchid : '#DA70D6',
			palegoldenrod : '#EEE8AA',
			palegreen : '#98FB98',
			paleturquoise : '#AFEEEE',
			palevioletred : '#DB7093',
			papayawhip : '#FFEFD5',
			peachpuff : '#FFDAB9',
			peru : '#CD853F',
			pink : '#FFC0CB',
			plum : '#DDA0DD',
			powderblue : '#B0E0E6',
			rosybrown : '#BC8F8F',
			royalblue : '#4169E1',
			saddlebrown : '#8B4513',
			salmon : '#FA8072',
			sandybrown : '#F4A460',
			seagreen : '#2E8B57',
			seashell : '#FFF5EE',
			sienna : '#A0522D',
			skyblue : '#87CEEB',
			slateblue : '#6A5ACD',
			slategray : '#708090',
			slategrey : '#708090',
			snow : '#FFFAFA',
			springgreen : '#00FF7F',
			steelblue : '#4682B4',
			tan : '#D2B48C',
			thistle : '#D8BFD8',
			tomato : '#FF6347',
			turquoise : '#40E0D0',
			violet : '#EE82EE',
			wheat : '#F5DEB3',
			whitesmoke : '#F5F5F5',
			yellowgreen : '#9ACD32'
		};
		
		function getRgbHslContent(styleString) {
			var start = styleString.indexOf('(', 3);
			var end = styleString.indexOf(')', start + 1);
			var parts = styleString.substring(start + 1, end).split(',');
			// add alpha if needed
			if (parts.length == 4 && styleString.substr(3, 1) == 'a') {
				alpha = Number(parts[3]);
			} else {
				parts[3] = 1;
			}
			return parts;
		}
		
		function percent(s) {
			return parseFloat(s) / 100;
		}
		
		function clamp(v, min, max) {
			return Math.min(max, Math.max(min, v));
		}
		
		function hslToRgb(parts) {
			var r,
			g,
			b;
			h = parseFloat(parts[0]) / 360 % 360;
			if (h < 0)
				h++;
			s = clamp(percent(parts[1]), 0, 1);
			l = clamp(percent(parts[2]), 0, 1);
			if (s == 0) {
				r = g = b = l; // achromatic
			} else {
				var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
				var p = 2 * l - q;
				r = hueToRgb(p, q, h + 1 / 3);
				g = hueToRgb(p, q, h);
				b = hueToRgb(p, q, h - 1 / 3);
			}
			
			return '#' + decToHex[Math.floor(r * 255)] +
			decToHex[Math.floor(g * 255)] +
			decToHex[Math.floor(b * 255)];
		}
		
		function hueToRgb(m1, m2, h) {
			if (h < 0)
				h++;
			if (h > 1)
				h--;
			
			if (6 * h < 1)
				return m1 + (m2 - m1) * 6 * h;
			else if (2 * h < 1)
				return m2;
			else if (3 * h < 2)
				return m1 + (m2 - m1) * (2 / 3 - h) * 6;
			else
				return m1;
		}
		
		function processStyle(styleString) {
			var str,
			alpha = 1;
			
			styleString = String(styleString);
			if (styleString.charAt(0) == '#') {
				str = styleString;
			} else if (/^rgb/.test(styleString)) {
				var parts = getRgbHslContent(styleString);
				var str = '#',
				n;
				for (var i = 0; i < 3; i++) {
					if (parts[i].indexOf('%') != -1) {
						n = Math.floor(percent(parts[i]) * 255);
					} else {
						n = Number(parts[i]);
					}
					str += decToHex[clamp(n, 0, 255)];
				}
				alpha = parts[3];
			} else if (/^hsl/.test(styleString)) {
				var parts = getRgbHslContent(styleString);
				str = hslToRgb(parts);
				alpha = parts[3];
			} else {
				str = colorData[styleString] || styleString;
			}
			return {
				color : str,
				alpha : alpha
			};
		}
		
		var DEFAULT_STYLE = {
			style : 'normal',
			variant : 'normal',
			weight : 'normal',
			size : 10,
			family : 'sans-serif'
		};
		
		// Internal text style cache
		var fontStyleCache = {};
		
		function processFontStyle(styleString) {
			if (fontStyleCache[styleString]) {
				return fontStyleCache[styleString];
			}
			
			var el = document.createElement('div');
			var style = el.style;
			try {
				style.font = styleString;
			} catch (ex) {
				// Ignore failures to set to invalid font.
			}
			
			return fontStyleCache[styleString] = {
				style : style.fontStyle || DEFAULT_STYLE.style,
				variant : style.fontVariant || DEFAULT_STYLE.variant,
				weight : style.fontWeight || DEFAULT_STYLE.weight,
				size : style.fontSize || DEFAULT_STYLE.size,
				family : style.fontFamily || DEFAULT_STYLE.family
			};
		}
		
		function getComputedStyle(style, element) {
			var computedStyle = {};
			
			for (var p in style) {
				computedStyle[p] = style[p];
			}
			
			// Compute the size
			var canvasFontSize = parseFloat(element.currentStyle.fontSize),
			fontSize = parseFloat(style.size);
			
			if (typeof style.size == 'number') {
				computedStyle.size = style.size;
			} else if (style.size.indexOf('px') != -1) {
				computedStyle.size = fontSize;
			} else if (style.size.indexOf('em') != -1) {
				computedStyle.size = canvasFontSize * fontSize;
			} else if (style.size.indexOf('%') != -1) {
				computedStyle.size = (canvasFontSize / 100) * fontSize;
			} else if (style.size.indexOf('pt') != -1) {
				computedStyle.size = fontSize / .75;
			} else {
				computedStyle.size = canvasFontSize;
			}
			
			// Different scaling between normal text and VML text. This was found using
			// trial and error to get the same size as non VML text.
			computedStyle.size *= 0.981;
			
			return computedStyle;
		}
		
		function buildStyle(style) {
			return style.style + ' ' + style.variant + ' ' + style.weight + ' ' +
			style.size + 'px ' + style.family;
		}
		
		function processLineCap(lineCap) {
			switch (lineCap) {
			case 'butt':
				return 'flat';
			case 'round':
				return 'round';
			case 'square':
			default:
				return 'square';
			}
		}
		
		/**
		 * This class implements CanvasRenderingContext2D interface as described by
		 * the WHATWG.
		 * @param {HTMLElement} surfaceElement The element that the 2D context should
		 * be associated with
		 */
		function CanvasRenderingContext2D_(surfaceElement) {
			this.m_ = createMatrixIdentity();
			
			this.mStack_ = [];
			this.aStack_ = [];
			this.currentPath_ = [];
			
			// Canvas context properties
			this.strokeStyle = '#000';
			this.fillStyle = '#000';
			
			this.lineWidth = 1;
			this.lineJoin = 'miter';
			this.lineCap = 'butt';
			this.miterLimit = Z * 1;
			this.globalAlpha = 1;
			this.font = '10px sans-serif';
			this.textAlign = 'left';
			this.textBaseline = 'alphabetic';
			this.canvas = surfaceElement;
			
			var el = surfaceElement.ownerDocument.createElement('div');
			el.style.width = surfaceElement.clientWidth + 'px';
			el.style.height = surfaceElement.clientHeight + 'px';
			el.style.overflow = 'hidden';
			el.style.position = 'absolute';
			surfaceElement.appendChild(el);
			
			this.element_ = el;
			this.arcScaleX_ = 1;
			this.arcScaleY_ = 1;
			this.lineScale_ = 1;
		}
		
		var contextPrototype = CanvasRenderingContext2D_.prototype;
		contextPrototype.clearRect = function () {
			if (this.textMeasureEl_) {
				this.textMeasureEl_.removeNode(true);
				this.textMeasureEl_ = null;
			}
			this.element_.innerHTML = '';
		};
		
		contextPrototype.beginPath = function () {
			// TODO: Branch current matrix so that save/restore has no effect
			//       as per safari docs.
			this.currentPath_ = [];
		};
		
		contextPrototype.moveTo = function (aX, aY) {
			var p = this.getCoords_(aX, aY);
			this.currentPath_.push({
				type : 'moveTo',
				x : p.x,
				y : p.y
			});
			this.currentX_ = p.x;
			this.currentY_ = p.y;
		};
		
		contextPrototype.lineTo = function (aX, aY) {
			var p = this.getCoords_(aX, aY);
			this.currentPath_.push({
				type : 'lineTo',
				x : p.x,
				y : p.y
			});
			
			this.currentX_ = p.x;
			this.currentY_ = p.y;
		};
		
		contextPrototype.bezierCurveTo = function (aCP1x, aCP1y,
			aCP2x, aCP2y,
			aX, aY) {
			var p = this.getCoords_(aX, aY);
			var cp1 = this.getCoords_(aCP1x, aCP1y);
			var cp2 = this.getCoords_(aCP2x, aCP2y);
			bezierCurveTo(this, cp1, cp2, p);
		};
		
		// Helper function that takes the already fixed cordinates.
		function bezierCurveTo(self, cp1, cp2, p) {
			self.currentPath_.push({
				type : 'bezierCurveTo',
				cp1x : cp1.x,
				cp1y : cp1.y,
				cp2x : cp2.x,
				cp2y : cp2.y,
				x : p.x,
				y : p.y
			});
			self.currentX_ = p.x;
			self.currentY_ = p.y;
		}
		
		contextPrototype.quadraticCurveTo = function (aCPx, aCPy, aX, aY) {
			// the following is lifted almost directly from
			// http://developer.mozilla.org/en/docs/Canvas_tutorial:Drawing_shapes
			
			var cp = this.getCoords_(aCPx, aCPy);
			var p = this.getCoords_(aX, aY);
			
			var cp1 = {
				x : this.currentX_ + 2.0 / 3.0 * (cp.x - this.currentX_),
				y : this.currentY_ + 2.0 / 3.0 * (cp.y - this.currentY_)
			};
			var cp2 = {
				x : cp1.x + (p.x - this.currentX_) / 3.0,
				y : cp1.y + (p.y - this.currentY_) / 3.0
			};
			
			bezierCurveTo(this, cp1, cp2, p);
		};
		
		contextPrototype.arc = function (aX, aY, aRadius,
			aStartAngle, aEndAngle, aClockwise) {
			aRadius *= Z;
			var arcType = aClockwise ? 'at' : 'wa';
			
			var xStart = aX + mc(aStartAngle) * aRadius - Z2;
			var yStart = aY + ms(aStartAngle) * aRadius - Z2;
			
			var xEnd = aX + mc(aEndAngle) * aRadius - Z2;
			var yEnd = aY + ms(aEndAngle) * aRadius - Z2;
			
			// IE won't render arches drawn counter clockwise if xStart == xEnd.
			if (xStart == xEnd && !aClockwise) {
				xStart += 0.125; // Offset xStart by 1/80 of a pixel. Use something
				// that can be represented in binary
			}
			
			var p = this.getCoords_(aX, aY);
			var pStart = this.getCoords_(xStart, yStart);
			var pEnd = this.getCoords_(xEnd, yEnd);
			
			this.currentPath_.push({
				type : arcType,
				x : p.x,
				y : p.y,
				radius : aRadius,
				xStart : pStart.x,
				yStart : pStart.y,
				xEnd : pEnd.x,
				yEnd : pEnd.y
			});
			
		};
		
		contextPrototype.rect = function (aX, aY, aWidth, aHeight) {
			this.moveTo(aX, aY);
			this.lineTo(aX + aWidth, aY);
			this.lineTo(aX + aWidth, aY + aHeight);
			this.lineTo(aX, aY + aHeight);
			this.closePath();
		};
		
		contextPrototype.strokeRect = function (aX, aY, aWidth, aHeight) {
			var oldPath = this.currentPath_;
			this.beginPath();
			
			this.moveTo(aX, aY);
			this.lineTo(aX + aWidth, aY);
			this.lineTo(aX + aWidth, aY + aHeight);
			this.lineTo(aX, aY + aHeight);
			this.closePath();
			this.stroke();
			
			this.currentPath_ = oldPath;
		};
		
		contextPrototype.fillRect = function (aX, aY, aWidth, aHeight) {
			var oldPath = this.currentPath_;
			this.beginPath();
			
			this.moveTo(aX, aY);
			this.lineTo(aX + aWidth, aY);
			this.lineTo(aX + aWidth, aY + aHeight);
			this.lineTo(aX, aY + aHeight);
			this.closePath();
			this.fill();
			
			this.currentPath_ = oldPath;
		};
		
		contextPrototype.createLinearGradient = function (aX0, aY0, aX1, aY1) {
			var gradient = new CanvasGradient_('gradient');
			gradient.x0_ = aX0;
			gradient.y0_ = aY0;
			gradient.x1_ = aX1;
			gradient.y1_ = aY1;
			return gradient;
		};
		
		contextPrototype.createRadialGradient = function (aX0, aY0, aR0,
			aX1, aY1, aR1) {
			var gradient = new CanvasGradient_('gradientradial');
			gradient.x0_ = aX0;
			gradient.y0_ = aY0;
			gradient.r0_ = aR0;
			gradient.x1_ = aX1;
			gradient.y1_ = aY1;
			gradient.r1_ = aR1;
			return gradient;
		};
		
		contextPrototype.drawImage = function (image, var_args) {
			var dx,
			dy,
			dw,
			dh,
			sx,
			sy,
			sw,
			sh;
			
			// to find the original width we overide the width and height
			var oldRuntimeWidth = image.runtimeStyle.width;
			var oldRuntimeHeight = image.runtimeStyle.height;
			image.runtimeStyle.width = 'auto';
			image.runtimeStyle.height = 'auto';
			
			// get the original size
			var w = image.width;
			var h = image.height;
			
			// and remove overides
			image.runtimeStyle.width = oldRuntimeWidth;
			image.runtimeStyle.height = oldRuntimeHeight;
			
			if (arguments.length == 3) {
				dx = arguments[1];
				dy = arguments[2];
				sx = sy = 0;
				sw = dw = w;
				sh = dh = h;
			} else if (arguments.length == 5) {
				dx = arguments[1];
				dy = arguments[2];
				dw = arguments[3];
				dh = arguments[4];
				sx = sy = 0;
				sw = w;
				sh = h;
			} else if (arguments.length == 9) {
				sx = arguments[1];
				sy = arguments[2];
				sw = arguments[3];
				sh = arguments[4];
				dx = arguments[5];
				dy = arguments[6];
				dw = arguments[7];
				dh = arguments[8];
			} else {
				throw Error('Invalid number of arguments');
			}
			
			var d = this.getCoords_(dx, dy);
			
			var w2 = sw / 2;
			var h2 = sh / 2;
			
			var vmlStr = [];
			
			var W = 10;
			var H = 10;
			
			// For some reason that I've now forgotten, using divs didn't work
			vmlStr.push(' <g_vml_:group',
				' coordsize="', Z * W, ',', Z * H, '"',
				' coordorigin="0,0"',
				' style="width:', W, 'px;height:', H, 'px;position:absolute;');
			
			// If filters are necessary (rotation exists), create them
			// filters are bog-slow, so only create them if abbsolutely necessary
			// The following check doesn't account for skews (which don't exist
			// in the canvas spec (yet) anyway.
			
			if (this.m_[0][0] != 1 || this.m_[0][1] ||
				this.m_[1][1] != 1 || this.m_[1][0]) {
				var filter = [];
				
				// Note the 12/21 reversal
				filter.push('M11=', this.m_[0][0], ',',
					'M12=', this.m_[1][0], ',',
					'M21=', this.m_[0][1], ',',
					'M22=', this.m_[1][1], ',',
					'Dx=', mr(d.x / Z), ',',
					'Dy=', mr(d.y / Z), '');
				
				// Bounding box calculation (need to minimize displayed area so that
				// filters don't waste time on unused pixels.
				var max = d;
				var c2 = this.getCoords_(dx + dw, dy);
				var c3 = this.getCoords_(dx, dy + dh);
				var c4 = this.getCoords_(dx + dw, dy + dh);
				
				max.x = m.max(max.x, c2.x, c3.x, c4.x);
				max.y = m.max(max.y, c2.y, c3.y, c4.y);
				
				vmlStr.push('padding:0 ', mr(max.x / Z), 'px ', mr(max.y / Z),
					'px 0;filter:progid:DXImageTransform.Microsoft.Matrix(',
					filter.join(''), ", sizingmethod='clip');");
				
			} else {
				vmlStr.push('top:', mr(d.y / Z), 'px;left:', mr(d.x / Z), 'px;');
			}
			
			vmlStr.push(' ">',
				'<g_vml_:image src="', image.src, '"',
				' style="width:', Z * dw, 'px;',
				' height:', Z * dh, 'px"',
				' cropleft="', sx / w, '"',
				' croptop="', sy / h, '"',
				' cropright="', (w - sx - sw) / w, '"',
				' cropbottom="', (h - sy - sh) / h, '"',
				' />',
				'</g_vml_:group>');
			
			this.element_.insertAdjacentHTML('BeforeEnd', vmlStr.join(''));
		};
		
		contextPrototype.stroke = function (aFill) {
			var W = 10;
			var H = 10;
			// Divide the shape into chunks if it's too long because IE has a limit
			// somewhere for how long a VML shape can be. This simple division does
			// not work with fills, only strokes, unfortunately.
			var chunkSize = 5000;
			
			var min = {
				x : null,
				y : null
			};
			var max = {
				x : null,
				y : null
			};
			
			for (var j = 0; j < this.currentPath_.length; j += chunkSize) {
				var lineStr = [];
				var lineOpen = false;
				
				lineStr.push('<g_vml_:shape',
					' filled="', !!aFill, '"',
					' style="position:absolute;width:', W, 'px;height:', H, 'px;"',
					' coordorigin="0,0"',
					' coordsize="', Z * W, ',', Z * H, '"',
					' stroked="', !aFill, '"',
					' path="');
				
				var newSeq = false;
				
				for (var i = j; i < Math.min(j + chunkSize, this.currentPath_.length); i++) {
					if (i % chunkSize == 0 && i > 0) { // move into position for next chunk
						lineStr.push(' m ', mr(this.currentPath_[i - 1].x), ',', mr(this.currentPath_[i - 1].y));
					}
					
					var p = this.currentPath_[i];
					var c;
					
					switch (p.type) {
					case 'moveTo':
						c = p;
						lineStr.push(' m ', mr(p.x), ',', mr(p.y));
						break;
					case 'lineTo':
						lineStr.push(' l ', mr(p.x), ',', mr(p.y));
						break;
					case 'close':
						lineStr.push(' x ');
						p = null;
						break;
					case 'bezierCurveTo':
						lineStr.push(' c ',
							mr(p.cp1x), ',', mr(p.cp1y), ',',
							mr(p.cp2x), ',', mr(p.cp2y), ',',
							mr(p.x), ',', mr(p.y));
						break;
					case 'at':
					case 'wa':
						lineStr.push(' ', p.type, ' ',
							mr(p.x - this.arcScaleX_ * p.radius), ',',
							mr(p.y - this.arcScaleY_ * p.radius), ' ',
							mr(p.x + this.arcScaleX_ * p.radius), ',',
							mr(p.y + this.arcScaleY_ * p.radius), ' ',
							mr(p.xStart), ',', mr(p.yStart), ' ',
							mr(p.xEnd), ',', mr(p.yEnd));
						break;
					}
					
					// TODO: Following is broken for curves due to
					//       move to proper paths.
					
					// Figure out dimensions so we can do gradient fills
					// properly
					if (p) {
						if (min.x == null || p.x < min.x) {
							min.x = p.x;
						}
						if (max.x == null || p.x > max.x) {
							max.x = p.x;
						}
						if (min.y == null || p.y < min.y) {
							min.y = p.y;
						}
						if (max.y == null || p.y > max.y) {
							max.y = p.y;
						}
					}
				}
				lineStr.push(' ">');
				
				if (!aFill) {
					appendStroke(this, lineStr);
				} else {
					appendFill(this, lineStr, min, max);
				}
				
				lineStr.push('</g_vml_:shape>');
				
				this.element_.insertAdjacentHTML('beforeEnd', lineStr.join(''));
			}
		};
		
		function appendStroke(ctx, lineStr) {
			var a = processStyle(ctx.strokeStyle);
			var color = a.color;
			var opacity = a.alpha * ctx.globalAlpha;
			var lineWidth = ctx.lineScale_ * ctx.lineWidth;
			
			// VML cannot correctly render a line if the width is less than 1px.
			// In that case, we dilute the color to make the line look thinner.
			if (lineWidth < 1) {
				opacity *= lineWidth;
			}
			
			lineStr.push(
				'<g_vml_:stroke',
				' opacity="', opacity, '"',
				' joinstyle="', ctx.lineJoin, '"',
				' miterlimit="', ctx.miterLimit, '"',
				' endcap="', processLineCap(ctx.lineCap), '"',
				' weight="', lineWidth, 'px"',
				' color="', color, '" />');
		}
		
		function appendFill(ctx, lineStr, min, max) {
			var fillStyle = ctx.fillStyle;
			var arcScaleX = ctx.arcScaleX_;
			var arcScaleY = ctx.arcScaleY_;
			var width = max.x - min.x;
			var height = max.y - min.y;
			if (fillStyle instanceof CanvasGradient_) {
				// TODO: Gradients transformed with the transformation matrix.
				var angle = 0;
				var focus = {
					x : 0,
					y : 0
				};
				
				// additional offset
				var shift = 0;
				// scale factor for offset
				var expansion = 1;
				
				if (fillStyle.type_ == 'gradient') {
					var x0 = fillStyle.x0_ / arcScaleX;
					var y0 = fillStyle.y0_ / arcScaleY;
					var x1 = fillStyle.x1_ / arcScaleX;
					var y1 = fillStyle.y1_ / arcScaleY;
					var p0 = ctx.getCoords_(x0, y0);
					var p1 = ctx.getCoords_(x1, y1);
					var dx = p1.x - p0.x;
					var dy = p1.y - p0.y;
					angle = Math.atan2(dx, dy) * 180 / Math.PI;
					
					// The angle should be a non-negative number.
					if (angle < 0) {
						angle += 360;
					}
					
					// Very small angles produce an unexpected result because they are
					// converted to a scientific notation string.
					if (angle < 1e-6) {
						angle = 0;
					}
				} else {
					var p0 = ctx.getCoords_(fillStyle.x0_, fillStyle.y0_);
					focus = {
						x : (p0.x - min.x) / width,
						y : (p0.y - min.y) / height
					};
					
					width /= arcScaleX * Z;
					height /= arcScaleY * Z;
					var dimension = m.max(width, height);
					shift = 2 * fillStyle.r0_ / dimension;
					expansion = 2 * fillStyle.r1_ / dimension - shift;
				}
				
				// We need to sort the color stops in ascending order by offset,
				// otherwise IE won't interpret it correctly.
				var stops = fillStyle.colors_;
				stops.sort(function (cs1, cs2) {
					return cs1.offset - cs2.offset;
				});
				
				var length = stops.length;
				var color1 = stops[0].color;
				var color2 = stops[length - 1].color;
				var opacity1 = stops[0].alpha * ctx.globalAlpha;
				var opacity2 = stops[length - 1].alpha * ctx.globalAlpha;
				
				var colors = [];
				for (var i = 0; i < length; i++) {
					var stop = stops[i];
					colors.push(stop.offset * expansion + shift + ' ' + stop.color);
				}
				
				// When colors attribute is used, the meanings of opacity and o:opacity2
				// are reversed.
				lineStr.push('<g_vml_:fill type="', fillStyle.type_, '"',
					' method="none" focus="100%"',
					' color="', color1, '"',
					' color2="', color2, '"',
					' colors="', colors.join(','), '"',
					' opacity="', opacity2, '"',
					' g_o_:opacity2="', opacity1, '"',
					' angle="', angle, '"',
					' focusposition="', focus.x, ',', focus.y, '" />');
			} else if (fillStyle instanceof CanvasPattern_) {
				if (width && height) {
					var deltaLeft = -min.x;
					var deltaTop = -min.y;
					lineStr.push('<g_vml_:fill',
						' position="',
						deltaLeft / width * arcScaleX * arcScaleX, ',',
						deltaTop / height * arcScaleY * arcScaleY, '"',
						' type="tile"',
						// TODO: Figure out the correct size to fit the scale.
						//' size="', w, 'px ', h, 'px"',
						' src="', fillStyle.src_, '" />');
				}
			} else {
				var a = processStyle(ctx.fillStyle);
				var color = a.color;
				var opacity = a.alpha * ctx.globalAlpha;
				lineStr.push('<g_vml_:fill color="', color, '" opacity="', opacity,
					'" />');
			}
		}
		
		contextPrototype.fill = function () {
			this.stroke(true);
		};
		
		contextPrototype.closePath = function () {
			this.currentPath_.push({
				type : 'close'
			});
		};
		
		/**
		 * @private
		 */
		contextPrototype.getCoords_ = function (aX, aY) {
			var m = this.m_;
			return {
				x : Z * (aX * m[0][0] + aY * m[1][0] + m[2][0]) - Z2,
				y : Z * (aX * m[0][1] + aY * m[1][1] + m[2][1]) - Z2
			};
		};
		
		contextPrototype.save = function () {
			var o = {};
			copyState(this, o);
			this.aStack_.push(o);
			this.mStack_.push(this.m_);
			this.m_ = matrixMultiply(createMatrixIdentity(), this.m_);
		};
		
		contextPrototype.restore = function () {
			if (this.aStack_.length) {
				copyState(this.aStack_.pop(), this);
				this.m_ = this.mStack_.pop();
			}
		};
		
		function matrixIsFinite(m) {
			return isFinite(m[0][0]) && isFinite(m[0][1]) &&
			isFinite(m[1][0]) && isFinite(m[1][1]) &&
			isFinite(m[2][0]) && isFinite(m[2][1]);
		}
		
		function setM(ctx, m, updateLineScale) {
			if (!matrixIsFinite(m)) {
				return;
			}
			ctx.m_ = m;
			
			if (updateLineScale) {
				// Get the line scale.
				// Determinant of this.m_ means how much the area is enlarged by the
				// transformation. So its square root can be used as a scale factor
				// for width.
				var det = m[0][0] * m[1][1] - m[0][1] * m[1][0];
				ctx.lineScale_ = sqrt(abs(det));
			}
		}
		
		contextPrototype.translate = function (aX, aY) {
			var m1 = [
				[1, 0, 0],
				[0, 1, 0],
				[aX, aY, 1]
			];
			
			setM(this, matrixMultiply(m1, this.m_), false);
		};
		
		contextPrototype.rotate = function (aRot) {
			var c = mc(aRot);
			var s = ms(aRot);
			
			var m1 = [
				[c, s, 0],
				[-s, c, 0],
				[0, 0, 1]
			];
			
			setM(this, matrixMultiply(m1, this.m_), false);
		};
		
		contextPrototype.scale = function (aX, aY) {
			this.arcScaleX_ *= aX;
			this.arcScaleY_ *= aY;
			var m1 = [
				[aX, 0, 0],
				[0, aY, 0],
				[0, 0, 1]
			];
			
			setM(this, matrixMultiply(m1, this.m_), true);
		};
		
		contextPrototype.transform = function (m11, m12, m21, m22, dx, dy) {
			var m1 = [
				[m11, m12, 0],
				[m21, m22, 0],
				[dx, dy, 1]
			];
			
			setM(this, matrixMultiply(m1, this.m_), true);
		};
		
		contextPrototype.setTransform = function (m11, m12, m21, m22, dx, dy) {
			var m = [
				[m11, m12, 0],
				[m21, m22, 0],
				[dx, dy, 1]
			];
			
			setM(this, m, true);
		};
		
		/**
		 * The text drawing function.
		 * The maxWidth argument isn't taken in account, since no browser supports
		 * it yet.
		 */
		contextPrototype.drawText_ = function (text, x, y, maxWidth, stroke) {
			var m = this.m_,
			delta = 1000,
			left = 0,
			right = delta,
			offset = {
				x : 0,
				y : 0
			},
			lineStr = [];
			
			var fontStyle = getComputedStyle(processFontStyle(this.font),
					this.element_);
			
			var fontStyleString = buildStyle(fontStyle);
			
			var elementStyle = this.element_.currentStyle;
			var textAlign = this.textAlign.toLowerCase();
			switch (textAlign) {
			case 'left':
			case 'center':
			case 'right':
				break;
			case 'end':
				textAlign = elementStyle.direction == 'ltr' ? 'right' : 'left';
				break;
			case 'start':
				textAlign = elementStyle.direction == 'rtl' ? 'right' : 'left';
				break;
			default:
				textAlign = 'left';
			}
			
			// 1.75 is an arbitrary number, as there is no info about the text baseline
			switch (this.textBaseline) {
			case 'hanging':
			case 'top':
				offset.y = fontStyle.size / 1.75;
				break;
			case 'middle':
				break;
			default:
			case null:
			case 'alphabetic':
			case 'ideographic':
			case 'bottom':
				offset.y = -fontStyle.size / 2.25;
				break;
			}
			
			switch (textAlign) {
			case 'right':
				left = delta;
				right = 0.05;
				break;
			case 'center':
				left = right = delta / 2;
				break;
			}
			
			var d = this.getCoords_(x + offset.x, y + offset.y);
			
			lineStr.push('<g_vml_:line from="', -left, ' 0" to="', right, ' 0.05" ',
				' coordsize="100 100" coordorigin="0 0"',
				' filled="', !stroke, '" stroked="', !!stroke,
				'" style="position:absolute;width:1px;height:1px;">');
			
			if (stroke) {
				appendStroke(this, lineStr);
			} else {
				// TODO: Fix the min and max params.
				appendFill(this, lineStr, {
					x : -left,
					y : 0
				}, {
					x : right,
					y : fontStyle.size
				});
			}
			
			var skewM = m[0][0].toFixed(3) + ',' + m[1][0].toFixed(3) + ',' +
				m[0][1].toFixed(3) + ',' + m[1][1].toFixed(3) + ',0,0';
			
			var skewOffset = mr(d.x / Z) + ',' + mr(d.y / Z);
			
			lineStr.push('<g_vml_:skew on="t" matrix="', skewM, '" ',
				' offset="', skewOffset, '" origin="', left, ' 0" />',
				'<g_vml_:path textpathok="true" />',
				'<g_vml_:textpath on="true" string="',
				encodeHtmlAttribute(text),
				'" style="v-text-align:', textAlign,
				';font:', encodeHtmlAttribute(fontStyleString),
				'" /></g_vml_:line>');
			
			this.element_.insertAdjacentHTML('beforeEnd', lineStr.join(''));
		};
		
		contextPrototype.fillText = function (text, x, y, maxWidth) {
			this.drawText_(text, x, y, maxWidth, false);
		};
		
		contextPrototype.strokeText = function (text, x, y, maxWidth) {
			this.drawText_(text, x, y, maxWidth, true);
		};
		
		contextPrototype.measureText = function (text) {
			if (!this.textMeasureEl_) {
				var s = '<span style="position:absolute;' +
					'top:-20000px;left:0;padding:0;margin:0;border:none;' +
					'white-space:pre;"></span>';
				this.element_.insertAdjacentHTML('beforeEnd', s);
				this.textMeasureEl_ = this.element_.lastChild;
			}
			var doc = this.element_.ownerDocument;
			this.textMeasureEl_.innerHTML = '';
			this.textMeasureEl_.style.font = this.font;
			// Don't use innerHTML or innerText because they allow markup/whitespace.
			this.textMeasureEl_.appendChild(doc.createTextNode(text));
			return {
				width : this.textMeasureEl_.offsetWidth
			};
		};
		
		/******** STUBS ********/
		contextPrototype.clip = function () {
			// TODO: Implement
		};
		
		contextPrototype.arcTo = function () {
			// TODO: Implement
		};
		
		contextPrototype.createPattern = function (image, repetition) {
			return new CanvasPattern_(image, repetition);
		};
		
		// Gradient / Pattern Stubs
		function CanvasGradient_(aType) {
			this.type_ = aType;
			this.x0_ = 0;
			this.y0_ = 0;
			this.r0_ = 0;
			this.x1_ = 0;
			this.y1_ = 0;
			this.r1_ = 0;
			this.colors_ = [];
		}
		
		CanvasGradient_.prototype.addColorStop = function (aOffset, aColor) {
			aColor = processStyle(aColor);
			this.colors_.push({
				offset : aOffset,
				color : aColor.color,
				alpha : aColor.alpha
			});
		};
		
		function CanvasPattern_(image, repetition) {
			assertImageIsValid(image);
			switch (repetition) {
			case 'repeat':
			case null:
			case '':
				this.repetition_ = 'repeat';
				break
			case 'repeat-x':
			case 'repeat-y':
			case 'no-repeat':
				this.repetition_ = repetition;
				break;
			default:
				throwException('SYNTAX_ERR');
			}
			
			this.src_ = image.src;
			this.width_ = image.width;
			this.height_ = image.height;
		}
		
		function throwException(s) {
			throw new DOMException_(s);
		}
		
		function assertImageIsValid(img) {
			if (!img || img.nodeType != 1 || img.tagName != 'IMG') {
				throwException('TYPE_MISMATCH_ERR');
			}
			if (img.readyState != 'complete') {
				throwException('INVALID_STATE_ERR');
			}
		}
		
		function DOMException_(s) {
			this.code = this[s];
			this.message = s + ': DOM Exception ' + this.code;
		}
		var p = DOMException_.prototype = new Error;
		p.INDEX_SIZE_ERR = 1;
		p.DOMSTRING_SIZE_ERR = 2;
		p.HIERARCHY_REQUEST_ERR = 3;
		p.WRONG_DOCUMENT_ERR = 4;
		p.INVALID_CHARACTER_ERR = 5;
		p.NO_DATA_ALLOWED_ERR = 6;
		p.NO_MODIFICATION_ALLOWED_ERR = 7;
		p.NOT_FOUND_ERR = 8;
		p.NOT_SUPPORTED_ERR = 9;
		p.INUSE_ATTRIBUTE_ERR = 10;
		p.INVALID_STATE_ERR = 11;
		p.SYNTAX_ERR = 12;
		p.INVALID_MODIFICATION_ERR = 13;
		p.NAMESPACE_ERR = 14;
		p.INVALID_ACCESS_ERR = 15;
		p.VALIDATION_ERR = 16;
		p.TYPE_MISMATCH_ERR = 17;
		
		// set up externs
		G_vmlCanvasManager = G_vmlCanvasManager_;
		CanvasRenderingContext2D = CanvasRenderingContext2D_;
		CanvasGradient = CanvasGradient_;
		CanvasPattern = CanvasPattern_;
		DOMException = DOMException_;
	})();
	
} // if

/* Javascript plotting library for jQuery, v. 0.7.
 *
 * Released under the MIT license by IOLA, December 2007.
 *
 */

// first an inline dependency, jquery.colorhelpers.js, we inline it here
// for convenience

/* Plugin for jQuery for working with colors.
 *
 * Version 1.1.
 *
 * Inspiration from jQuery color animation plugin by John Resig.
 *
 * Released under the MIT license by Ole Laursen, October 2009.
 *
 * Examples:
 *
 *   $.color.parse("#fff").scale('rgb', 0.25).add('a', -0.5).toString()
 *   var c = $.color.extract($("#mydiv"), 'background-color');
 *   console.log(c.r, c.g, c.b, c.a);
 *   $.color.make(100, 50, 25, 0.4).toString() // returns "rgba(100,50,25,0.4)"
 *
 * Note that .scale() and .add() return the same modified object
 * instead of making a new one.
 *
 * V. 1.1: Fix error handling so e.g. parsing an empty string does
 * produce a color rather than just crashing.
 */
(function (B) {
	B.color = {};
	B.color.make = function (F, E, C, D) {
		var G = {};
		G.r = F || 0;
		G.g = E || 0;
		G.b = C || 0;
		G.a = D != null ? D : 1;
		G.add = function (J, I) {
			for (var H = 0; H < J.length; ++H) {
				G[J.charAt(H)] += I
			}
			return G.normalize()
		};
		G.scale = function (J, I) {
			for (var H = 0; H < J.length; ++H) {
				G[J.charAt(H)] *= I
			}
			return G.normalize()
		};
		G.toString = function () {
			if (G.a >= 1) {
				return "rgb(" + [G.r, G.g, G.b].join(",") + ")"
			} else {
				return "rgba(" + [G.r, G.g, G.b, G.a].join(",") + ")"
			}
		};
		G.normalize = function () {
			function H(J, K, I) {
				return K < J ? J : (K > I ? I : K)
			}
			G.r = H(0, parseInt(G.r), 255);
			G.g = H(0, parseInt(G.g), 255);
			G.b = H(0, parseInt(G.b), 255);
			G.a = H(0, G.a, 1);
			return G
		};
		G.clone = function () {
			return B.color.make(G.r, G.b, G.g, G.a)
		};
		return G.normalize()
	};
	B.color.extract = function (D, C) {
		var E;
		do {
			E = D.css(C).toLowerCase();
			if (E != "" && E != "transparent") {
				break
			}
			D = D.parent()
		} while (!B.nodeName(D.get(0), "body"));
		if (E == "rgba(0, 0, 0, 0)") {
			E = "transparent"
		}
		return B.color.parse(E)
	};
	B.color.parse = function (F) {
		var E,
		C = B.color.make;
		if (E = /rgb\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*\)/.exec(F)) {
			return C(parseInt(E[1], 10), parseInt(E[2], 10), parseInt(E[3], 10))
		}
		if (E = /rgba\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]+(?:\.[0-9]+)?)\s*\)/.exec(F)) {
			return C(parseInt(E[1], 10), parseInt(E[2], 10), parseInt(E[3], 10), parseFloat(E[4]))
		}
		if (E = /rgb\(\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*\)/.exec(F)) {
			return C(parseFloat(E[1]) * 2.55, parseFloat(E[2]) * 2.55, parseFloat(E[3]) * 2.55)
		}
		if (E = /rgba\(\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\s*\)/.exec(F)) {
			return C(parseFloat(E[1]) * 2.55, parseFloat(E[2]) * 2.55, parseFloat(E[3]) * 2.55, parseFloat(E[4]))
		}
		if (E = /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec(F)) {
			return C(parseInt(E[1], 16), parseInt(E[2], 16), parseInt(E[3], 16))
		}
		if (E = /#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/.exec(F)) {
			return C(parseInt(E[1] + E[1], 16), parseInt(E[2] + E[2], 16), parseInt(E[3] + E[3], 16))
		}
		var D = B.trim(F).toLowerCase();
		if (D == "transparent") {
			return C(255, 255, 255, 0)
		} else {
			E = A[D] || [0, 0, 0];
			return C(E[0], E[1], E[2])
		}
	};
	var A = {
		aqua : [0, 255, 255],
		azure : [240, 255, 255],
		beige : [245, 245, 220],
		black : [0, 0, 0],
		blue : [0, 0, 255],
		brown : [165, 42, 42],
		cyan : [0, 255, 255],
		darkblue : [0, 0, 139],
		darkcyan : [0, 139, 139],
		darkgrey : [169, 169, 169],
		darkgreen : [0, 100, 0],
		darkkhaki : [189, 183, 107],
		darkmagenta : [139, 0, 139],
		darkolivegreen : [85, 107, 47],
		darkorange : [255, 140, 0],
		darkorchid : [153, 50, 204],
		darkred : [139, 0, 0],
		darksalmon : [233, 150, 122],
		darkviolet : [148, 0, 211],
		fuchsia : [255, 0, 255],
		gold : [255, 215, 0],
		green : [0, 128, 0],
		indigo : [75, 0, 130],
		khaki : [240, 230, 140],
		lightblue : [173, 216, 230],
		lightcyan : [224, 255, 255],
		lightgreen : [144, 238, 144],
		lightgrey : [211, 211, 211],
		lightpink : [255, 182, 193],
		lightyellow : [255, 255, 224],
		lime : [0, 255, 0],
		magenta : [255, 0, 255],
		maroon : [128, 0, 0],
		navy : [0, 0, 128],
		olive : [128, 128, 0],
		orange : [255, 165, 0],
		pink : [255, 192, 203],
		purple : [128, 0, 128],
		violet : [128, 0, 128],
		red : [255, 0, 0],
		silver : [192, 192, 192],
		white : [255, 255, 255],
		yellow : [255, 255, 0]
	}
})(jQuery);

// the actual Flot code
(function ($) {
	function Plot(placeholder, data_, options_, plugins) {
		// data is on the form:
		//   [ series1, series2 ... ]
		// where series is either just the data as [ [x1, y1], [x2, y2], ... ]
		// or { data: [ [x1, y1], [x2, y2], ... ], label: "some label", ... }
		
		var series = [],
		options = {
			// the color theme used for graphs
			colors : ["#edc240", "#afd8f8", "#cb4b4b", "#4da74d", "#9440ed"],
			legend : {
				show : true,
				noColumns : 1, // number of colums in legend table
				labelFormatter : null, // fn: string -> string
				labelBoxBorderColor : "#ccc", // border color for the little label boxes
				container : null, // container (as jQuery object) to put legend in, null means default on top of graph
				position : "ne", // position of default legend container within plot
				margin : 5, // distance from grid edge to default legend container within plot
				backgroundColor : null, // null means auto-detect
				backgroundOpacity : 0.85 // set to 0 to avoid background
			},
			xaxis : {
				show : null, // null = auto-detect, true = always, false = never
				position : "bottom", // or "top"
				mode : null, // null or "time"
				color : null, // base color, labels, ticks
				tickColor : null, // possibly different color of ticks, e.g. "rgba(0,0,0,0.15)"
				transform : null, // null or f: number -> number to transform axis
				inverseTransform : null, // if transform is set, this should be the inverse function
				min : null, // min. value to show, null means set automatically
				max : null, // max. value to show, null means set automatically
				autoscaleMargin : null, // margin in % to add if auto-setting min/max
				ticks : null, // either [1, 3] or [[1, "a"], 3] or (fn: axis info -> ticks) or app. number of ticks for auto-ticks
				tickFormatter : null, // fn: number -> string
				labelWidth : null, // size of tick labels in pixels
				labelHeight : null,
				reserveSpace : null, // whether to reserve space even if axis isn't shown
				tickLength : null, // size in pixels of ticks, or "full" for whole line
				alignTicksWithAxis : null, // axis number or null for no sync
				
				// mode specific options
				tickDecimals : null, // no. of decimals, null means auto
				tickSize : null, // number or [number, "unit"]
				minTickSize : null, // number or [number, "unit"]
				monthNames : null, // list of names of months
				timeformat : null, // format string to use
				twelveHourClock : false // 12 or 24 time in time mode
			},
			yaxis : {
				autoscaleMargin : 0.02,
				position : "left" // or "right"
			},
			xaxes : [],
			yaxes : [],
			series : {
				points : {
					show : false,
					radius : 3,
					lineWidth : 2, // in pixels
					fill : true,
					fillColor : "#ffffff",
					symbol : "circle" // or callback
				},
				lines : {
					// we don't put in show: false so we can see
					// whether lines were actively disabled
					lineWidth : 2, // in pixels
					fill : false,
					fillColor : null,
					steps : false
				},
				bars : {
					show : false,
					lineWidth : 2, // in pixels
					barWidth : 1, // in units of the x axis
					fill : true,
					fillColor : null,
					align : "left", // or "center"
					horizontal : false
				},
				shadowSize : 3
			},
			grid : {
				show : true,
				aboveData : false,
				color : "#545454", // primary color used for outline and labels
				backgroundColor : null, // null for transparent, else color
				borderColor : null, // set if different from the grid color
				tickColor : null, // color for the ticks, e.g. "rgba(0,0,0,0.15)"
				labelMargin : 5, // in pixels
				axisMargin : 8, // in pixels
				borderWidth : 2, // in pixels
				minBorderMargin : null, // in pixels, null means taken from points radius
				markings : null, // array of ranges or fn: axes -> array of ranges
				markingsColor : "#f4f4f4",
				markingsLineWidth : 2,
				// interactive stuff
				clickable : false,
				hoverable : false,
				autoHighlight : true, // highlight in case mouse is near
				mouseActiveRadius : 10 // how far the mouse can be away to activate an item
			},
			hooks : {}
		},
		canvas = null, // the canvas for the plot itself
		overlay = null, // canvas for interactive stuff on top of plot
		eventHolder = null, // jQuery object that events should be bound to
		ctx = null,
		octx = null,
		xaxes = [],
		yaxes = [],
		plotOffset = {
			left : 0,
			right : 0,
			top : 0,
			bottom : 0
		},
		canvasWidth = 0,
		canvasHeight = 0,
		plotWidth = 0,
		plotHeight = 0,
		hooks = {
			processOptions : [],
			processRawData : [],
			processDatapoints : [],
			drawSeries : [],
			draw : [],
			bindEvents : [],
			drawOverlay : [],
			shutdown : []
		},
		plot = this;
		
		// public functions
		plot.setData = setData;
		plot.setupGrid = setupGrid;
		plot.draw = draw;
		plot.getPlaceholder = function () {
			return placeholder;
		};
		plot.getCanvas = function () {
			return canvas;
		};
		plot.getPlotOffset = function () {
			return plotOffset;
		};
		plot.width = function () {
			return plotWidth;
		};
		plot.height = function () {
			return plotHeight;
		};
		plot.offset = function () {
			var o = eventHolder.offset();
			o.left += plotOffset.left;
			o.top += plotOffset.top;
			return o;
		};
		plot.getData = function () {
			return series;
		};
		plot.getAxes = function () {
			var res = {},
			i;
			$.each(xaxes.concat(yaxes), function (_, axis) {
				if (axis)
					res[axis.direction + (axis.n != 1 ? axis.n : "") + "axis"] = axis;
			});
			return res;
		};
		plot.getXAxes = function () {
			return xaxes;
		};
		plot.getYAxes = function () {
			return yaxes;
		};
		plot.c2p = canvasToAxisCoords;
		plot.p2c = axisToCanvasCoords;
		plot.getOptions = function () {
			return options;
		};
		plot.highlight = highlight;
		plot.unhighlight = unhighlight;
		plot.triggerRedrawOverlay = triggerRedrawOverlay;
		plot.pointOffset = function (point) {
			return {
				left : parseInt(xaxes[axisNumber(point, "x") - 1].p2c(+point.x) + plotOffset.left),
				top : parseInt(yaxes[axisNumber(point, "y") - 1].p2c(+point.y) + plotOffset.top)
			};
		};
		plot.shutdown = shutdown;
		plot.resize = function () {
			getCanvasDimensions();
			resizeCanvas(canvas);
			resizeCanvas(overlay);
		};
		
		// public attributes
		plot.hooks = hooks;
		
		// initialize
		initPlugins(plot);
		parseOptions(options_);
		setupCanvases();
		setData(data_);
		setupGrid();
		draw();
		bindEvents();
		
		function executeHooks(hook, args) {
			args = [plot].concat(args);
			for (var i = 0; i < hook.length; ++i)
				hook[i].apply(this, args);
		}
		
		function initPlugins() {
			for (var i = 0; i < plugins.length; ++i) {
				var p = plugins[i];
				p.init(plot);
				if (p.options)
					$.extend(true, options, p.options);
			}
		}
		
		function parseOptions(opts) {
			var i;
			
			$.extend(true, options, opts);
			
			if (options.xaxis.color == null)
				options.xaxis.color = options.grid.color;
			if (options.yaxis.color == null)
				options.yaxis.color = options.grid.color;
			
			if (options.xaxis.tickColor == null) // backwards-compatibility
				options.xaxis.tickColor = options.grid.tickColor;
			if (options.yaxis.tickColor == null) // backwards-compatibility
				options.yaxis.tickColor = options.grid.tickColor;
			
			if (options.grid.borderColor == null)
				options.grid.borderColor = options.grid.color;
			if (options.grid.tickColor == null)
				options.grid.tickColor = $.color.parse(options.grid.color).scale('a', 0.22).toString();
			
			// fill in defaults in axes, copy at least always the
			// first as the rest of the code assumes it'll be there
			for (i = 0; i < Math.max(1, options.xaxes.length); ++i)
				options.xaxes[i] = $.extend(true, {}, options.xaxis, options.xaxes[i]);
			for (i = 0; i < Math.max(1, options.yaxes.length); ++i)
				options.yaxes[i] = $.extend(true, {}, options.yaxis, options.yaxes[i]);
			
			// backwards compatibility, to be removed in future
			if (options.xaxis.noTicks && options.xaxis.ticks == null)
				options.xaxis.ticks = options.xaxis.noTicks;
			if (options.yaxis.noTicks && options.yaxis.ticks == null)
				options.yaxis.ticks = options.yaxis.noTicks;
			if (options.x2axis) {
				options.xaxes[1] = $.extend(true, {}, options.xaxis, options.x2axis);
				options.xaxes[1].position = "top";
			}
			if (options.y2axis) {
				options.yaxes[1] = $.extend(true, {}, options.yaxis, options.y2axis);
				options.yaxes[1].position = "right";
			}
			if (options.grid.coloredAreas)
				options.grid.markings = options.grid.coloredAreas;
			if (options.grid.coloredAreasColor)
				options.grid.markingsColor = options.grid.coloredAreasColor;
			if (options.lines)
				$.extend(true, options.series.lines, options.lines);
			if (options.points)
				$.extend(true, options.series.points, options.points);
			if (options.bars)
				$.extend(true, options.series.bars, options.bars);
			if (options.shadowSize != null)
				options.series.shadowSize = options.shadowSize;
			
			// save options on axes for future reference
			for (i = 0; i < options.xaxes.length; ++i)
				getOrCreateAxis(xaxes, i + 1).options = options.xaxes[i];
			for (i = 0; i < options.yaxes.length; ++i)
				getOrCreateAxis(yaxes, i + 1).options = options.yaxes[i];
			
			// add hooks from options
			for (var n in hooks)
				if (options.hooks[n] && options.hooks[n].length)
					hooks[n] = hooks[n].concat(options.hooks[n]);
			
			executeHooks(hooks.processOptions, [options]);
		}
		
		function setData(d) {
			series = parseData(d);
			fillInSeriesOptions();
			processData();
		}
		
		function parseData(d) {
			var res = [];
			for (var i = 0; i < d.length; ++i) {
				var s = $.extend(true, {}, options.series);
				
				if (d[i].data != null) {
					s.data = d[i].data; // move the data instead of deep-copy
					delete d[i].data;
					
					$.extend(true, s, d[i]);
					
					d[i].data = s.data;
				} else
					s.data = d[i];
				res.push(s);
			}
			
			return res;
		}
		
		function axisNumber(obj, coord) {
			var a = obj[coord + "axis"];
			if (typeof a == "object") // if we got a real axis, extract number
				a = a.n;
			if (typeof a != "number")
				a = 1; // default to first axis
			return a;
		}
		
		function allAxes() {
			// return flat array without annoying null entries
			return $.grep(xaxes.concat(yaxes), function (a) {
				return a;
			});
		}
		
		function canvasToAxisCoords(pos) {
			// return an object with x/y corresponding to all used axes
			var res = {},
			i,
			axis;
			for (i = 0; i < xaxes.length; ++i) {
				axis = xaxes[i];
				if (axis && axis.used)
					res["x" + axis.n] = axis.c2p(pos.left);
			}
			
			for (i = 0; i < yaxes.length; ++i) {
				axis = yaxes[i];
				if (axis && axis.used)
					res["y" + axis.n] = axis.c2p(pos.top);
			}
			
			if (res.x1 !== undefined)
				res.x = res.x1;
			if (res.y1 !== undefined)
				res.y = res.y1;
			
			return res;
		}
		
		function axisToCanvasCoords(pos) {
			// get canvas coords from the first pair of x/y found in pos
			var res = {},
			i,
			axis,
			key;
			
			for (i = 0; i < xaxes.length; ++i) {
				axis = xaxes[i];
				if (axis && axis.used) {
					key = "x" + axis.n;
					if (pos[key] == null && axis.n == 1)
						key = "x";
					
					if (pos[key] != null) {
						res.left = axis.p2c(pos[key]);
						break;
					}
				}
			}
			
			for (i = 0; i < yaxes.length; ++i) {
				axis = yaxes[i];
				if (axis && axis.used) {
					key = "y" + axis.n;
					if (pos[key] == null && axis.n == 1)
						key = "y";
					
					if (pos[key] != null) {
						res.top = axis.p2c(pos[key]);
						break;
					}
				}
			}
			
			return res;
		}
		
		function getOrCreateAxis(axes, number) {
			if (!axes[number - 1])
				axes[number - 1] = {
					n : number, // save the number for future reference
					direction : axes == xaxes ? "x" : "y",
					options : $.extend(true, {}, axes == xaxes ? options.xaxis : options.yaxis)
				};
			
			return axes[number - 1];
		}
		
		function fillInSeriesOptions() {
			var i;
			
			// collect what we already got of colors
			var neededColors = series.length,
			usedColors = [],
			assignedColors = [];
			for (i = 0; i < series.length; ++i) {
				var sc = series[i].color;
				if (sc != null) {
					--neededColors;
					if (typeof sc == "number")
						assignedColors.push(sc);
					else
						usedColors.push($.color.parse(series[i].color));
				}
			}
			
			// we might need to generate more colors if higher indices
			// are assigned
			for (i = 0; i < assignedColors.length; ++i) {
				neededColors = Math.max(neededColors, assignedColors[i] + 1);
			}
			
			// produce colors as needed
			var colors = [],
			variation = 0;
			i = 0;
			while (colors.length < neededColors) {
				var c;
				if (options.colors.length == i) // check degenerate case
					c = $.color.make(100, 100, 100);
				else
					c = $.color.parse(options.colors[i]);
				
				// vary color if needed
				var sign = variation % 2 == 1 ? -1 : 1;
				c.scale('rgb', 1 + sign * Math.ceil(variation / 2) * 0.2)
				
				// FIXME: if we're getting to close to something else,
				// we should probably skip this one
				colors.push(c);
				
				++i;
				if (i >= options.colors.length) {
					i = 0;
					++variation;
				}
			}
			
			// fill in the options
			var colori = 0,
			s;
			for (i = 0; i < series.length; ++i) {
				s = series[i];
				
				// assign colors
				if (s.color == null) {
					s.color = colors[colori].toString();
					++colori;
				} else if (typeof s.color == "number")
					s.color = colors[s.color].toString();
				
				// turn on lines automatically in case nothing is set
				if (s.lines.show == null) {
					var v,
					show = true;
					for (v in s)
						if (s[v] && s[v].show) {
							show = false;
							break;
						}
					if (show)
						s.lines.show = true;
				}
				
				// setup axes
				s.xaxis = getOrCreateAxis(xaxes, axisNumber(s, "x"));
				s.yaxis = getOrCreateAxis(yaxes, axisNumber(s, "y"));
			}
		}
		
		function processData() {
			var topSentry = Number.POSITIVE_INFINITY,
			bottomSentry = Number.NEGATIVE_INFINITY,
			fakeInfinity = Number.MAX_VALUE,
			i,
			j,
			k,
			m,
			length,
			s,
			points,
			ps,
			x,
			y,
			axis,
			val,
			f,
			p;
			
			function updateAxis(axis, min, max) {
				if (min < axis.datamin && min != -fakeInfinity)
					axis.datamin = min;
				if (max > axis.datamax && max != fakeInfinity)
					axis.datamax = max;
			}
			
			$.each(allAxes(), function (_, axis) {
				// init axis
				axis.datamin = topSentry;
				axis.datamax = bottomSentry;
				axis.used = false;
			});
			
			for (i = 0; i < series.length; ++i) {
				s = series[i];
				s.datapoints = {
					points : []
				};
				
				executeHooks(hooks.processRawData, [s, s.data, s.datapoints]);
			}
			
			// first pass: clean and copy data
			for (i = 0; i < series.length; ++i) {
				s = series[i];
				
				var data = s.data,
				format = s.datapoints.format;
				
				if (!format) {
					format = [];
					// find out how to copy
					format.push({
						x : true,
						number : true,
						required : true
					});
					format.push({
						y : true,
						number : true,
						required : true
					});
					
					if (s.bars.show || (s.lines.show && s.lines.fill)) {
						format.push({
							y : true,
							number : true,
							required : false,
							defaultValue : 0
						});
						if (s.bars.horizontal) {
							delete format[format.length - 1].y;
							format[format.length - 1].x = true;
						}
					}
					
					s.datapoints.format = format;
				}
				
				if (s.datapoints.pointsize != null)
					continue; // already filled in
				
				s.datapoints.pointsize = format.length;
				
				ps = s.datapoints.pointsize;
				points = s.datapoints.points;
				
				insertSteps = s.lines.show && s.lines.steps;
				s.xaxis.used = s.yaxis.used = true;
				
				for (j = k = 0; j < data.length; ++j, k += ps) {
					p = data[j];
					
					var nullify = p == null;
					if (!nullify) {
						for (m = 0; m < ps; ++m) {
							val = p[m];
							f = format[m];
							
							if (f) {
								if (f.number && val != null) {
									val = +val; // convert to number
									if (isNaN(val))
										val = null;
									else if (val == Infinity)
										val = fakeInfinity;
									else if (val == -Infinity)
										val = -fakeInfinity;
								}
								
								if (val == null) {
									if (f.required)
										nullify = true;
									
									if (f.defaultValue != null)
										val = f.defaultValue;
								}
							}
							
							points[k + m] = val;
						}
					}
					
					if (nullify) {
						for (m = 0; m < ps; ++m) {
							val = points[k + m];
							if (val != null) {
								f = format[m];
								// extract min/max info
								if (f.x)
									updateAxis(s.xaxis, val, val);
								if (f.y)
									updateAxis(s.yaxis, val, val);
							}
							points[k + m] = null;
						}
					} else {
						// a little bit of line specific stuff that
						// perhaps shouldn't be here, but lacking
						// better means...
						if (insertSteps && k > 0
							 && points[k - ps] != null
							 && points[k - ps] != points[k]
							 && points[k - ps + 1] != points[k + 1]) {
							// copy the point to make room for a middle point
							for (m = 0; m < ps; ++m)
								points[k + ps + m] = points[k + m];
							
							// middle point has same y
							points[k + 1] = points[k - ps + 1];
							
							// we've added a point, better reflect that
							k += ps;
						}
					}
				}
			}
			
			// give the hooks a chance to run
			for (i = 0; i < series.length; ++i) {
				s = series[i];
				
				executeHooks(hooks.processDatapoints, [s, s.datapoints]);
			}
			
			// second pass: find datamax/datamin for auto-scaling
			for (i = 0; i < series.length; ++i) {
				s = series[i];
				points = s.datapoints.points,
				ps = s.datapoints.pointsize;
				
				var xmin = topSentry,
				ymin = topSentry,
				xmax = bottomSentry,
				ymax = bottomSentry;
				
				for (j = 0; j < points.length; j += ps) {
					if (points[j] == null)
						continue;
					
					for (m = 0; m < ps; ++m) {
						val = points[j + m];
						f = format[m];
						if (!f || val == fakeInfinity || val == -fakeInfinity)
							continue;
						
						if (f.x) {
							if (val < xmin)
								xmin = val;
							if (val > xmax)
								xmax = val;
						}
						if (f.y) {
							if (val < ymin)
								ymin = val;
							if (val > ymax)
								ymax = val;
						}
					}
				}
				
				if (s.bars.show) {
					// make sure we got room for the bar on the dancing floor
					var delta = s.bars.align == "left" ? 0 : -s.bars.barWidth / 2;
					if (s.bars.horizontal) {
						ymin += delta;
						ymax += delta + s.bars.barWidth;
					} else {
						xmin += delta;
						xmax += delta + s.bars.barWidth;
					}
				}
				
				updateAxis(s.xaxis, xmin, xmax);
				updateAxis(s.yaxis, ymin, ymax);
			}
			
			$.each(allAxes(), function (_, axis) {
				if (axis.datamin == topSentry)
					axis.datamin = null;
				if (axis.datamax == bottomSentry)
					axis.datamax = null;
			});
		}
		
		function makeCanvas(skipPositioning, cls) {
			var c = document.createElement('canvas');
			c.className = cls;
			c.width = canvasWidth;
			c.height = canvasHeight;
			
			if (!skipPositioning)
				$(c).css({
					position : 'absolute',
					left : 0,
					top : 0
				});
			
			$(c).appendTo(placeholder);
			
			if (!c.getContext) // excanvas hack
				c = window.G_vmlCanvasManager.initElement(c);
			
			// used for resetting in case we get replotted
			c.getContext("2d").save();
			
			return c;
		}
		
		function getCanvasDimensions() {
			canvasWidth = placeholder.width();
			canvasHeight = placeholder.height();
			
			if (canvasWidth <= 0 || canvasHeight <= 0)
				throw "Invalid dimensions for plot, width = " + canvasWidth + ", height = " + canvasHeight;
		}
		
		function resizeCanvas(c) {
			// resizing should reset the state (excanvas seems to be
			// buggy though)
			if (c.width != canvasWidth)
				c.width = canvasWidth;
			
			if (c.height != canvasHeight)
				c.height = canvasHeight;
			
			// so try to get back to the initial state (even if it's
			// gone now, this should be safe according to the spec)
			var cctx = c.getContext("2d");
			cctx.restore();
			
			// and save again
			cctx.save();
		}
		
		function setupCanvases() {
			var reused,
			existingCanvas = placeholder.children("canvas.base"),
			existingOverlay = placeholder.children("canvas.overlay");
			
			if (existingCanvas.length == 0 || existingOverlay == 0) {
				// init everything
				
				placeholder.html(""); // make sure placeholder is clear
				
				placeholder.css({
					padding : 0
				}); // padding messes up the positioning
				
				if (placeholder.css("position") == 'static')
					placeholder.css("position", "relative"); // for positioning labels and overlay
				
				getCanvasDimensions();
				
				canvas = makeCanvas(true, "base");
				overlay = makeCanvas(false, "overlay"); // overlay canvas for interactive features
				
				reused = false;
			} else {
				// reuse existing elements
				
				canvas = existingCanvas.get(0);
				overlay = existingOverlay.get(0);
				
				reused = true;
			}
			
			ctx = canvas.getContext("2d");
			octx = overlay.getContext("2d");
			
			// we include the canvas in the event holder too, because IE 7
			// sometimes has trouble with the stacking order
			eventHolder = $([overlay, canvas]);
			
			if (reused) {
				// run shutdown in the old plot object
				placeholder.data("plot").shutdown();
				
				// reset reused canvases
				plot.resize();
				
				// make sure overlay pixels are cleared (canvas is cleared when we redraw)
				octx.clearRect(0, 0, canvasWidth, canvasHeight);
				
				// then whack any remaining obvious garbage left
				eventHolder.unbind();
				placeholder.children().not([canvas, overlay]).remove();
			}
			
			// save in case we get replotted
			placeholder.data("plot", plot);
		}
		
		function bindEvents() {
			// bind events
			if (options.grid.hoverable) {
				eventHolder.mousemove(onMouseMove);
				eventHolder.mouseleave(onMouseLeave);
			}
			
			if (options.grid.clickable)
				eventHolder.click(onClick);
			
			executeHooks(hooks.bindEvents, [eventHolder]);
		}
		
		function shutdown() {
			if (redrawTimeout)
				clearTimeout(redrawTimeout);
			
			eventHolder.unbind("mousemove", onMouseMove);
			eventHolder.unbind("mouseleave", onMouseLeave);
			eventHolder.unbind("click", onClick);
			
			executeHooks(hooks.shutdown, [eventHolder]);
		}
		
		function setTransformationHelpers(axis) {
			// set helper functions on the axis, assumes plot area
			// has been computed already
			
			function identity(x) {
				return x;
			}
			
			var s,
			m,
			t = axis.options.transform || identity,
			it = axis.options.inverseTransform;
			
			// precompute how much the axis is scaling a point
			// in canvas space
			if (axis.direction == "x") {
				s = axis.scale = plotWidth / Math.abs(t(axis.max) - t(axis.min));
				m = Math.min(t(axis.max), t(axis.min));
			} else {
				s = axis.scale = plotHeight / Math.abs(t(axis.max) - t(axis.min));
				s = -s;
				m = Math.max(t(axis.max), t(axis.min));
			}
			
			// data point to canvas coordinate
			if (t == identity) // slight optimization
				axis.p2c = function (p) {
					return (p - m) * s;
				};
			else
				axis.p2c = function (p) {
					return (t(p) - m) * s;
				};
			// canvas coordinate to data point
			if (!it)
				axis.c2p = function (c) {
					return m + c / s;
				};
			else
				axis.c2p = function (c) {
					return it(m + c / s);
				};
		}
		
		function measureTickLabels(axis) {
			var opts = axis.options,
			i,
			ticks = axis.ticks || [],
			labels = [],
			l,
			w = opts.labelWidth,
			h = opts.labelHeight,
			dummyDiv;
			
			function makeDummyDiv(labels, width) {
				return $('<div style="position:absolute;top:-10000px;' + width + 'font-size:smaller">' +
					'<div class="' + axis.direction + 'Axis ' + axis.direction + axis.n + 'Axis">'
					 + labels.join("") + '</div></div>')
				.appendTo(placeholder);
			}
			
			if (axis.direction == "x") {
				// to avoid measuring the widths of the labels (it's slow), we
				// construct fixed-size boxes and put the labels inside
				// them, we don't need the exact figures and the
				// fixed-size box content is easy to center
				if (w == null)
					w = Math.floor(canvasWidth / (ticks.length > 0 ? ticks.length : 1));
				
				// measure x label heights
				if (h == null) {
					labels = [];
					for (i = 0; i < ticks.length; ++i) {
						l = ticks[i].label;
						if (l)
							labels.push('<div class="tickLabel" style="float:left;width:' + w + 'px">' + l + '</div>');
					}
					
					if (labels.length > 0) {
						// stick them all in the same div and measure
						// collective height
						labels.push('<div style="clear:left"></div>');
						dummyDiv = makeDummyDiv(labels, "width:10000px;");
						h = dummyDiv.height();
						dummyDiv.remove();
					}
				}
			} else if (w == null || h == null) {
				// calculate y label dimensions
				for (i = 0; i < ticks.length; ++i) {
					l = ticks[i].label;
					if (l)
						labels.push('<div class="tickLabel">' + l + '</div>');
				}
				
				if (labels.length > 0) {
					dummyDiv = makeDummyDiv(labels, "");
					if (w == null)
						w = dummyDiv.children().width();
					if (h == null)
						h = dummyDiv.find("div.tickLabel").height();
					dummyDiv.remove();
				}
			}
			
			if (w == null)
				w = 0;
			if (h == null)
				h = 0;
			
			axis.labelWidth = w;
			axis.labelHeight = h;
		}
		
		function allocateAxisBoxFirstPhase(axis) {
			// find the bounding box of the axis by looking at label
			// widths/heights and ticks, make room by diminishing the
			// plotOffset
			
			var lw = axis.labelWidth,
			lh = axis.labelHeight,
			pos = axis.options.position,
			tickLength = axis.options.tickLength,
			axismargin = options.grid.axisMargin,
			padding = options.grid.labelMargin,
			all = axis.direction == "x" ? xaxes : yaxes,
			index;
			
			// determine axis margin
			var samePosition = $.grep(all, function (a) {
					return a && a.options.position == pos && a.reserveSpace;
				});
			if ($.inArray(axis, samePosition) == samePosition.length - 1)
				axismargin = 0; // outermost
			
			// determine tick length - if we're innermost, we can use "full"
			if (tickLength == null)
				tickLength = "full";
			
			var sameDirection = $.grep(all, function (a) {
					return a && a.reserveSpace;
				});
			
			var innermost = $.inArray(axis, sameDirection) == 0;
			if (!innermost && tickLength == "full")
				tickLength = 5;
			
			if (!isNaN(+tickLength))
				padding += +tickLength;
			
			// compute box
			if (axis.direction == "x") {
				lh += padding;
				
				if (pos == "bottom") {
					plotOffset.bottom += lh + axismargin;
					axis.box = {
						top : canvasHeight - plotOffset.bottom,
						height : lh
					};
				} else {
					axis.box = {
						top : plotOffset.top + axismargin,
						height : lh
					};
					plotOffset.top += lh + axismargin;
				}
			} else {
				lw += padding;
				
				if (pos == "left") {
					axis.box = {
						left : plotOffset.left + axismargin,
						width : lw
					};
					plotOffset.left += lw + axismargin;
				} else {
					plotOffset.right += lw + axismargin;
					axis.box = {
						left : canvasWidth - plotOffset.right,
						width : lw
					};
				}
			}
			
			// save for future reference
			axis.position = pos;
			axis.tickLength = tickLength;
			axis.box.padding = padding;
			axis.innermost = innermost;
		}
		
		function allocateAxisBoxSecondPhase(axis) {
			// set remaining bounding box coordinates
			if (axis.direction == "x") {
				axis.box.left = plotOffset.left;
				axis.box.width = plotWidth;
			} else {
				axis.box.top = plotOffset.top;
				axis.box.height = plotHeight;
			}
		}
		
		function setupGrid() {
			var i,
			axes = allAxes();
			
			// first calculate the plot and axis box dimensions
			
			$.each(axes, function (_, axis) {
				axis.show = axis.options.show;
				if (axis.show == null)
					axis.show = axis.used; // by default an axis is visible if it's got data
				
				axis.reserveSpace = axis.show || axis.options.reserveSpace;
				
				setRange(axis);
			});
			
			allocatedAxes = $.grep(axes, function (axis) {
					return axis.reserveSpace;
				});
			
			plotOffset.left = plotOffset.right = plotOffset.top = plotOffset.bottom = 0;
			if (options.grid.show) {
				$.each(allocatedAxes, function (_, axis) {
					// make the ticks
					setupTickGeneration(axis);
					setTicks(axis);
					snapRangeToTicks(axis, axis.ticks);
					
					// find labelWidth/Height for axis
					measureTickLabels(axis);
				});
				
				// with all dimensions in house, we can compute the
				// axis boxes, start from the outside (reverse order)
				for (i = allocatedAxes.length - 1; i >= 0; --i)
					allocateAxisBoxFirstPhase(allocatedAxes[i]);
				
				// make sure we've got enough space for things that
				// might stick out
				var minMargin = options.grid.minBorderMargin;
				if (minMargin == null) {
					minMargin = 0;
					for (i = 0; i < series.length; ++i)
						minMargin = Math.max(minMargin, series[i].points.radius + series[i].points.lineWidth / 2);
				}
				
				for (var a in plotOffset) {
					plotOffset[a] += options.grid.borderWidth;
					plotOffset[a] = Math.max(minMargin, plotOffset[a]);
				}
			}
			
			plotWidth = canvasWidth - plotOffset.left - plotOffset.right;
			plotHeight = canvasHeight - plotOffset.bottom - plotOffset.top;
			
			// now we got the proper plotWidth/Height, we can compute the scaling
			$.each(axes, function (_, axis) {
				setTransformationHelpers(axis);
			});
			
			if (options.grid.show) {
				$.each(allocatedAxes, function (_, axis) {
					allocateAxisBoxSecondPhase(axis);
				});
				
				insertAxisLabels();
			}
			
			insertLegend();
		}
		
		function setRange(axis) {
			var opts = axis.options,
			min =  + (opts.min != null ? opts.min : axis.datamin),
			max =  + (opts.max != null ? opts.max : axis.datamax),
			delta = max - min;
			
			if (delta == 0.0) {
				// degenerate case
				var widen = max == 0 ? 1 : 0.01;
				
				if (opts.min == null)
					min -= widen;
				// always widen max if we couldn't widen min to ensure we
				// don't fall into min == max which doesn't work
				if (opts.max == null || opts.min != null)
					max += widen;
			} else {
				// consider autoscaling
				var margin = opts.autoscaleMargin;
				if (margin != null) {
					if (opts.min == null) {
						min -= delta * margin;
						// make sure we don't go below zero if all values
						// are positive
						if (min < 0 && axis.datamin != null && axis.datamin >= 0)
							min = 0;
					}
					if (opts.max == null) {
						max += delta * margin;
						if (max > 0 && axis.datamax != null && axis.datamax <= 0)
							max = 0;
					}
				}
			}
			axis.min = min;
			axis.max = max;
		}
		
		function setupTickGeneration(axis) {
			var opts = axis.options;
			
			// estimate number of ticks
			var noTicks;
			if (typeof opts.ticks == "number" && opts.ticks > 0)
				noTicks = opts.ticks;
			else
				// heuristic based on the model a*sqrt(x) fitted to
				// some data points that seemed reasonable
				noTicks = 0.3 * Math.sqrt(axis.direction == "x" ? canvasWidth : canvasHeight);
			
			var delta = (axis.max - axis.min) / noTicks,
			size,
			generator,
			unit,
			formatter,
			i,
			magn,
			norm;
			
			if (opts.mode == "time") {
				// pretty handling of time
				
				// map of app. size of time units in milliseconds
				var timeUnitSize = {
					"second" : 1000,
					"minute" : 60 * 1000,
					"hour" : 60 * 60 * 1000,
					"day" : 24 * 60 * 60 * 1000,
					"month" : 30 * 24 * 60 * 60 * 1000,
					"year" : 365.2425 * 24 * 60 * 60 * 1000
				};
				
				// the allowed tick sizes, after 1 year we use
				// an integer algorithm
				var spec = [
					[1, "second"], [2, "second"], [5, "second"], [10, "second"],
					[30, "second"],
					[1, "minute"], [2, "minute"], [5, "minute"], [10, "minute"],
					[30, "minute"],
					[1, "hour"], [2, "hour"], [4, "hour"],
					[8, "hour"], [12, "hour"],
					[1, "day"], [2, "day"], [3, "day"],
					[0.25, "month"], [0.5, "month"], [1, "month"],
					[2, "month"], [3, "month"], [6, "month"],
					[1, "year"]
				];
				
				var minSize = 0;
				if (opts.minTickSize != null) {
					if (typeof opts.tickSize == "number")
						minSize = opts.tickSize;
					else
						minSize = opts.minTickSize[0] * timeUnitSize[opts.minTickSize[1]];
				}
				
				for (var i = 0; i < spec.length - 1; ++i)
					if (delta < (spec[i][0] * timeUnitSize[spec[i][1]]
							 + spec[i + 1][0] * timeUnitSize[spec[i + 1][1]]) / 2
						 && spec[i][0] * timeUnitSize[spec[i][1]] >= minSize)
						break;
				size = spec[i][0];
				unit = spec[i][1];
				
				// special-case the possibility of several years
				if (unit == "year") {
					magn = Math.pow(10, Math.floor(Math.log(delta / timeUnitSize.year) / Math.LN10));
					norm = (delta / timeUnitSize.year) / magn;
					if (norm < 1.5)
						size = 1;
					else if (norm < 3)
						size = 2;
					else if (norm < 7.5)
						size = 5;
					else
						size = 10;
					
					size *= magn;
				}
				
				axis.tickSize = opts.tickSize || [size, unit];
				
				generator = function (axis) {
					var ticks = [],
					tickSize = axis.tickSize[0],
					unit = axis.tickSize[1],
					d = new Date(axis.min);
					
					var step = tickSize * timeUnitSize[unit];
					
					if (unit == "second")
						d.setUTCSeconds(floorInBase(d.getUTCSeconds(), tickSize));
					if (unit == "minute")
						d.setUTCMinutes(floorInBase(d.getUTCMinutes(), tickSize));
					if (unit == "hour")
						d.setUTCHours(floorInBase(d.getUTCHours(), tickSize));
					if (unit == "month")
						d.setUTCMonth(floorInBase(d.getUTCMonth(), tickSize));
					if (unit == "year")
						d.setUTCFullYear(floorInBase(d.getUTCFullYear(), tickSize));
					
					// reset smaller components
					d.setUTCMilliseconds(0);
					if (step >= timeUnitSize.minute)
						d.setUTCSeconds(0);
					if (step >= timeUnitSize.hour)
						d.setUTCMinutes(0);
					if (step >= timeUnitSize.day)
						d.setUTCHours(0);
					if (step >= timeUnitSize.day * 4)
						d.setUTCDate(1);
					if (step >= timeUnitSize.year)
						d.setUTCMonth(0);
					
					var carry = 0,
					v = Number.NaN,
					prev;
					do {
						prev = v;
						v = d.getTime();
						ticks.push(v);
						if (unit == "month") {
							if (tickSize < 1) {
								// a bit complicated - we'll divide the month
								// up but we need to take care of fractions
								// so we don't end up in the middle of a day
								d.setUTCDate(1);
								var start = d.getTime();
								d.setUTCMonth(d.getUTCMonth() + 1);
								var end = d.getTime();
								d.setTime(v + carry * timeUnitSize.hour + (end - start) * tickSize);
								carry = d.getUTCHours();
								d.setUTCHours(0);
							} else
								d.setUTCMonth(d.getUTCMonth() + tickSize);
						} else if (unit == "year") {
							d.setUTCFullYear(d.getUTCFullYear() + tickSize);
						} else
							d.setTime(v + step);
					} while (v < axis.max && v != prev);
					
					return ticks;
				};
				
				formatter = function (v, axis) {
					var d = new Date(v);
					
					// first check global format
					if (opts.timeformat != null)
						return $.plot.formatDate(d, opts.timeformat, opts.monthNames);
					
					var t = axis.tickSize[0] * timeUnitSize[axis.tickSize[1]];
					var span = axis.max - axis.min;
					var suffix = (opts.twelveHourClock) ? " %p" : "";
					
					if (t < timeUnitSize.minute)
						fmt = "%h:%M:%S" + suffix;
					else if (t < timeUnitSize.day) {
						if (span < 2 * timeUnitSize.day)
							fmt = "%h:%M" + suffix;
						else
							fmt = "%b %d %h:%M" + suffix;
					} else if (t < timeUnitSize.month)
						fmt = "%b %d";
					else if (t < timeUnitSize.year) {
						if (span < timeUnitSize.year)
							fmt = "%b";
						else
							fmt = "%b %y";
					} else
						fmt = "%y";
					
					return $.plot.formatDate(d, fmt, opts.monthNames);
				};
			} else {
				// pretty rounding of base-10 numbers
				var maxDec = opts.tickDecimals;
				var dec = -Math.floor(Math.log(delta) / Math.LN10);
				if (maxDec != null && dec > maxDec)
					dec = maxDec;
				
				magn = Math.pow(10, -dec);
				norm = delta / magn; // norm is between 1.0 and 10.0
				
				if (norm < 1.5)
					size = 1;
				else if (norm < 3) {
					size = 2;
					// special case for 2.5, requires an extra decimal
					if (norm > 2.25 && (maxDec == null || dec + 1 <= maxDec)) {
						size = 2.5;
						++dec;
					}
				} else if (norm < 7.5)
					size = 5;
				else
					size = 10;
				
				size *= magn;
				
				if (opts.minTickSize != null && size < opts.minTickSize)
					size = opts.minTickSize;
				
				axis.tickDecimals = Math.max(0, maxDec != null ? maxDec : dec);
				axis.tickSize = opts.tickSize || size;
				
				generator = function (axis) {
					var ticks = [];
					
					// spew out all possible ticks
					var start = floorInBase(axis.min, axis.tickSize),
					i = 0,
					v = Number.NaN,
					prev;
					do {
						prev = v;
						v = start + i * axis.tickSize;
						ticks.push(v);
						++i;
					} while (v < axis.max && v != prev);
					return ticks;
				};
				
				formatter = function (v, axis) {
					return v.toFixed(axis.tickDecimals);
				};
			}
			
			if (opts.alignTicksWithAxis != null) {
				var otherAxis = (axis.direction == "x" ? xaxes : yaxes)[opts.alignTicksWithAxis - 1];
				if (otherAxis && otherAxis.used && otherAxis != axis) {
					// consider snapping min/max to outermost nice ticks
					var niceTicks = generator(axis);
					if (niceTicks.length > 0) {
						if (opts.min == null)
							axis.min = Math.min(axis.min, niceTicks[0]);
						if (opts.max == null && niceTicks.length > 1)
							axis.max = Math.max(axis.max, niceTicks[niceTicks.length - 1]);
					}
					
					generator = function (axis) {
						// copy ticks, scaled to this axis
						var ticks = [],
						v,
						i;
						for (i = 0; i < otherAxis.ticks.length; ++i) {
							v = (otherAxis.ticks[i].v - otherAxis.min) / (otherAxis.max - otherAxis.min);
							v = axis.min + v * (axis.max - axis.min);
							ticks.push(v);
						}
						return ticks;
					};
					
					// we might need an extra decimal since forced
					// ticks don't necessarily fit naturally
					if (axis.mode != "time" && opts.tickDecimals == null) {
						var extraDec = Math.max(0, -Math.floor(Math.log(delta) / Math.LN10) + 1),
						ts = generator(axis);
						
						// only proceed if the tick interval rounded
						// with an extra decimal doesn't give us a
						// zero at end
						if (!(ts.length > 1 && /\..*0$/.test((ts[1] - ts[0]).toFixed(extraDec))))
							axis.tickDecimals = extraDec;
					}
				}
			}
			
			axis.tickGenerator = generator;
			if ($.isFunction(opts.tickFormatter))
				axis.tickFormatter = function (v, axis) {
					return "" + opts.tickFormatter(v, axis);
				};
			else
				axis.tickFormatter = formatter;
		}
		
		function setTicks(axis) {
			var oticks = axis.options.ticks,
			ticks = [];
			if (oticks == null || (typeof oticks == "number" && oticks > 0))
				ticks = axis.tickGenerator(axis);
			else if (oticks) {
				if ($.isFunction(oticks))
					// generate the ticks
					ticks = oticks({
							min : axis.min,
							max : axis.max
						});
				else
					ticks = oticks;
			}
			
			// clean up/labelify the supplied ticks, copy them over
			var i,
			v;
			axis.ticks = [];
			for (i = 0; i < ticks.length; ++i) {
				var label = null;
				var t = ticks[i];
				if (typeof t == "object") {
					v = +t[0];
					if (t.length > 1)
						label = t[1];
				} else
					v = +t;
				if (label == null)
					label = axis.tickFormatter(v, axis);
				if (!isNaN(v))
					axis.ticks.push({
						v : v,
						label : label
					});
			}
		}
		
		function snapRangeToTicks(axis, ticks) {
			if (axis.options.autoscaleMargin && ticks.length > 0) {
				// snap to ticks
				if (axis.options.min == null)
					axis.min = Math.min(axis.min, ticks[0].v);
				if (axis.options.max == null && ticks.length > 1)
					axis.max = Math.max(axis.max, ticks[ticks.length - 1].v);
			}
		}
		
		function draw() {
			ctx.clearRect(0, 0, canvasWidth, canvasHeight);
			
			var grid = options.grid;
			
			// draw background, if any
			if (grid.show && grid.backgroundColor)
				drawBackground();
			
			if (grid.show && !grid.aboveData)
				drawGrid();
			
			for (var i = 0; i < series.length; ++i) {
				executeHooks(hooks.drawSeries, [ctx, series[i]]);
				drawSeries(series[i]);
			}
			
			executeHooks(hooks.draw, [ctx]);
			
			if (grid.show && grid.aboveData)
				drawGrid();
		}
		
		function extractRange(ranges, coord) {
			var axis,
			from,
			to,
			key,
			axes = allAxes();
			
			for (i = 0; i < axes.length; ++i) {
				axis = axes[i];
				if (axis.direction == coord) {
					key = coord + axis.n + "axis";
					if (!ranges[key] && axis.n == 1)
						key = coord + "axis"; // support x1axis as xaxis
					if (ranges[key]) {
						from = ranges[key].from;
						to = ranges[key].to;
						break;
					}
				}
			}
			
			// backwards-compat stuff - to be removed in future
			if (!ranges[key]) {
				axis = coord == "x" ? xaxes[0] : yaxes[0];
				from = ranges[coord + "1"];
				to = ranges[coord + "2"];
			}
			
			// auto-reverse as an added bonus
			if (from != null && to != null && from > to) {
				var tmp = from;
				from = to;
				to = tmp;
			}
			
			return {
				from : from,
				to : to,
				axis : axis
			};
		}
		
		function drawBackground() {
			ctx.save();
			ctx.translate(plotOffset.left, plotOffset.top);
			
			ctx.fillStyle = getColorOrGradient(options.grid.backgroundColor, plotHeight, 0, "rgba(255, 255, 255, 0)");
			ctx.fillRect(0, 0, plotWidth, plotHeight);
			ctx.restore();
		}
		
		function drawGrid() {
			var i;
			
			ctx.save();
			ctx.translate(plotOffset.left, plotOffset.top);
			
			// draw markings
			var markings = options.grid.markings;
			if (markings) {
				if ($.isFunction(markings)) {
					var axes = plot.getAxes();
					// xmin etc. is backwards compatibility, to be
					// removed in the future
					axes.xmin = axes.xaxis.min;
					axes.xmax = axes.xaxis.max;
					axes.ymin = axes.yaxis.min;
					axes.ymax = axes.yaxis.max;
					
					markings = markings(axes);
				}
				
				for (i = 0; i < markings.length; ++i) {
					var m = markings[i],
					xrange = extractRange(m, "x"),
					yrange = extractRange(m, "y");
					
					// fill in missing
					if (xrange.from == null)
						xrange.from = xrange.axis.min;
					if (xrange.to == null)
						xrange.to = xrange.axis.max;
					if (yrange.from == null)
						yrange.from = yrange.axis.min;
					if (yrange.to == null)
						yrange.to = yrange.axis.max;
					
					// clip
					if (xrange.to < xrange.axis.min || xrange.from > xrange.axis.max ||
						yrange.to < yrange.axis.min || yrange.from > yrange.axis.max)
						continue;
					
					xrange.from = Math.max(xrange.from, xrange.axis.min);
					xrange.to = Math.min(xrange.to, xrange.axis.max);
					yrange.from = Math.max(yrange.from, yrange.axis.min);
					yrange.to = Math.min(yrange.to, yrange.axis.max);
					
					if (xrange.from == xrange.to && yrange.from == yrange.to)
						continue;
					
					// then draw
					xrange.from = xrange.axis.p2c(xrange.from);
					xrange.to = xrange.axis.p2c(xrange.to);
					yrange.from = yrange.axis.p2c(yrange.from);
					yrange.to = yrange.axis.p2c(yrange.to);
					
					if (xrange.from == xrange.to || yrange.from == yrange.to) {
						// draw line
						ctx.beginPath();
						ctx.strokeStyle = m.color || options.grid.markingsColor;
						ctx.lineWidth = m.lineWidth || options.grid.markingsLineWidth;
						ctx.moveTo(xrange.from, yrange.from);
						ctx.lineTo(xrange.to, yrange.to);
						ctx.stroke();
					} else {
						// fill area
						ctx.fillStyle = m.color || options.grid.markingsColor;
						ctx.fillRect(xrange.from, yrange.to,
							xrange.to - xrange.from,
							yrange.from - yrange.to);
					}
				}
			}
			
			// draw the ticks
			var axes = allAxes(),
			bw = options.grid.borderWidth;
			
			for (var j = 0; j < axes.length; ++j) {
				var axis = axes[j],
				box = axis.box,
				t = axis.tickLength,
				x,
				y,
				xoff,
				yoff;
				if (!axis.show || axis.ticks.length == 0)
					{ continue; }
					
				ctx.strokeStyle = axis.options.tickColor || $.color.parse(axis.options.color).scale('a', 0.22).toString();
				ctx.lineWidth = 1;
				
				// find the edges
				if (axis.direction == "x") {
					x = 0;
					if (t == "full")
						y = (axis.position == "top" ? 0 : plotHeight);
					else
						y = box.top - plotOffset.top + (axis.position == "top" ? box.height : 0);
				} else {
					y = 0;
					if (t == "full")
						x = (axis.position == "left" ? 0 : plotWidth);
					else
						x = box.left - plotOffset.left + (axis.position == "left" ? box.width : 0);
				}
				
				// draw tick bar
				if (!axis.innermost) {
					ctx.beginPath();
					xoff = yoff = 0;
					if (axis.direction == "x")
						xoff = plotWidth;
					else
						yoff = plotHeight;
					
					if (ctx.lineWidth == 1) {
						x = Math.floor(x) + 0.5;
						y = Math.floor(y) + 0.5;
					}
					
					ctx.moveTo(x, y);
					ctx.lineTo(x + xoff, y + yoff);
					ctx.stroke();
				}
				
				// draw ticks
				ctx.beginPath();
				for (i = 0; i < axis.ticks.length; ++i) {
					var v = axis.ticks[i].v;
					
					xoff = yoff = 0;
					
					if (v < axis.min || v > axis.max
						// skip those lying on the axes if we got a border
						 || (t == "full" && bw > 0
							 && (v == axis.min || v == axis.max)))
						continue;
					
					if (axis.direction == "x") {
						x = axis.p2c(v);
						yoff = t == "full" ? -plotHeight : t;
						
						if (axis.position == "top")
							yoff = -yoff;
					} else {
						y = axis.p2c(v);
						xoff = t == "full" ? -plotWidth : t;
						
						if (axis.position == "left")
							xoff = -xoff;
					}
					
					if (ctx.lineWidth == 1) {
						if (axis.direction == "x")
							x = Math.floor(x) + 0.5;
						else
							y = Math.floor(y) + 0.5;
					}
					
					ctx.moveTo(x, y);
					ctx.lineTo(x + xoff, y + yoff);
				}
				
				ctx.stroke();
			}
			
			// draw border
			if (bw) {
				ctx.lineWidth = bw;
				ctx.strokeStyle = options.grid.borderColor;
				ctx.strokeRect(-bw / 2, -bw / 2, plotWidth + bw, plotHeight + bw);
			}
			
			ctx.restore();
		}
		
		function insertAxisLabels() {
			placeholder.find(".tickLabels").remove();
			
			var html = ['<div class="tickLabels" style="font-size:smaller">'];
			
			var axes = allAxes();
			for (var j = 0; j < axes.length; ++j) {
				var axis = axes[j],
				box = axis.box;
				if (!axis.show)
					continue;
				//debug: html.push('<div style="position:absolute;opacity:0.10;background-color:red;left:' + box.left + 'px;top:' + box.top + 'px;width:' + box.width +  'px;height:' + box.height + 'px"></div>')
				html.push('<div class="' + axis.direction + 'Axis ' + axis.direction + axis.n + 'Axis" style="color:' + axis.options.color + '">');
				for (var i = 0; i < axis.ticks.length; ++i) {
					var tick = axis.ticks[i];
					if (!tick.label || tick.v < axis.min || tick.v > axis.max)
						continue;
					
					var pos = {},
					align;
					
					if (axis.direction == "x") {
						align = "center";
						pos.left = Math.round(plotOffset.left + axis.p2c(tick.v) - axis.labelWidth / 2);
						if (axis.position == "bottom")
							pos.top = box.top + box.padding;
						else
							pos.bottom = canvasHeight - (box.top + box.height - box.padding);
					} else {
						pos.top = Math.round(plotOffset.top + axis.p2c(tick.v) - axis.labelHeight / 2);
						if (axis.position == "left") {
							pos.right = canvasWidth - (box.left + box.width - box.padding)
								align = "right";
						} else {
							pos.left = box.left + box.padding;
							align = "left";
						}
					}
					
					pos.width = axis.labelWidth;
					
					var style = ["position:absolute", "text-align:" + align];
					for (var a in pos)
						style.push(a + ":" + pos[a] + "px")
						
						html.push('<div class="tickLabel" style="' + style.join(';') + '">' + tick.label + '</div>');
				}
				html.push('</div>');
			}
			
			html.push('</div>');
			
			placeholder.append(html.join(""));
		}
		
		function drawSeries(series) {
			if (series.lines.show)
				drawSeriesLines(series);
			if (series.bars.show)
				drawSeriesBars(series);
			if (series.points.show)
				drawSeriesPoints(series);
		}
		
		function drawSeriesLines(series) {
			function plotLine(datapoints, xoffset, yoffset, axisx, axisy) {
				var points = datapoints.points,
				ps = datapoints.pointsize,
				prevx = null,
				prevy = null;
				
				ctx.beginPath();
				for (var i = ps; i < points.length; i += ps) {
					var x1 = points[i - ps],
					y1 = points[i - ps + 1],
					x2 = points[i],
					y2 = points[i + 1];
					
					if (x1 == null || x2 == null)
						continue;
					
					// clip with ymin
					if (y1 <= y2 && y1 < axisy.min) {
						if (y2 < axisy.min)
							continue; // line segment is outside
						// compute new intersection point
						x1 = (axisy.min - y1) / (y2 - y1) * (x2 - x1) + x1;
						y1 = axisy.min;
					} else if (y2 <= y1 && y2 < axisy.min) {
						if (y1 < axisy.min)
							continue;
						x2 = (axisy.min - y1) / (y2 - y1) * (x2 - x1) + x1;
						y2 = axisy.min;
					}
					
					// clip with ymax
					if (y1 >= y2 && y1 > axisy.max) {
						if (y2 > axisy.max)
							continue;
						x1 = (axisy.max - y1) / (y2 - y1) * (x2 - x1) + x1;
						y1 = axisy.max;
					} else if (y2 >= y1 && y2 > axisy.max) {
						if (y1 > axisy.max)
							continue;
						x2 = (axisy.max - y1) / (y2 - y1) * (x2 - x1) + x1;
						y2 = axisy.max;
					}
					
					// clip with xmin
					if (x1 <= x2 && x1 < axisx.min) {
						if (x2 < axisx.min)
							continue;
						y1 = (axisx.min - x1) / (x2 - x1) * (y2 - y1) + y1;
						x1 = axisx.min;
					} else if (x2 <= x1 && x2 < axisx.min) {
						if (x1 < axisx.min)
							continue;
						y2 = (axisx.min - x1) / (x2 - x1) * (y2 - y1) + y1;
						x2 = axisx.min;
					}
					
					// clip with xmax
					if (x1 >= x2 && x1 > axisx.max) {
						if (x2 > axisx.max)
							continue;
						y1 = (axisx.max - x1) / (x2 - x1) * (y2 - y1) + y1;
						x1 = axisx.max;
					} else if (x2 >= x1 && x2 > axisx.max) {
						if (x1 > axisx.max)
							continue;
						y2 = (axisx.max - x1) / (x2 - x1) * (y2 - y1) + y1;
						x2 = axisx.max;
					}
					
					if (x1 != prevx || y1 != prevy)
						ctx.moveTo(axisx.p2c(x1) + xoffset, axisy.p2c(y1) + yoffset);
					
					prevx = x2;
					prevy = y2;
					ctx.lineTo(axisx.p2c(x2) + xoffset, axisy.p2c(y2) + yoffset);
				}
				ctx.stroke();
			}
			
			function plotLineArea(datapoints, axisx, axisy) {
				var points = datapoints.points,
				ps = datapoints.pointsize,
				bottom = Math.min(Math.max(0, axisy.min), axisy.max),
				i = 0,
				top,
				areaOpen = false,
				ypos = 1,
				segmentStart = 0,
				segmentEnd = 0;
				
				// we process each segment in two turns, first forward
				// direction to sketch out top, then once we hit the
				// end we go backwards to sketch the bottom
				while (true) {
					if (ps > 0 && i > points.length + ps)
						break;
					
					i += ps; // ps is negative if going backwards
					
					var x1 = points[i - ps],
					y1 = points[i - ps + ypos],
					x2 = points[i],
					y2 = points[i + ypos];
					
					if (areaOpen) {
						if (ps > 0 && x1 != null && x2 == null) {
							// at turning point
							segmentEnd = i;
							ps = -ps;
							ypos = 2;
							continue;
						}
						
						if (ps < 0 && i == segmentStart + ps) {
							// done with the reverse sweep
							ctx.fill();
							areaOpen = false;
							ps = -ps;
							ypos = 1;
							i = segmentStart = segmentEnd + ps;
							continue;
						}
					}
					
					if (x1 == null || x2 == null)
						continue;
					
					// clip x values
					
					// clip with xmin
					if (x1 <= x2 && x1 < axisx.min) {
						if (x2 < axisx.min)
							continue;
						y1 = (axisx.min - x1) / (x2 - x1) * (y2 - y1) + y1;
						x1 = axisx.min;
					} else if (x2 <= x1 && x2 < axisx.min) {
						if (x1 < axisx.min)
							continue;
						y2 = (axisx.min - x1) / (x2 - x1) * (y2 - y1) + y1;
						x2 = axisx.min;
					}
					
					// clip with xmax
					if (x1 >= x2 && x1 > axisx.max) {
						if (x2 > axisx.max)
							continue;
						y1 = (axisx.max - x1) / (x2 - x1) * (y2 - y1) + y1;
						x1 = axisx.max;
					} else if (x2 >= x1 && x2 > axisx.max) {
						if (x1 > axisx.max)
							continue;
						y2 = (axisx.max - x1) / (x2 - x1) * (y2 - y1) + y1;
						x2 = axisx.max;
					}
					
					if (!areaOpen) {
						// open area
						ctx.beginPath();
						ctx.moveTo(axisx.p2c(x1), axisy.p2c(bottom));
						areaOpen = true;
					}
					
					// now first check the case where both is outside
					if (y1 >= axisy.max && y2 >= axisy.max) {
						ctx.lineTo(axisx.p2c(x1), axisy.p2c(axisy.max));
						ctx.lineTo(axisx.p2c(x2), axisy.p2c(axisy.max));
						continue;
					} else if (y1 <= axisy.min && y2 <= axisy.min) {
						ctx.lineTo(axisx.p2c(x1), axisy.p2c(axisy.min));
						ctx.lineTo(axisx.p2c(x2), axisy.p2c(axisy.min));
						continue;
					}
					
					// else it's a bit more complicated, there might
					// be a flat maxed out rectangle first, then a
					// triangular cutout or reverse; to find these
					// keep track of the current x values
					var x1old = x1,
					x2old = x2;
					
					// clip the y values, without shortcutting, we
					// go through all cases in turn
					
					// clip with ymin
					if (y1 <= y2 && y1 < axisy.min && y2 >= axisy.min) {
						x1 = (axisy.min - y1) / (y2 - y1) * (x2 - x1) + x1;
						y1 = axisy.min;
					} else if (y2 <= y1 && y2 < axisy.min && y1 >= axisy.min) {
						x2 = (axisy.min - y1) / (y2 - y1) * (x2 - x1) + x1;
						y2 = axisy.min;
					}
					
					// clip with ymax
					if (y1 >= y2 && y1 > axisy.max && y2 <= axisy.max) {
						x1 = (axisy.max - y1) / (y2 - y1) * (x2 - x1) + x1;
						y1 = axisy.max;
					} else if (y2 >= y1 && y2 > axisy.max && y1 <= axisy.max) {
						x2 = (axisy.max - y1) / (y2 - y1) * (x2 - x1) + x1;
						y2 = axisy.max;
					}
					
					// if the x value was changed we got a rectangle
					// to fill
					if (x1 != x1old) {
						ctx.lineTo(axisx.p2c(x1old), axisy.p2c(y1));
						// it goes to (x1, y1), but we fill that below
					}
					
					// fill triangular section, this sometimes result
					// in redundant points if (x1, y1) hasn't changed
					// from previous line to, but we just ignore that
					ctx.lineTo(axisx.p2c(x1), axisy.p2c(y1));
					ctx.lineTo(axisx.p2c(x2), axisy.p2c(y2));
					
					// fill the other rectangle if it's there
					if (x2 != x2old) {
						ctx.lineTo(axisx.p2c(x2), axisy.p2c(y2));
						ctx.lineTo(axisx.p2c(x2old), axisy.p2c(y2));
					}
				}
			}
			
			ctx.save();
			ctx.translate(plotOffset.left, plotOffset.top);
			ctx.lineJoin = "round";
			
			var lw = series.lines.lineWidth,
			sw = series.shadowSize;
			// FIXME: consider another form of shadow when filling is turned on
			if (lw > 0 && sw > 0) {
				// draw shadow as a thick and thin line with transparency
				ctx.lineWidth = sw;
				ctx.strokeStyle = "rgba(0,0,0,0.1)";
				// position shadow at angle from the mid of line
				var angle = Math.PI / 18;
				plotLine(series.datapoints, Math.sin(angle) * (lw / 2 + sw / 2), Math.cos(angle) * (lw / 2 + sw / 2), series.xaxis, series.yaxis);
				ctx.lineWidth = sw / 2;
				plotLine(series.datapoints, Math.sin(angle) * (lw / 2 + sw / 4), Math.cos(angle) * (lw / 2 + sw / 4), series.xaxis, series.yaxis);
			}
			
			ctx.lineWidth = lw;
			ctx.strokeStyle = series.color;
			var fillStyle = getFillStyle(series.lines, series.color, 0, plotHeight);
			if (fillStyle) {
				ctx.fillStyle = fillStyle;
				plotLineArea(series.datapoints, series.xaxis, series.yaxis);
			}
			
			if (lw > 0)
				plotLine(series.datapoints, 0, 0, series.xaxis, series.yaxis);
			ctx.restore();
		}
		
		function drawSeriesPoints(series) {
			function plotPoints(datapoints, radius, fillStyle, offset, shadow, axisx, axisy, symbol) {
				var points = datapoints.points,
				ps = datapoints.pointsize;
				
				for (var i = 0; i < points.length; i += ps) {
					var x = points[i],
					y = points[i + 1];
					if (x == null || x < axisx.min || x > axisx.max || y < axisy.min || y > axisy.max)
						continue;
					
					ctx.beginPath();
					x = axisx.p2c(x);
					y = axisy.p2c(y) + offset;
					if (symbol == "circle")
						ctx.arc(x, y, radius, 0, shadow ? Math.PI : Math.PI * 2, false);
					else
						symbol(ctx, x, y, radius, shadow);
					ctx.closePath();
					
					if (fillStyle) {
						ctx.fillStyle = fillStyle;
						ctx.fill();
					}
					ctx.stroke();
				}
			}
			
			ctx.save();
			ctx.translate(plotOffset.left, plotOffset.top);
			
			var lw = series.points.lineWidth,
			sw = series.shadowSize,
			radius = series.points.radius,
			symbol = series.points.symbol;
			if (lw > 0 && sw > 0) {
				// draw shadow in two steps
				var w = sw / 2;
				ctx.lineWidth = w;
				ctx.strokeStyle = "rgba(0,0,0,0.1)";
				plotPoints(series.datapoints, radius, null, w + w / 2, true,
					series.xaxis, series.yaxis, symbol);
				
				ctx.strokeStyle = "rgba(0,0,0,0.2)";
				plotPoints(series.datapoints, radius, null, w / 2, true,
					series.xaxis, series.yaxis, symbol);
			}
			
			ctx.lineWidth = lw;
			ctx.strokeStyle = series.color;
			plotPoints(series.datapoints, radius,
				getFillStyle(series.points, series.color), 0, false,
				series.xaxis, series.yaxis, symbol);
			ctx.restore();
		}
		
		function drawBar(x, y, b, barLeft, barRight, offset, fillStyleCallback, axisx, axisy, c, horizontal, lineWidth) {
			var left,
			right,
			bottom,
			top,
			drawLeft,
			drawRight,
			drawTop,
			drawBottom,
			tmp;
			
			// in horizontal mode, we start the bar from the left
			// instead of from the bottom so it appears to be
			// horizontal rather than vertical
			if (horizontal) {
				drawBottom = drawRight = drawTop = true;
				drawLeft = false;
				left = b;
				right = x;
				top = y + barLeft;
				bottom = y + barRight;
				
				// account for negative bars
				if (right < left) {
					tmp = right;
					right = left;
					left = tmp;
					drawLeft = true;
					drawRight = false;
				}
			} else {
				drawLeft = drawRight = drawTop = true;
				drawBottom = false;
				left = x + barLeft;
				right = x + barRight;
				bottom = b;
				top = y;
				
				// account for negative bars
				if (top < bottom) {
					tmp = top;
					top = bottom;
					bottom = tmp;
					drawBottom = true;
					drawTop = false;
				}
			}
			
			// clip
			if (right < axisx.min || left > axisx.max ||
				top < axisy.min || bottom > axisy.max)
				return;
			
			if (left < axisx.min) {
				left = axisx.min;
				drawLeft = false;
			}
			
			if (right > axisx.max) {
				right = axisx.max;
				drawRight = false;
			}
			
			if (bottom < axisy.min) {
				bottom = axisy.min;
				drawBottom = false;
			}
			
			if (top > axisy.max) {
				top = axisy.max;
				drawTop = false;
			}
			
			left = axisx.p2c(left);
			bottom = axisy.p2c(bottom);
			right = axisx.p2c(right);
			top = axisy.p2c(top);
			
			// fill the bar
			if (fillStyleCallback) {
				c.beginPath();
				c.moveTo(left, bottom);
				c.lineTo(left, top);
				c.lineTo(right, top);
				c.lineTo(right, bottom);
				c.fillStyle = fillStyleCallback(bottom, top);
				c.fill();
			}
			
			// draw outline
			if (lineWidth > 0 && (drawLeft || drawRight || drawTop || drawBottom)) {
				c.beginPath();
				
				// FIXME: inline moveTo is buggy with excanvas
				c.moveTo(left, bottom + offset);
				if (drawLeft)
					c.lineTo(left, top + offset);
				else
					c.moveTo(left, top + offset);
				if (drawTop)
					c.lineTo(right, top + offset);
				else
					c.moveTo(right, top + offset);
				if (drawRight)
					c.lineTo(right, bottom + offset);
				else
					c.moveTo(right, bottom + offset);
				if (drawBottom)
					c.lineTo(left, bottom + offset);
				else
					c.moveTo(left, bottom + offset);
				c.stroke();
			}
		}
		
		function drawSeriesBars(series) {
			function plotBars(datapoints, barLeft, barRight, offset, fillStyleCallback, axisx, axisy) {
				var points = datapoints.points,
				ps = datapoints.pointsize;
				
				for (var i = 0; i < points.length; i += ps) {
					if (points[i] == null)
						continue;
					drawBar(points[i], points[i + 1], points[i + 2], barLeft, barRight, offset, fillStyleCallback, axisx, axisy, ctx, series.bars.horizontal, series.bars.lineWidth);
				}
			}
			
			ctx.save();
			ctx.translate(plotOffset.left, plotOffset.top);
			
			// FIXME: figure out a way to add shadows (for instance along the right edge)
			ctx.lineWidth = series.bars.lineWidth;
			ctx.strokeStyle = series.color;
			var barLeft = series.bars.align == "left" ? 0 : -series.bars.barWidth / 2;
			var fillStyleCallback = series.bars.fill ? function (bottom, top) {
				return getFillStyle(series.bars, series.color, bottom, top);
			}
			 : null;
			plotBars(series.datapoints, barLeft, barLeft + series.bars.barWidth, 0, fillStyleCallback, series.xaxis, series.yaxis);
			ctx.restore();
		}
		
		function getFillStyle(filloptions, seriesColor, bottom, top) {
			var fill = filloptions.fill;
			if (!fill)
				return null;
			
			if (filloptions.fillColor)
				return getColorOrGradient(filloptions.fillColor, bottom, top, seriesColor);
			
			var c = $.color.parse(seriesColor);
			c.a = typeof fill == "number" ? fill : 0.4;
			c.normalize();
			return c.toString();
		}
		
		function insertLegend() {
			placeholder.find(".legend").remove();
			
			if (!options.legend.show)
				return;
			
			var fragments = [],
			rowStarted = false,
			lf = options.legend.labelFormatter,
			s,
			label;
			for (var i = 0; i < series.length; ++i) {
				s = series[i];
				label = s.label;
				if (!label)
					continue;
				
				if (i % options.legend.noColumns == 0) {
					if (rowStarted)
						fragments.push('</tr>');
					fragments.push('<tr>');
					rowStarted = true;
				}
				
				if (lf)
					label = lf(label, s);
				
				fragments.push(
					'<td class="legendColorBox"><div style="border:1px solid ' + options.legend.labelBoxBorderColor + ';padding:1px"><div style="width:4px;height:0;border:5px solid ' + s.color + ';overflow:hidden"></div></div></td>' +
					'<td class="legendLabel">' + label + '</td>');
			}
			if (rowStarted)
				fragments.push('</tr>');
			
			if (fragments.length == 0)
				return;
			
			var table = '<table style="font-size:smaller;color:' + options.grid.color + '">' + fragments.join("") + '</table>';
			if (options.legend.container != null)
				$(options.legend.container).html(table);
			else {
				var pos = "",
				p = options.legend.position,
				m = options.legend.margin;
				if (m[0] == null)
					m = [m, m];
				if (p.charAt(0) == "n")
					pos += 'top:' + (m[1] + plotOffset.top) + 'px;';
				else if (p.charAt(0) == "s")
					pos += 'bottom:' + (m[1] + plotOffset.bottom) + 'px;';
				if (p.charAt(1) == "e")
					pos += 'right:' + (m[0] + plotOffset.right) + 'px;';
				else if (p.charAt(1) == "w")
					pos += 'left:' + (m[0] + plotOffset.left) + 'px;';
				var legend = $('<div class="legend">' + table.replace('style="', 'style="position:absolute;' + pos + ';') + '</div>').appendTo(placeholder);
				if (options.legend.backgroundOpacity != 0.0) {
					// put in the transparent background
					// separately to avoid blended labels and
					// label boxes
					var c = options.legend.backgroundColor;
					if (c == null) {
						c = options.grid.backgroundColor;
						if (c && typeof c == "string")
							c = $.color.parse(c);
						else
							c = $.color.extract(legend, 'background-color');
						c.a = 1;
						c = c.toString();
					}
					var div = legend.children();
					$('<div style="position:absolute;width:' + div.width() + 'px;height:' + div.height() + 'px;' + pos + 'background-color:' + c + ';"> </div>').prependTo(legend).css('opacity', options.legend.backgroundOpacity);
				}
			}
		}
		
		// interactive features
		
		var highlights = [],
		redrawTimeout = null;
		
		// returns the data item the mouse is over, or null if none is found
		function findNearbyItem(mouseX, mouseY, seriesFilter) {
			var maxDistance = options.grid.mouseActiveRadius,
			smallestDistance = maxDistance * maxDistance + 1,
			item = null,
			foundPoint = false,
			i,
			j;
			
			for (i = series.length - 1; i >= 0; --i) {
				if (!seriesFilter(series[i]))
					continue;
				
				var s = series[i],
				axisx = s.xaxis,
				axisy = s.yaxis,
				points = s.datapoints.points,
				ps = s.datapoints.pointsize,
				mx = axisx.c2p(mouseX), // precompute some stuff to make the loop faster
				my = axisy.c2p(mouseY),
				maxx = maxDistance / axisx.scale,
				maxy = maxDistance / axisy.scale;
				
				// with inverse transforms, we can't use the maxx/maxy
				// optimization, sadly
				if (axisx.options.inverseTransform)
					maxx = Number.MAX_VALUE;
				if (axisy.options.inverseTransform)
					maxy = Number.MAX_VALUE;
				
				if (s.lines.show || s.points.show) {
					for (j = 0; j < points.length; j += ps) {
						var x = points[j],
						y = points[j + 1];
						if (x == null)
							continue;
						
						// For points and lines, the cursor must be within a
						// certain distance to the data point
						if (x - mx > maxx || x - mx < -maxx ||
							y - my > maxy || y - my < -maxy)
							continue;
						
						// We have to calculate distances in pixels, not in
						// data units, because the scales of the axes may be different
						var dx = Math.abs(axisx.p2c(x) - mouseX),
						dy = Math.abs(axisy.p2c(y) - mouseY),
						dist = dx * dx + dy * dy; // we save the sqrt
						
						// use <= to ensure last point takes precedence
						// (last generally means on top of)
						if (dist < smallestDistance) {
							smallestDistance = dist;
							item = [i, j / ps];
						}
					}
				}
				
				if (s.bars.show && !item) { // no other point can be nearby
					var barLeft = s.bars.align == "left" ? 0 : -s.bars.barWidth / 2,
					barRight = barLeft + s.bars.barWidth;
					
					for (j = 0; j < points.length; j += ps) {
						var x = points[j],
						y = points[j + 1],
						b = points[j + 2];
						if (x == null)
							continue;
						
						// for a bar graph, the cursor must be inside the bar
						if (series[i].bars.horizontal ?
							(mx <= Math.max(b, x) && mx >= Math.min(b, x) &&
								my >= y + barLeft && my <= y + barRight) :
							(mx >= x + barLeft && mx <= x + barRight &&
								my >= Math.min(b, y) && my <= Math.max(b, y)))
							item = [i, j / ps];
					}
				}
			}
			
			if (item) {
				i = item[0];
				j = item[1];
				ps = series[i].datapoints.pointsize;
				
				return {
					datapoint : series[i].datapoints.points.slice(j * ps, (j + 1) * ps),
					dataIndex : j,
					series : series[i],
					seriesIndex : i
				};
			}
			
			return null;
		}
		
		function onMouseMove(e) {
			if (options.grid.hoverable)
				triggerClickHoverEvent("plothover", e,
					function (s) {
					return s["hoverable"] != false;
				});
		}
		
		function onMouseLeave(e) {
			if (options.grid.hoverable)
				triggerClickHoverEvent("plothover", e,
					function (s) {
					return false;
				});
		}
		
		function onClick(e) {
			triggerClickHoverEvent("plotclick", e,
				function (s) {
				return s["clickable"] != false;
			});
		}
		
		// trigger click or hover event (they send the same parameters
		// so we share their code)
		function triggerClickHoverEvent(eventname, event, seriesFilter) {
			var offset = eventHolder.offset(),
			canvasX = event.pageX - offset.left - plotOffset.left,
			canvasY = event.pageY - offset.top - plotOffset.top,
			pos = canvasToAxisCoords({
					left : canvasX,
					top : canvasY
				});
			
			pos.pageX = event.pageX;
			pos.pageY = event.pageY;
			
			var item = findNearbyItem(canvasX, canvasY, seriesFilter);
			
			if (item) {
				// fill in mouse pos for any listeners out there
				item.pageX = parseInt(item.series.xaxis.p2c(item.datapoint[0]) + offset.left + plotOffset.left);
				item.pageY = parseInt(item.series.yaxis.p2c(item.datapoint[1]) + offset.top + plotOffset.top);
			}
			
			if (options.grid.autoHighlight) {
				// clear auto-highlights
				for (var i = 0; i < highlights.length; ++i) {
					var h = highlights[i];
					if (h.auto == eventname &&
						!(item && h.series == item.series &&
							h.point[0] == item.datapoint[0] &&
							h.point[1] == item.datapoint[1]))
						unhighlight(h.series, h.point);
				}
				
				if (item)
					highlight(item.series, item.datapoint, eventname);
			}
			
			placeholder.trigger(eventname, [pos, item]);
		}
		
		function triggerRedrawOverlay() {
			if (!redrawTimeout)
				redrawTimeout = setTimeout(drawOverlay, 30);
		}
		
		function drawOverlay() {
			redrawTimeout = null;
			
			// draw highlights
			octx.save();
			octx.clearRect(0, 0, canvasWidth, canvasHeight);
			octx.translate(plotOffset.left, plotOffset.top);
			
			var i,
			hi;
			for (i = 0; i < highlights.length; ++i) {
				hi = highlights[i];
				
				if (hi.series.bars.show)
					drawBarHighlight(hi.series, hi.point);
				else
					drawPointHighlight(hi.series, hi.point);
			}
			octx.restore();
			
			executeHooks(hooks.drawOverlay, [octx]);
		}
		
		function highlight(s, point, auto) {
			if (typeof s == "number")
				s = series[s];
			
			if (typeof point == "number") {
				var ps = s.datapoints.pointsize;
				point = s.datapoints.points.slice(ps * point, ps * (point + 1));
			}
			
			var i = indexOfHighlight(s, point);
			if (i == -1) {
				highlights.push({
					series : s,
					point : point,
					auto : auto
				});
				
				triggerRedrawOverlay();
			} else if (!auto)
				highlights[i].auto = false;
		}
		
		function unhighlight(s, point) {
			if (s == null && point == null) {
				highlights = [];
				triggerRedrawOverlay();
			}
			
			if (typeof s == "number")
				s = series[s];
			
			if (typeof point == "number")
				point = s.data[point];
			
			var i = indexOfHighlight(s, point);
			if (i != -1) {
				highlights.splice(i, 1);
				
				triggerRedrawOverlay();
			}
		}
		
		function indexOfHighlight(s, p) {
			for (var i = 0; i < highlights.length; ++i) {
				var h = highlights[i];
				if (h.series == s && h.point[0] == p[0]
					 && h.point[1] == p[1])
					return i;
			}
			return -1;
		}
		
		function drawPointHighlight(series, point) {
			var x = point[0],
			y = point[1],
			axisx = series.xaxis,
			axisy = series.yaxis;
			
			if (x < axisx.min || x > axisx.max || y < axisy.min || y > axisy.max)
				return;
			
			var pointRadius = series.points.radius + series.points.lineWidth / 2;
			octx.lineWidth = pointRadius;
			octx.strokeStyle = $.color.parse(series.color).scale('a', 0.5).toString();
			var radius = 1.5 * pointRadius,
			x = axisx.p2c(x),
			y = axisy.p2c(y);
			
			octx.beginPath();
			if (series.points.symbol == "circle")
				octx.arc(x, y, radius, 0, 2 * Math.PI, false);
			else
				series.points.symbol(octx, x, y, radius, false);
			octx.closePath();
			octx.stroke();
		}
		
		function drawBarHighlight(series, point) {
			octx.lineWidth = series.bars.lineWidth;
			octx.strokeStyle = $.color.parse(series.color).scale('a', 0.5).toString();
			var fillStyle = $.color.parse(series.color).scale('a', 0.5).toString();
			var barLeft = series.bars.align == "left" ? 0 : -series.bars.barWidth / 2;
			drawBar(point[0], point[1], point[2] || 0, barLeft, barLeft + series.bars.barWidth,
				0, function () {
				return fillStyle;
			}, series.xaxis, series.yaxis, octx, series.bars.horizontal, series.bars.lineWidth);
		}
		
		function getColorOrGradient(spec, bottom, top, defaultColor) {
			if (typeof spec == "string")
				return spec;
			else {
				// assume this is a gradient spec; IE currently only
				// supports a simple vertical gradient properly, so that's
				// what we support too
				var gradient = ctx.createLinearGradient(0, top, 0, bottom);
				
				for (var i = 0, l = spec.colors.length; i < l; ++i) {
					var c = spec.colors[i];
					if (typeof c != "string") {
						var co = $.color.parse(defaultColor);
						if (c.brightness != null)
							co = co.scale('rgb', c.brightness)
								if (c.opacity != null)
									co.a *= c.opacity;
								c = co.toString();
					}
					gradient.addColorStop(i / (l - 1), c);
				}
				
				return gradient;
			}
		}
	}
	
	$.plot = function (placeholder, data, options) {
		//var t0 = new Date();
		var plot = new Plot($(placeholder), data, options, $.plot.plugins);
		//(window.console ? console.log : alert)("time used (msecs): " + ((new Date()).getTime() - t0.getTime()));
		return plot;
	};
	
	$.plot.version = "0.7";
	
	$.plot.plugins = [];
	
	// returns a string with the date d formatted according to fmt
	$.plot.formatDate = function (d, fmt, monthNames) {
		var leftPad = function (n) {
			n = "" + n;
			return n.length == 1 ? "0" + n : n;
		};
		
		var r = [];
		var escape = false,
		padNext = false;
		var hours = d.getUTCHours();
		var isAM = hours < 12;
		if (monthNames == null)
			monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		
		if (fmt.search(/%p|%P/) != -1) {
			if (hours > 12) {
				hours = hours - 12;
			} else if (hours == 0) {
				hours = 12;
			}
		}
		for (var i = 0; i < fmt.length; ++i) {
			var c = fmt.charAt(i);
			
			if (escape) {
				switch (c) {
				case 'h':
					c = "" + hours;
					break;
				case 'H':
					c = leftPad(hours);
					break;
				case 'M':
					c = leftPad(d.getUTCMinutes());
					break;
				case 'S':
					c = leftPad(d.getUTCSeconds());
					break;
				case 'd':
					c = "" + d.getUTCDate();
					break;
				case 'm':
					c = "" + (d.getUTCMonth() + 1);
					break;
				case 'y':
					c = "" + d.getUTCFullYear();
					break;
				case 'b':
					c = "" + monthNames[d.getUTCMonth()];
					break;
				case 'p':
					c = (isAM) ? ("" + "am") : ("" + "pm");
					break;
				case 'P':
					c = (isAM) ? ("" + "AM") : ("" + "PM");
					break;
				case '0':
					c = "";
					padNext = true;
					break;
				}
				if (c && padNext) {
					c = leftPad(c);
					padNext = false;
				}
				r.push(c);
				if (!padNext)
					escape = false;
			} else {
				if (c == "%")
					escape = true;
				else
					r.push(c);
			}
		}
		return r.join("");
	};
	
	// round to nearby lower multiple of base
	function floorInBase(n, base) {
		return base * Math.floor(n / base);
	}
	
})(jQuery);



/*
 * jQuery hashchange event - v1.3 - 7/21/2010
 * http://benalman.com/projects/jquery-hashchange-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */

// Script: jQuery hashchange event
//
// *Version: 1.3, Last updated: 7/21/2010*
// 
// Project Home - http://benalman.com/projects/jquery-hashchange-plugin/
// GitHub       - http://github.com/cowboy/jquery-hashchange/
// Source       - http://github.com/cowboy/jquery-hashchange/raw/master/jquery.ba-hashchange.js
// (Minified)   - http://github.com/cowboy/jquery-hashchange/raw/master/jquery.ba-hashchange.min.js (0.8kb gzipped)
// 
// About: License
// 
// Copyright (c) 2010 "Cowboy" Ben Alman,
// Dual licensed under the MIT and GPL licenses.
// http://benalman.com/about/license/
// 
// About: Examples
// 
// These working examples, complete with fully commented code, illustrate a few
// ways in which this plugin can be used.
// 
// hashchange event - http://benalman.com/code/projects/jquery-hashchange/examples/hashchange/
// document.domain - http://benalman.com/code/projects/jquery-hashchange/examples/document_domain/
// 
// About: Support and Testing
// 
// Information about what version or versions of jQuery this plugin has been
// tested with, what browsers it has been tested in, and where the unit tests
// reside (so you can test it yourself).
// 
// jQuery Versions - 1.2.6, 1.3.2, 1.4.1, 1.4.2
// Browsers Tested - Internet Explorer 6-8, Firefox 2-4, Chrome 5-6, Safari 3.2-5,
//                   Opera 9.6-10.60, iPhone 3.1, Android 1.6-2.2, BlackBerry 4.6-5.
// Unit Tests      - http://benalman.com/code/projects/jquery-hashchange/unit/
// 
// About: Known issues
// 
// While this jQuery hashchange event implementation is quite stable and
// robust, there are a few unfortunate browser bugs surrounding expected
// hashchange event-based behaviors, independent of any JavaScript
// window.onhashchange abstraction. See the following examples for more
// information:
// 
// Chrome: Back Button - http://benalman.com/code/projects/jquery-hashchange/examples/bug-chrome-back-button/
// Firefox: Remote XMLHttpRequest - http://benalman.com/code/projects/jquery-hashchange/examples/bug-firefox-remote-xhr/
// WebKit: Back Button in an Iframe - http://benalman.com/code/projects/jquery-hashchange/examples/bug-webkit-hash-iframe/
// Safari: Back Button from a different domain - http://benalman.com/code/projects/jquery-hashchange/examples/bug-safari-back-from-diff-domain/
// 
// Also note that should a browser natively support the window.onhashchange 
// event, but not report that it does, the fallback polling loop will be used.
// 
// About: Release History
// 
// 1.3   - (7/21/2010) Reorganized IE6/7 Iframe code to make it more
//         "removable" for mobile-only development. Added IE6/7 document.title
//         support. Attempted to make Iframe as hidden as possible by using
//         techniques from http://www.paciellogroup.com/blog/?p=604. Added 
//         support for the "shortcut" format $(window).hashchange( fn ) and
//         $(window).hashchange() like jQuery provides for built-in events.
//         Renamed jQuery.hashchangeDelay to <jQuery.fn.hashchange.delay> and
//         lowered its default value to 50. Added <jQuery.fn.hashchange.domain>
//         and <jQuery.fn.hashchange.src> properties plus document-domain.html
//         file to address access denied issues when setting document.domain in
//         IE6/7.
// 1.2   - (2/11/2010) Fixed a bug where coming back to a page using this plugin
//         from a page on another domain would cause an error in Safari 4. Also,
//         IE6/7 Iframe is now inserted after the body (this actually works),
//         which prevents the page from scrolling when the event is first bound.
//         Event can also now be bound before DOM ready, but it won't be usable
//         before then in IE6/7.
// 1.1   - (1/21/2010) Incorporated document.documentMode test to fix IE8 bug
//         where browser version is incorrectly reported as 8.0, despite
//         inclusion of the X-UA-Compatible IE=EmulateIE7 meta tag.
// 1.0   - (1/9/2010) Initial Release. Broke out the jQuery BBQ event.special
//         window.onhashchange functionality into a separate plugin for users
//         who want just the basic event & back button support, without all the
//         extra awesomeness that BBQ provides. This plugin will be included as
//         part of jQuery BBQ, but also be available separately.

(function($,window,undefined){
  '$:nomunge'; // Used by YUI compressor.
  
  // Reused string.
  var str_hashchange = 'hashchange',
    
    // Method / object references.
    doc = document,
    fake_onhashchange,
    special = $.event.special,
    
    // Does the browser support window.onhashchange? Note that IE8 running in
    // IE7 compatibility mode reports true for 'onhashchange' in window, even
    // though the event isn't supported, so also test document.documentMode.
    doc_mode = doc.documentMode,
    supports_onhashchange = 'on' + str_hashchange in window && ( doc_mode === undefined || doc_mode > 7 );
  
  // Get location.hash (or what you'd expect location.hash to be) sans any
  // leading #. Thanks for making this necessary, Firefox!
  function get_fragment( url ) {
    url = url || location.href;
    return '#' + url.replace( /^[^#]*#?(.*)$/, '$1' );
  };
  
  // Method: jQuery.fn.hashchange
  // 
  // Bind a handler to the window.onhashchange event or trigger all bound
  // window.onhashchange event handlers. This behavior is consistent with
  // jQuery's built-in event handlers.
  // 
  // Usage:
  // 
  // > jQuery(window).hashchange( [ handler ] );
  // 
  // Arguments:
  // 
  //  handler - (Function) Optional handler to be bound to the hashchange
  //    event. This is a "shortcut" for the more verbose form:
  //    jQuery(window).bind( 'hashchange', handler ). If handler is omitted,
  //    all bound window.onhashchange event handlers will be triggered. This
  //    is a shortcut for the more verbose
  //    jQuery(window).trigger( 'hashchange' ). These forms are described in
  //    the <hashchange event> section.
  // 
  // Returns:
  // 
  //  (jQuery) The initial jQuery collection of elements.
  
  // Allow the "shortcut" format $(elem).hashchange( fn ) for binding and
  // $(elem).hashchange() for triggering, like jQuery does for built-in events.
  $.fn[ str_hashchange ] = function( fn ) {
    return fn ? this.bind( str_hashchange, fn ) : this.trigger( str_hashchange );
  };
  
  // Property: jQuery.fn.hashchange.delay
  // 
  // The numeric interval (in milliseconds) at which the <hashchange event>
  // polling loop executes. Defaults to 50.
  
  // Property: jQuery.fn.hashchange.domain
  // 
  // If you're setting document.domain in your JavaScript, and you want hash
  // history to work in IE6/7, not only must this property be set, but you must
  // also set document.domain BEFORE jQuery is loaded into the page. This
  // property is only applicable if you are supporting IE6/7 (or IE8 operating
  // in "IE7 compatibility" mode).
  // 
  // In addition, the <jQuery.fn.hashchange.src> property must be set to the
  // path of the included "document-domain.html" file, which can be renamed or
  // modified if necessary (note that the document.domain specified must be the
  // same in both your main JavaScript as well as in this file).
  // 
  // Usage:
  // 
  // jQuery.fn.hashchange.domain = document.domain;
  
  // Property: jQuery.fn.hashchange.src
  // 
  // If, for some reason, you need to specify an Iframe src file (for example,
  // when setting document.domain as in <jQuery.fn.hashchange.domain>), you can
  // do so using this property. Note that when using this property, history
  // won't be recorded in IE6/7 until the Iframe src file loads. This property
  // is only applicable if you are supporting IE6/7 (or IE8 operating in "IE7
  // compatibility" mode).
  // 
  // Usage:
  // 
  // jQuery.fn.hashchange.src = 'path/to/file.html';
  
  $.fn[ str_hashchange ].delay = 50;
  /*
  $.fn[ str_hashchange ].domain = null;
  $.fn[ str_hashchange ].src = null;
  */
  
  // Event: hashchange event
  // 
  // Fired when location.hash changes. In browsers that support it, the native
  // HTML5 window.onhashchange event is used, otherwise a polling loop is
  // initialized, running every <jQuery.fn.hashchange.delay> milliseconds to
  // see if the hash has changed. In IE6/7 (and IE8 operating in "IE7
  // compatibility" mode), a hidden Iframe is created to allow the back button
  // and hash-based history to work.
  // 
  // Usage as described in <jQuery.fn.hashchange>:
  // 
  // > // Bind an event handler.
  // > jQuery(window).hashchange( function(e) {
  // >   var hash = location.hash;
  // >   ...
  // > });
  // > 
  // > // Manually trigger the event handler.
  // > jQuery(window).hashchange();
  // 
  // A more verbose usage that allows for event namespacing:
  // 
  // > // Bind an event handler.
  // > jQuery(window).bind( 'hashchange', function(e) {
  // >   var hash = location.hash;
  // >   ...
  // > });
  // > 
  // > // Manually trigger the event handler.
  // > jQuery(window).trigger( 'hashchange' );
  // 
  // Additional Notes:
  // 
  // * The polling loop and Iframe are not created until at least one handler
  //   is actually bound to the 'hashchange' event.
  // * If you need the bound handler(s) to execute immediately, in cases where
  //   a location.hash exists on page load, via bookmark or page refresh for
  //   example, use jQuery(window).hashchange() or the more verbose 
  //   jQuery(window).trigger( 'hashchange' ).
  // * The event can be bound before DOM ready, but since it won't be usable
  //   before then in IE6/7 (due to the necessary Iframe), recommended usage is
  //   to bind it inside a DOM ready handler.
  
  // Override existing $.event.special.hashchange methods (allowing this plugin
  // to be defined after jQuery BBQ in BBQ's source code).
  special[ str_hashchange ] = $.extend( special[ str_hashchange ], {
    
    // Called only when the first 'hashchange' event is bound to window.
    setup: function() {
      // If window.onhashchange is supported natively, there's nothing to do..
      if ( supports_onhashchange ) { return false; }
      
      // Otherwise, we need to create our own. And we don't want to call this
      // until the user binds to the event, just in case they never do, since it
      // will create a polling loop and possibly even a hidden Iframe.
      $( fake_onhashchange.start );
    },
    
    // Called only when the last 'hashchange' event is unbound from window.
    teardown: function() {
      // If window.onhashchange is supported natively, there's nothing to do..
      if ( supports_onhashchange ) { return false; }
      
      // Otherwise, we need to stop ours (if possible).
      $( fake_onhashchange.stop );
    }
    
  });
  
  // fake_onhashchange does all the work of triggering the window.onhashchange
  // event for browsers that don't natively support it, including creating a
  // polling loop to watch for hash changes and in IE 6/7 creating a hidden
  // Iframe to enable back and forward.
  fake_onhashchange = (function(){
    var self = {},
      timeout_id,
      
      // Remember the initial hash so it doesn't get triggered immediately.
      last_hash = get_fragment(),
      
      fn_retval = function(val){ return val; },
      history_set = fn_retval,
      history_get = fn_retval;
    
    // Start the polling loop.
    self.start = function() {
      timeout_id || poll();
    };
    
    // Stop the polling loop.
    self.stop = function() {
      timeout_id && clearTimeout( timeout_id );
      timeout_id = undefined;
    };
    
    // This polling loop checks every $.fn.hashchange.delay milliseconds to see
    // if location.hash has changed, and triggers the 'hashchange' event on
    // window when necessary.
    function poll() {
      var hash = get_fragment(),
        history_hash = history_get( last_hash );
      
      if ( hash !== last_hash ) {
        history_set( last_hash = hash, history_hash );
        
        $(window).trigger( str_hashchange );
        
      } else if ( history_hash !== last_hash ) {
        location.href = location.href.replace( /#.*/, '' ) + history_hash;
      }
      
      timeout_id = setTimeout( poll, $.fn[ str_hashchange ].delay );
    };
    
    // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    // vvvvvvvvvvvvvvvvvvv REMOVE IF NOT SUPPORTING IE6/7/8 vvvvvvvvvvvvvvvvvvv
    // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    $.browser.msie && !supports_onhashchange && (function(){
      // Not only do IE6/7 need the "magical" Iframe treatment, but so does IE8
      // when running in "IE7 compatibility" mode.
      
      var iframe,
        iframe_src;
      
      // When the event is bound and polling starts in IE 6/7, create a hidden
      // Iframe for history handling.
      self.start = function(){
        if ( !iframe ) {
          iframe_src = $.fn[ str_hashchange ].src;
          iframe_src = iframe_src && iframe_src + get_fragment();
          
          // Create hidden Iframe. Attempt to make Iframe as hidden as possible
          // by using techniques from http://www.paciellogroup.com/blog/?p=604.
          iframe = $('<iframe tabindex="-1" title="empty"/>').hide()
            
            // When Iframe has completely loaded, initialize the history and
            // start polling.
            .one( 'load', function(){
              iframe_src || history_set( get_fragment() );
              poll();
            })
            
            // Load Iframe src if specified, otherwise nothing.
            .attr( 'src', iframe_src || 'javascript:0' )
            
            // Append Iframe after the end of the body to prevent unnecessary
            // initial page scrolling (yes, this works).
            .insertAfter( 'body' )[0].contentWindow;
          
          // Whenever `document.title` changes, update the Iframe's title to
          // prettify the back/next history menu entries. Since IE sometimes
          // errors with "Unspecified error" the very first time this is set
          // (yes, very useful) wrap this with a try/catch block.
          doc.onpropertychange = function(){
            try {
              if ( event.propertyName === 'title' ) {
                iframe.document.title = doc.title;
              }
            } catch(e) {}
          };
          
        }
      };
      
      // Override the "stop" method since an IE6/7 Iframe was created. Even
      // if there are no longer any bound event handlers, the polling loop
      // is still necessary for back/next to work at all!
      self.stop = fn_retval;
      
      // Get history by looking at the hidden Iframe's location.hash.
      history_get = function() {
        return get_fragment( iframe.location.href );
      };
      
      // Set a new history item by opening and then closing the Iframe
      // document, *then* setting its location.hash. If document.domain has
      // been set, update that as well.
      history_set = function( hash, history_hash ) {
        var iframe_doc = iframe.document,
          domain = $.fn[ str_hashchange ].domain;
        
        if ( hash !== history_hash ) {
          // Update Iframe with any initial `document.title` that might be set.
          iframe_doc.title = doc.title;
          
          // Opening the Iframe's document after it has been closed is what
          // actually adds a history entry.
          iframe_doc.open();
          
          // Set document.domain for the Iframe document as well, if necessary.
          domain && iframe_doc.write( '<script>document.domain="' + domain + '"</script>' );
          
          iframe_doc.close();
          
          // Update the Iframe's hash, for great justice.
          iframe.location.hash = hash;
        }
      };
      
    })();
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    // ^^^^^^^^^^^^^^^^^^^ REMOVE IF NOT SUPPORTING IE6/7/8 ^^^^^^^^^^^^^^^^^^^
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    
    return self;
  })();
  
})(jQuery,this);

/*
 * jQuery Hotkeys Plugin
 * Copyright 2010, John Resig
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * Based upon the plugin by Tzury Bar Yochay:
 * http://github.com/tzuryby/hotkeys
 *
 * Original idea by:
 * Binny V A, http://www.openjs.com/scripts/events/keyboard_shortcuts/
 */

(function (jQuery) {
	
	jQuery.hotkeys = {
		version : "0.8",
		
		specialKeys : {
			8 : "backspace",
			9 : "tab",
			13 : "return",
			16 : "shift",
			17 : "ctrl",
			18 : "alt",
			19 : "pause",
			20 : "capslock",
			27 : "esc",
			32 : "space",
			33 : "pageup",
			34 : "pagedown",
			35 : "end",
			36 : "home",
			37 : "left",
			38 : "up",
			39 : "right",
			40 : "down",
			45 : "insert",
			46 : "del",
			96 : "0",
			97 : "1",
			98 : "2",
			99 : "3",
			100 : "4",
			101 : "5",
			102 : "6",
			103 : "7",
			104 : "8",
			105 : "9",
			106 : "*",
			107 : "+",
			109 : "-",
			110 : ".",
			111 : "/",
			112 : "f1",
			113 : "f2",
			114 : "f3",
			115 : "f4",
			116 : "f5",
			117 : "f6",
			118 : "f7",
			119 : "f8",
			120 : "f9",
			121 : "f10",
			122 : "f11",
			123 : "f12",
			144 : "numlock",
			145 : "scroll",
			191 : "/",
			224 : "meta"
		},
		
		shiftNums : {
			"`" : "~",
			"1" : "!",
			"2" : "@",
			"3" : "#",
			"4" : "$",
			"5" : "%",
			"6" : "^",
			"7" : "&",
			"8" : "*",
			"9" : "(",
			"0" : ")",
			"-" : "_",
			"=" : "+",
			";" : ": ",
			"'" : "\"",
			"," : "<",
			"." : ">",
			"/" : "?",
			"\\" : "|"
		}
	};
	
	function keyHandler(handleObj) {
		// Only care when a possible input has been specified
		if (typeof handleObj.data !== "string") {
			return;
		}
		
		var origHandler = handleObj.handler,
		keys = handleObj.data.toLowerCase().split(" ");
		
		handleObj.handler = function (event) {
			// Don't fire in text-accepting inputs that we didn't directly bind to
			if (this !== event.target && (/textarea|select/i.test(event.target.nodeName) ||
					event.target.type === "text")) {
				return;
			}
			
			// Keypress represents characters, not special keys
			var special = event.type !== "keypress" && jQuery.hotkeys.specialKeys[event.which],
			character = String.fromCharCode(event.which).toLowerCase(),
			key,
			modif = "",
			possible = {};
			
			// check combinations (alt|ctrl|shift+anything)
			if (event.altKey && special !== "alt") {
				modif += "alt+";
			}
			
			if (event.ctrlKey && special !== "ctrl") {
				modif += "ctrl+";
			}
			
			// TODO: Need to make sure this works consistently across platforms
			if (event.metaKey && !event.ctrlKey && special !== "meta") {
				modif += "meta+";
			}
			
			if (event.shiftKey && special !== "shift") {
				modif += "shift+";
			}
			
			if (special) {
				possible[modif + special] = true;
				
			} else {
				possible[modif + character] = true;
				possible[modif + jQuery.hotkeys.shiftNums[character]] = true;
				
				// "$" can be triggered as "Shift+4" or "Shift+$" or just "$"
				if (modif === "shift+") {
					possible[jQuery.hotkeys.shiftNums[character]] = true;
				}
			}
			
			for (var i = 0, l = keys.length; i < l; i++) {
				if (possible[keys[i]]) {
					return origHandler.apply(this, arguments);
				}
			}
		};
	}
	
	jQuery.each(["keydown", "keyup", "keypress"], function () {
		jQuery.event.special[this] = {
			add : keyHandler
		};
	});
	
})(jQuery);

/**
* hoverIntent is similar to jQuery's built-in "hover" function except that
* instead of firing the onMouseOver event immediately, hoverIntent checks
* to see if the user's mouse has slowed down (beneath the sensitivity
* threshold) before firing the onMouseOver event.
* 
* hoverIntent r6 // 2011.02.26 // jQuery 1.5.1+
* <http://cherne.net/brian/resources/jquery.hoverIntent.html>
* 
* hoverIntent is currently available for use in all personal or commercial 
* projects under both MIT and GPL licenses. This means that you can choose 
* the license that best suits your project, and use it accordingly.
* 
* // basic usage (just like .hover) receives onMouseOver and onMouseOut functions
* $("ul li").hoverIntent( showNav , hideNav );
* 
* // advanced usage receives configuration object only
* $("ul li").hoverIntent({
*	sensitivity: 7, // number = sensitivity threshold (must be 1 or higher)
*	interval: 100,   // number = milliseconds of polling interval
*	over: showNav,  // function = onMouseOver callback (required)
*	timeout: 0,   // number = milliseconds delay before onMouseOut function call
*	out: hideNav    // function = onMouseOut callback (required)
* });
* 
* @param  f  onMouseOver function || An object with configuration options
* @param  g  onMouseOut function  || Nothing (use configuration options object)
* @author    Brian Cherne brian(at)cherne(dot)net
*/
(function($) {
	$.fn.hoverIntent = function(f,g) {
		// default configuration options
		var cfg = {
			sensitivity: 7,
			interval: 225,
			timeout: 0
		};
		// override configuration options with user supplied object
		cfg = $.extend(cfg, g ? { over: f, out: g } : f );

		// instantiate variables
		// cX, cY = current X and Y position of mouse, updated by mousemove event
		// pX, pY = previous X and Y position of mouse, set by mouseover and polling interval
		var cX, cY, pX, pY;

		// A private function for getting mouse position
		var track = function(ev) {
			cX = ev.pageX;
			cY = ev.pageY;
		};

		// A private function for comparing current and previous mouse position
		var compare = function(ev,ob) {
			ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
			// compare mouse positions to see if they've crossed the threshold
			if ( ( Math.abs(pX-cX) + Math.abs(pY-cY) ) < cfg.sensitivity ) {
				$(ob).unbind("mousemove",track);
				// set hoverIntent state to true (so mouseOut can be called)
				ob.hoverIntent_s = 1;
				return cfg.over.apply(ob,[ev]);
			} else {
				// set previous coordinates for next time
				pX = cX; pY = cY;
				// use self-calling timeout, guarantees intervals are spaced out properly (avoids JavaScript timer bugs)
				ob.hoverIntent_t = setTimeout( function(){compare(ev, ob);} , cfg.interval );
			}
		};

		// A private function for delaying the mouseOut function
		var delay = function(ev,ob) {
			ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
			ob.hoverIntent_s = 0;
			return cfg.out.apply(ob,[ev]);
		};

		// A private function for handling mouse 'hovering'
		var handleHover = function(e) {
			// copy objects to be passed into t (required for event object to be passed in IE)
			var ev = jQuery.extend({},e);
			var ob = this;

			// cancel hoverIntent timer if it exists
			if (ob.hoverIntent_t) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); }

			// if e.type == "mouseenter"
			if (e.type == "mouseenter") {
				// set "previous" X and Y position based on initial entry point
				pX = ev.pageX; pY = ev.pageY;
				// update "current" X and Y position based on mousemove
				$(ob).bind("mousemove",track);
				// start polling interval (self-calling timeout) to compare mouse coordinates over time
				if (ob.hoverIntent_s != 1) { ob.hoverIntent_t = setTimeout( function(){compare(ev,ob);} , cfg.interval );}

			// else e.type == "mouseleave"
			} else {
				// unbind expensive mousemove event
				$(ob).unbind("mousemove",track);
				// if hoverIntent state is true, then call the mouseOut function after the specified delay
				if (ob.hoverIntent_s == 1) { ob.hoverIntent_t = setTimeout( function(){delay(ev,ob);} , cfg.timeout );}
			}
		};

		// bind the function to the two event listeners
		return this.bind('mouseenter',handleHover).bind('mouseleave',handleHover);
	};
})(jQuery);

/*
 *jQuery browser plugin detection 1.0.3
 * http://plugins.jquery.com/project/jqplugin
 * Checks for plugins / mimetypes supported in the browser extending the jQuery.browser object
 * Copyright (c) 2008 Leonardo Rossetti motw.leo@gmail.com
 * MIT License: http://www.opensource.org/licenses/mit-license.php
   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   THE SOFTWARE.
*/
(function ($) {

	//checks if browser object exists
	if (typeof $.browser === "undefined" || !$.browser) {
		var browser = {};
		$.extend(browser);
	}
	var pluginList = {
		flash: {
			activex: ["ShockwaveFlash.ShockwaveFlash", "ShockwaveFlash.ShockwaveFlash.3", "ShockwaveFlash.ShockwaveFlash.4", "ShockwaveFlash.ShockwaveFlash.5", "ShockwaveFlash.ShockwaveFlash.6", "ShockwaveFlash.ShockwaveFlash.7"],
			plugin: /flash/gim
		},
		sl: {
			activex: ["AgControl.AgControl"],
			plugin: /silverlight/gim
		},
		pdf: {
			activex: ["acroPDF.PDF.1", "PDF.PdfCtrl.1", "PDF.PdfCtrl.4", "PDF.PdfCtrl.5", "PDF.PdfCtrl.6"],
			plugin: /adobe\s?acrobat/gim
		},
		qtime: {
			activex: ["QuickTime.QuickTime", "QuickTimeCheckObject.QuickTimeCheck.1", "QuickTime.QuickTime.4"],
			plugin: /quicktime/gim
		},
		wmp: {
			activex: ["WMPlayer.OCX", "MediaPlayer.MediaPlayer.1"],
			plugin: /(windows\smedia)|(Microsoft)/gim
		},
		shk: {
			activex: ["SWCtl.SWCtl", "SWCt1.SWCt1.7", "SWCt1.SWCt1.8", "SWCt1.SWCt1.9", "ShockwaveFlash.ShockwaveFlash.1"],
			plugin: /shockwave/gim
		},
		rp: {
			activex: ["RealPlayer", "rmocx.RealPlayer G2 Control.1"],
			plugin: /realplayer/gim
		}
	};
	var isSupported = function (p) {
		if (window.ActiveXObject) {
			$.browser[p] = false;
			
			for (i = 0; i < pluginList[p].activex.length; i++) {
				try {
					new ActiveXObject(pluginList[p].activex[i]);
					$.browser[p] = true;
				} catch (e) {}	
			}
		} else {
			$.each(navigator.plugins, function () {
				if (this.name.match(pluginList[p].plugin)) {
					$.browser[p] = true;
					return false;
				} else {
					$.browser[p] = false;
				}
			});
		}
	};
	
	$.each(pluginList, function (i, n) {
		isSupported(i);
	});

})(jQuery);
/**
 * jQuery JSON Plugin
 * version: 2.3 (2011-09-17)
 *
 * This document is licensed as free software under the terms of the
 * MIT License: http://www.opensource.org/licenses/mit-license.php
 *
 * Brantley Harris wrote this plugin. It is based somewhat on the JSON.org
 * website's http://www.json.org/json2.js, which proclaims:
 * "NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.", a sentiment that
 * I uphold.
 *
 * It is also influenced heavily by MochiKit's serializeJSON, which is
 * copyrighted 2005 by Bob Ippolito.
 */

(function( $ ) {

	var	escapeable = /["\\\x00-\x1f\x7f-\x9f]/g,
		meta = {
			'\b': '\\b',
			'\t': '\\t',
			'\n': '\\n',
			'\f': '\\f',
			'\r': '\\r',
			'"' : '\\"',
			'\\': '\\\\'
		};

	/**
	 * jQuery.toJSON
	 * Converts the given argument into a JSON respresentation.
	 *
	 * @param o {Mixed} The json-serializble *thing* to be converted
	 *
	 * If an object has a toJSON prototype, that will be used to get the representation.
	 * Non-integer/string keys are skipped in the object, as are keys that point to a
	 * function.
	 *
	 */
	$.toJSON = typeof JSON === 'object' && JSON.stringify
		? JSON.stringify
		: function( o ) {

		if ( o === null ) {
			return 'null';
		}

		var type = typeof o;

		if ( type === 'undefined' ) {
			return undefined;
		}
		if ( type === 'number' || type === 'boolean' ) {
			return '' + o;
		}
		if ( type === 'string') {
			return $.quoteString( o );
		}
		if ( type === 'object' ) {
			if ( typeof o.toJSON === 'function' ) {
				return $.toJSON( o.toJSON() );
			}
			if ( o.constructor === Date ) {
				var	month = o.getUTCMonth() + 1,
					day = o.getUTCDate(),
					year = o.getUTCFullYear(),
					hours = o.getUTCHours(),
					minutes = o.getUTCMinutes(),
					seconds = o.getUTCSeconds(),
					milli = o.getUTCMilliseconds();

				if ( month < 10 ) {
					month = '0' + month;
				}
				if ( day < 10 ) {
					day = '0' + day;
				}
				if ( hours < 10 ) {
					hours = '0' + hours;
				}
				if ( minutes < 10 ) {
					minutes = '0' + minutes;
				}
				if ( seconds < 10 ) {
					seconds = '0' + seconds;
				}
				if ( milli < 100 ) {
					milli = '0' + milli;
				}
				if ( milli < 10 ) {
					milli = '0' + milli;
				}
				return '"' + year + '-' + month + '-' + day + 'T' +
					hours + ':' + minutes + ':' + seconds +
					'.' + milli + 'Z"';
			}
			if ( o.constructor === Array ) {
				var ret = [];
				for ( var i = 0; i < o.length; i++ ) {
					ret.push( $.toJSON( o[i] ) || 'null' );
				}
				return '[' + ret.join(',') + ']';
			}
			var	name,
				val,
				pairs = [];
			for ( var k in o ) {
				type = typeof k;
				if ( type === 'number' ) {
					name = '"' + k + '"';
				} else if (type === 'string') {
					name = $.quoteString(k);
				} else {
					// Keys must be numerical or string. Skip others
					continue;
				}
				type = typeof o[k];

				if ( type === 'function' || type === 'undefined' ) {
					// Invalid values like these return undefined
					// from toJSON, however those object members
					// shouldn't be included in the JSON string at all.
					continue;
				}
				val = $.toJSON( o[k] );
				pairs.push( name + ':' + val );
			}
			return '{' + pairs.join( ',' ) + '}';
		}
	};

	/**
	 * jQuery.evalJSON
	 * Evaluates a given piece of json source.
	 *
	 * @param src {String}
	 */
	$.evalJSON = typeof JSON === 'object' && JSON.parse
		? JSON.parse
		: function( src ) {
		return eval('(' + src + ')');
	};

	/**
	 * jQuery.secureEvalJSON
	 * Evals JSON in a way that is *more* secure.
	 *
	 * @param src {String}
	 */
	$.secureEvalJSON = typeof JSON === 'object' && JSON.parse
		? JSON.parse
		: function( src ) {

		var filtered = 
			src
			.replace( /\\["\\\/bfnrtu]/g, '@' )
			.replace( /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
			.replace( /(?:^|:|,)(?:\s*\[)+/g, '');

		if ( /^[\],:{}\s]*$/.test( filtered ) ) {
			return eval( '(' + src + ')' );
		} else {
			throw new SyntaxError( 'Error parsing JSON, source is not valid.' );
		}
	};

	/**
	 * jQuery.quoteString
	 * Returns a string-repr of a string, escaping quotes intelligently.
	 * Mostly a support function for toJSON.
	 * Examples:
	 * >>> jQuery.quoteString('apple')
	 * "apple"
	 *
	 * >>> jQuery.quoteString('"Where are we going?", she asked.')
	 * "\"Where are we going?\", she asked."
	 */
	$.quoteString = function( string ) {
		if ( string.match( escapeable ) ) {
			return '"' + string.replace( escapeable, function( a ) {
				var c = meta[a];
				if ( typeof c === 'string' ) {
					return c;
				}
				c = a.charCodeAt();
				return '\\u00' + Math.floor(c / 16).toString(16) + (c % 16).toString(16);
			}) + '"';
		}
		return '"' + string + '"';
	};

})( jQuery );

/*
 * Metadata - jQuery plugin for parsing metadata from elements
 *
 * Copyright (c) 2006 John Resig, Yehuda Katz, J�örn Zaefferer, Paul McLanahan
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 *
 * Revision: $Id: jquery.metadata.js 3640 2007-10-11 18:34:38Z pmclanahan $
 *
 */

/**
 * Sets the type of metadata to use. Metadata is encoded in JSON, and each property
 * in the JSON will become a property of the element itself.
 *
 * There are four supported types of metadata storage:
 *
 *   attr:  Inside an attribute. The name parameter indicates *which* attribute.
 *
 *   class: Inside the class attribute, wrapped in curly braces: { }
 *
 *   elem:  Inside a child element (e.g. a script tag). The
 *          name parameter indicates *which* element.
 *   html5: Values are stored in data-* attributes.
 *
 * The metadata for an element is loaded the first time the element is accessed via jQuery.
 *
 * As a result, you can define the metadata type, use $(expr) to load the metadata into the elements
 * matched by expr, then redefine the metadata type and run another $(expr) for other elements.
 *
 * @name $.metadata.setType
 *
 * @example <p id="one" class="some_class {item_id: 1, item_label: 'Label'}">This is a p</p>
 * @before $.metadata.setType("class")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from the class attribute
 *
 * @example <p id="one" class="some_class" data="{item_id: 1, item_label: 'Label'}">This is a p</p>
 * @before $.metadata.setType("attr", "data")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a "data" attribute
 *
 * @example <p id="one" class="some_class"><script>{item_id: 1, item_label: 'Label'}</script>This is a p</p>
 * @before $.metadata.setType("elem", "script")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a nested script element
 *
 * @example <p id="one" class="some_class" data-item_id="1" data-item_label="Label">This is a p</p>
 * @before $.metadata.setType("html5")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a series of data-* attributes
 *
 * @param String type The encoding type
 * @param String name The name of the attribute to be used to get metadata (optional)
 * @cat Plugins/Metadata
 * @descr Sets the type of encoding to be used when loading metadata for the first time
 * @type undefined
 * @see metadata()
 */

(function ($) {
	
	$.extend({
		metadata : {
			defaults : {
				type : 'class',
				name : 'metadata',
				cre : /({.*})/,
				single : 'metadata'
			},
			setType : function (type, name) {
				this.defaults.type = type;
				this.defaults.name = name;
			},
			get : function (elem, opts) {
				var settings = $.extend({}, this.defaults, opts);
				// check for empty string in single property
				if (!settings.single.length)
					settings.single = 'metadata';
				
				var data = $.data(elem, settings.single);
				// returned cached data if it already exists
				if (data)
					return data;
				
				data = "{}";
				
				var getData = function (data) {
					if (typeof data != "string")
						return data;
					
					if (data.indexOf('{') < 0) {
						data = eval("(" + data + ")");
					}
				}
				
				var getObject = function (data) {
					if (typeof data != "string")
						return data;
					
					data = eval("(" + data + ")");
					return data;
				}
				
				if (settings.type == "html5") {
					var object = {};
					$(elem.attributes).each(function () {
						var name = this.nodeName;
						if (name.match(/^data-/))
							name = name.replace(/^data-/, '');
						else
							return true;
						object[name] = getObject(this.nodeValue);
					});
				} else {
					if (settings.type == "class") {
						var m = settings.cre.exec(elem.className);
						if (m)
							data = m[1];
					} else if (settings.type == "elem") {
						if (!elem.getElementsByTagName)
							return;
						var e = elem.getElementsByTagName(settings.name);
						if (e.length)
							data = $.trim(e[0].innerHTML);
					} else if (elem.getAttribute != undefined) {
						var attr = elem.getAttribute(settings.name);
						if (attr)
							data = attr;
					}
					object = getObject(data.indexOf("{") < 0 ? "{" + data + "}" : data);
				}
				
				$.data(elem, settings.single, object);
				return object;
			}
		}
	});
	
	/**
	 * Returns the metadata object for the first member of the jQuery object.
	 *
	 * @name metadata
	 * @descr Returns element's metadata object
	 * @param Object opts An object contianing settings to override the defaults
	 * @type jQuery
	 * @cat Plugins/Metadata
	 */
	$.fn.metadata = function (opts) {
		return $.metadata.get(this[0], opts);
	};
	
})(jQuery);

/*
 * jQuery outside events - v1.1 - 3/16/2010
 * http://benalman.com/projects/jquery-outside-events-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */

// Script: jQuery outside events
//
// *Version: 1.1, Last updated: 3/16/2010*
// 
// Project Home - http://benalman.com/projects/jquery-outside-events-plugin/
// GitHub       - http://github.com/cowboy/jquery-outside-events/
// Source       - http://github.com/cowboy/jquery-outside-events/raw/master/jquery.ba-outside-events.js
// (Minified)   - http://github.com/cowboy/jquery-outside-events/raw/master/jquery.ba-outside-events.min.js (0.9kb)
// 
// About: License
// 
// Copyright (c) 2010 "Cowboy" Ben Alman,
// Dual licensed under the MIT and GPL licenses.
// http://benalman.com/about/license/
// 
// About: Examples
// 
// These working examples, complete with fully commented code, illustrate a few
// ways in which this plugin can be used.
// 
// clickoutside - http://benalman.com/code/projects/jquery-outside-events/examples/clickoutside/
// dblclickoutside - http://benalman.com/code/projects/jquery-outside-events/examples/dblclickoutside/
// mouseoveroutside - http://benalman.com/code/projects/jquery-outside-events/examples/mouseoveroutside/
// focusoutside - http://benalman.com/code/projects/jquery-outside-events/examples/focusoutside/
// 
// About: Support and Testing
// 
// Information about what version or versions of jQuery this plugin has been
// tested with, what browsers it has been tested in, and where the unit tests
// reside (so you can test it yourself).
// 
// jQuery Versions - 1.4.2
// Browsers Tested - Internet Explorer 6-8, Firefox 2-3.6, Safari 3-4, Chrome, Opera 9.6-10.1.
// Unit Tests      - http://benalman.com/code/projects/jquery-outside-events/unit/
// 
// About: Release History
// 
// 1.1 - (3/16/2010) Made "clickoutside" plugin more general, resulting in a
//       whole new plugin with more than a dozen default "outside" events and
//       a method that can be used to add new ones.
// 1.0 - (2/27/2010) Initial release
//
// Topic: Default "outside" events
// 
// Note that each "outside" event is powered by an "originating" event. Only
// when the originating event is triggered on an element outside the element
// to which that outside event is bound will the bound event be triggered.
// 
// Because each outside event is powered by a separate originating event,
// stopping propagation of that originating event will prevent its related
// outside event from triggering.
// 
//  OUTSIDE EVENT     - ORIGINATING EVENT
//  clickoutside      - click
//  dblclickoutside   - dblclick
//  focusoutside      - focusin
//  bluroutside       - focusout
//  mousemoveoutside  - mousemove
//  mousedownoutside  - mousedown
//  mouseupoutside    - mouseup
//  mouseoveroutside  - mouseover
//  mouseoutoutside   - mouseout
//  keydownoutside    - keydown
//  keypressoutside   - keypress
//  keyupoutside      - keyup
//  changeoutside     - change
//  selectoutside     - select
//  submitoutside     - submit

(function($,doc,outside){
  '$:nomunge'; // Used by YUI compressor.
  
  $.map(
    // All these events will get an "outside" event counterpart by default.
    'click dblclick mousemove mousedown mouseup mouseover mouseout change select submit keydown keypress keyup'.split(' '),
    function( event_name ) { jq_addOutsideEvent( event_name ); }
  );
  
  // The focus and blur events are really focusin and focusout when it comes
  // to delegation, so they are a special case.
  jq_addOutsideEvent( 'focusin',  'focus' + outside );
  jq_addOutsideEvent( 'focusout', 'blur' + outside );
  
  // Method: jQuery.addOutsideEvent
  // 
  // Register a new "outside" event to be with this method. Adding an outside
  // event that already exists will probably blow things up, so check the
  // <Default "outside" events> list before trying to add a new one.
  // 
  // Usage:
  // 
  // > jQuery.addOutsideEvent( event_name [, outside_event_name ] );
  // 
  // Arguments:
  // 
  //  event_name - (String) The name of the originating event that the new
  //    "outside" event will be powered by. This event can be a native or
  //    custom event, as long as it bubbles up the DOM tree.
  //  outside_event_name - (String) An optional name for the new "outside"
  //    event. If omitted, the outside event will be named whatever the
  //    value of `event_name` is plus the "outside" suffix.
  // 
  // Returns:
  // 
  //  Nothing.
  
  $.addOutsideEvent = jq_addOutsideEvent;
  
  function jq_addOutsideEvent( event_name, outside_event_name ) {
    
    // The "outside" event name.
    outside_event_name = outside_event_name || event_name + outside;
    
    // A jQuery object containing all elements to which the "outside" event is
    // bound.
    var elems = $(),
      
      // The "originating" event, namespaced for easy unbinding.
      event_namespaced = event_name + '.' + outside_event_name + '-special-event';
    
    // Event: outside events
    // 
    // An "outside" event is triggered on an element when its corresponding
    // "originating" event is triggered on an element outside the element in
    // question. See the <Default "outside" events> list for more information.
    // 
    // Usage:
    // 
    // > jQuery('selector').bind( 'clickoutside', function(event) {
    // >   var clicked_elem = $(event.target);
    // >   ...
    // > });
    // 
    // > jQuery('selector').bind( 'dblclickoutside', function(event) {
    // >   var double_clicked_elem = $(event.target);
    // >   ...
    // > });
    // 
    // > jQuery('selector').bind( 'mouseoveroutside', function(event) {
    // >   var moused_over_elem = $(event.target);
    // >   ...
    // > });
    // 
    // > jQuery('selector').bind( 'focusoutside', function(event) {
    // >   var focused_elem = $(event.target);
    // >   ...
    // > });
    // 
    // You get the idea, right?
    
    $.event.special[ outside_event_name ] = {
      
      // Called only when the first "outside" event callback is bound per
      // element.
      setup: function(){
        
        // Add this element to the list of elements to which this "outside"
        // event is bound.
        elems = elems.add( this );
        
        // If this is the first element getting the event bound, bind a handler
        // to document to catch all corresponding "originating" events.
        if ( elems.length === 1 ) {
          $(doc).bind( event_namespaced, handle_event );
        }
      },
      
      // Called only when the last "outside" event callback is unbound per
      // element.
      teardown: function(){
        
        // Remove this element from the list of elements to which this
        // "outside" event is bound.
        elems = elems.not( this );
        
        // If this is the last element removed, remove the "originating" event
        // handler on document that powers this "outside" event.
        if ( elems.length === 0 ) {
          $(doc).unbind( event_namespaced );
        }
      },
      
      // Called every time a "outside" event callback is bound to an element.
      add: function( handleObj ) {
        var old_handler = handleObj.handler;
        
        // This function is executed every time the event is triggered. This is
        // used to override the default event.target reference with one that is
        // more useful.
        handleObj.handler = function( event, elem ) {
          
          // Set the event object's .target property to the element that the
          // user interacted with, not the element that the "outside" event was
          // was triggered on.
          event.target = elem;
          
          // Execute the actual bound handler.
          old_handler.apply( this, arguments );
        };
      }
    };
    
    // When the "originating" event is triggered..
    function handle_event( event ) {
      
      // Iterate over all elements to which this "outside" event is bound.
      $(elems).each(function(){
        var elem = $(this);
        
        // If this element isn't the element on which the event was triggered,
        // and this element doesn't contain said element, then said element is
        // considered to be outside, and the "outside" event will be triggered!
        if ( this !== event.target && !elem.has(event.target).length ) {
          
          // Use triggerHandler instead of trigger so that the "outside" event
          // doesn't bubble. Pass in the "originating" event's .target so that
          // the "outside" event.target can be overridden with something more
          // meaningful.
          elem.triggerHandler( outside_event_name, [ event.target ] );
        }
      });
    };
    
  };
  
})(jQuery,document,"outside");

/**
 * Resize Events
 * @version 0.7
 * Changelog:
 *   * 0.5 Added API bind() function to make it easier to add listeners.
 *   * 0.6 Added support for window height changes
 *   * 0.7 Clean up outstanding bugs (duplicate event firing) and refactor.
 *
 * There is no standard event for when a user resizes the text in their browser.
 * There is also no consistency between browser implementations of the window resize event
 * (some trigger as the window is resized, some only trigger as the user drops the resize handle).
 * This extension polls to detect these changes, and reports them immediately as custom events
 * ('x-text-resize' and 'x-window-resize') that other code can listen for and react to accordingly.
 * Resize Events also send an 'x-initial-size' event on load.
 *
 * The custom events triggered are sent with emPixels, textHeight and windowWidth variables.
 * emPixels is a unit that estimates much space you have to work with but is resolution, text size
 * and zoom level independant. Use this value to base layout decisions on, and the layout will
 * always fit.
 *
 * This extension is based on the 'text resize' events work of Lawrence Carvalho <http://www.alistapart.com/articles/fontresizing/>.
 *
 * @author Lawrence Carvalho <carvalho@uk.yahoo-inc.com>
 * @author Andrew Ramsden <http://irama.org/>
 *
 * @see http://irama.org/web/dhtml/resize-events/
 * @license GNU GENERAL PUBLIC LICENSE (GPL) <http://www.gnu.org/licenses/gpl.html>
 * @requires jQuery (tested with 1.4.2) <http://jquery.com/>
 */
var ResizeEvents = {
	baseTextHeight      : null,
	currentTextHeight   : null,
	baseWindowWidth     : null,
	baseWindowHeight    : null,
	currentWindowWidth  : null,
	currentWindowHeight : null,
	initialised         : false,
	intervalReference   : null,
	textSizeTestElement : null,
	eventElement        : $(document),
	conf                : {
		textResizeEvent          : 'x-text-resize',
		windowResizeEvent        : 'x-window-resize',
		windowWidthResizeEvent   : 'x-window-width-resize',
		windowHeightResizeEvent  : 'x-window-height-resize',
		initialResizeEvent       : 'x-initial-sizes',
		pollFrequency            : 500,
		textSizeTestElId         : 'text-resize'
	}
};

 // start closure (protects variables from global scope)
(function($){


	/**
	 * A simple way to add a listener for resize events.
	 *
	 * @param String events A space delimited list of events that should trigger this handler.
	 * @param function handler The handler function to be called when an event occurs.
	 */
	ResizeEvents.bind = function (events, handler) {

		// on DOMReady
			$(function(){
				// initialise if it hasn't happened already
					if (ResizeEvents.initialised !== true) {
						ResizeEvents.initialise();
					}
			});

		ResizeEvents.eventElement.bind(
			events,
			handler
		);
	};

	/**
	 * Initialisation
	 */
	ResizeEvents.initialise = function () {

		if (ResizeEvents.initialised === true) {
			return; // already initialised
		}

		// create text resize control element, and push it offscreen
			ResizeEvents.textSizeTestElement = $(
				'<span id="'+ResizeEvents.conf.textSizeTestElId+'" style="position: absolute; left: -9999px; bottom: 0; '+
				'font-size: 100%; font-family: Courier New, mono; margin: 0; padding: 0;">&nbsp;</span>'
			).get(0);

		// append control element
			$('body').append(ResizeEvents.textSizeTestElement);

		// initialise variables
			windowWidthNow = $(window).width();
			windowHeightNow = $(window).height();
			textHeightNow = getTextHeight();
			ResizeEvents.baseTextHeight = textHeightNow;
			ResizeEvents.currentTextHeight = textHeightNow;
			ResizeEvents.baseWindowWidth = windowWidthNow;
			ResizeEvents.currentWindowWidth = windowWidthNow;
			ResizeEvents.baseWindowHeight = windowHeightNow;
			ResizeEvents.currentWindowHeight = windowHeightNow;

		// start polling
			if (ResizeEvents.intervalReference == null) {
				ResizeEventsPoll();
				ResizeEvents.intervalReference = window.setInterval('ResizeEventsPoll()', ResizeEvents.conf.pollFrequency);
			}

		// trigger onload
			ResizeEvents.eventElement.trigger(ResizeEvents.conf.initialResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);

		// flag initialisation complete
			ResizeEvents.initialised = true;


	};

	/**
	 * This function is called a number of times each second to check if text size
	 * or window size has changed
	 */
	ResizeEventsPoll = function () {

		// get current values
			windowWidthNow = $(window).width();
			windowHeightNow = $(window).height();
			textHeightNow = getTextHeight();
			emPixelNow = windowWidthNow/textHeightNow;
			widthChanged = false;

		// test for window width change
			if (ResizeEvents.currentWindowWidth != windowWidthNow) {
				// Send custom event
					ResizeEvents.eventElement.trigger(ResizeEvents.conf.windowWidthResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);
					ResizeEvents.eventElement.trigger(ResizeEvents.conf.windowResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);
				// update current height
					ResizeEvents.currentWindowWidth = windowWidthNow;
					widthChanged = true;
			}

		// test for window height change
			if (ResizeEvents.currentWindowHeight != windowHeightNow) {
				// Send custom event
					ResizeEvents.eventElement.trigger(ResizeEvents.conf.windowHeightResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);
					if (!widthChanged) { // don't send window-resize event twice
						ResizeEvents.eventElement.trigger(ResizeEvents.conf.windowResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);
					}
				// update current height
					ResizeEvents.currentWindowHeight = windowHeightNow;
			}


		// test for text size change
			if (ResizeEvents.currentTextHeight != textHeightNow) {
				// Send custom event (with new text size)
					ResizeEvents.eventElement.trigger(ResizeEvents.conf.textResizeEvent, [emPixelNow, textHeightNow, windowWidthNow, windowHeightNow]);
				// update current height
					ResizeEvents.currentTextHeight = textHeightNow;
			}
	};

	/**
	 * @return The current text height in pixels
	 */
	getTextHeight = function () {
		return ResizeEvents.textSizeTestElement.offsetHeight+'';
	};

})(jQuery); /* end closure */

/**
 * Storage plugin
 * Provides a simple interface for storing data such as user preferences.
 * Storage is useful for saving and retreiving data to/from the user's browser.
 * For newer browsers, localStorage is used.
 * If localStorage isn't supported, then cookies are used instead.
 * Retrievable data is limited to the same domain as this file.
 *
 * Usage:
 * This plugin extends jQuery by adding itself as a static method.
 * $.Storage - is the class name, which represents the user's data store, whether it's cookies or local storage.
 *             <code>if ($.Storage)</code> will tell you if the plugin is loaded.
 * $.Storage.set("name", "value") - Stores a named value in the data store.
 * $.Storage.set({"name1":"value1", "name2":"value2", etc}) - Stores multiple name/value pairs in the data store.
 * $.Storage.get("name") - Retrieves the value of the given name from the data store.
 * $.Storage.remove("name") - Permanently deletes the name/value pair from the data store.
 *
 * @author Dave Schindler
 */
(function ($) {
	// Private data
	var isLS = ('localStorage' in window) && window.localStorage !== null;
	
	// Private functions
	function wls(n, v) {
		var c;
		if (typeof n === "string" && typeof v !== "undefined") {
			localStorage[n] = v;
			return true;
		} else if (typeof n === "object" && typeof v === "undefined") {
			for (c in n) {
				if (n.hasOwnProperty(c)) {
					localStorage[c] = n[c];
				}
			}
			return true;
		}
		return false;
	}
	
	function wc(n, v) {
		var dt,
		e,
		c;
		dt = new Date();
		dt.setTime(dt.getTime() + 31536000000); //1 year
		e = "; expires=" + dt.toGMTString();
		if (typeof n === "string" && typeof v === "string") {
			document.cookie = n + "=" + escape(v) + e + "; path=/";
			return true;
		} else if (typeof n === "object" && typeof v === "undefined") {
			for (c in n) {
				if (n.hasOwnProperty(c)) {
					document.cookie = c + "=" + escape(n[c]) + e + "; path=/";
				}
			}
			return true;
		}
		return false;
	}
	
	function rls(n) {
		return localStorage[n];
	}
	
	function rc(n) {
		var nn,
		ca,
		i,
		c;
		nn = n + "=";
		ca = document.cookie.split(';');
		for (i = 0; i < ca.length; i++) {
			c = ca[i];
			while (c.charAt(0) === ' ') {
				c = c.substring(1, c.length);
			}
			if (c.indexOf(nn) === 0) {
				return unescape(c.substring(nn.length, c.length));
			}
		}
		return null;
	}
	
	function dls(n) {
		return delete localStorage[n];
	}
	
	function dc(n) {
		return wc(n, "", -1);
	}
	
	/**
	 * Public API
	 * $.Storage - Represents the user's data store, whether it's cookies or local storage.
	 * $.Storage.set("name", "value") - Stores a named value in the data store.
	 * $.Storage.set({"name1":"value1", "name2":"value2", etc}) - Stores multiple name/value pairs in the data store.
	 * $.Storage.get("name") - Retrieves the value of the given name from the data store.
	 * $.Storage.remove("name") - Permanently deletes the name/value pair from the data store.
	 */
	$.extend({
		Storage : {
			set : isLS ? wls : wc,
			get : isLS ? rls : rc,
			remove : isLS ? dls : dc
		}
	});
})(jQuery);

// jQuery SWFObject v1.1.1 MIT/GPL @jon_neal
// http://jquery.thewikies.com/swfobject
(function ($, flash, Plugin) {
    var OBJECT = 'object',
        ENCODE = true;

    function _compareArrayIntegers(a, b) {
        var x = (a[0] || 0) - (b[0] || 0);
        return x > 0 || (!x && a.length > 0 && _compareArrayIntegers(a.slice(1), b.slice(1)));
    }

    function _objectToArguments(obj) {
        if (typeof obj != OBJECT) {
            return obj;
        }
        var arr = [],
            str = '';
        for (var i in obj) {
            if (typeof obj[i] == OBJECT) {
                str = _objectToArguments(obj[i]);
            } else {
                str = [i, (ENCODE) ? encodeURI(obj[i]) : obj[i]].join('=');
            }
            arr.push(str);
        }
        return arr.join('&');
    }

    function _objectFromObject(obj) {
        var arr = [];
        for (var i in obj) {
            if (obj[i]) {
                arr.push([i, '="', obj[i], '"'].join(''));
            }
        }
        return arr.join(' ');
    }

    function _paramsFromObject(obj) {
        var arr = [];
        for (var i in obj) {
            arr.push(['<param name="', i, '" value="', _objectToArguments(obj[i]), '" />'].join(''));
        }
        return arr.join('');
    }
    try {
        var flashVersion = Plugin.description || (function () {
            return (
            new Plugin('ShockwaveFlash.ShockwaveFlash')).GetVariable('$version');
        }());
    } catch (e) {
        flashVersion = 'Unavailable';
    }
    var flashVersionMatchVersionNumbers = flashVersion.match(/\d+/g) || [0];
    $[flash] = {
        available: flashVersionMatchVersionNumbers[0] > 0,
        activeX: Plugin && !Plugin.name,
        version: {
            original: flashVersion,
            array: flashVersionMatchVersionNumbers,
            string: flashVersionMatchVersionNumbers.join('.'),
            major: parseInt(flashVersionMatchVersionNumbers[0], 10) || 0,
            minor: parseInt(flashVersionMatchVersionNumbers[1], 10) || 0,
            release: parseInt(flashVersionMatchVersionNumbers[2], 10) || 0
        },
        hasVersion: function (version) {
            var versionArray = (/string|number/.test(typeof version)) ? version.toString().split('.') : (/object/.test(typeof version)) ? [version.major, version.minor] : version || [0, 0];
            return _compareArrayIntegers(
            flashVersionMatchVersionNumbers, versionArray);
        },
        encodeParams: true,
        expressInstall: 'expressInstall.swf',
        expressInstallIsActive: false,
        create: function (obj) {
            var instance = this;
            if (!obj.swf || instance.expressInstallIsActive || (!instance.available && !obj.hasVersionFail)) {
                return false;
            }
            if (!instance.hasVersion(obj.hasVersion || 1)) {
                instance.expressInstallIsActive = true;
                if (typeof obj.hasVersionFail == 'function') {
                    if (!obj.hasVersionFail.apply(obj)) {
                        return false;
                    }
                }
                obj = {
                    swf: obj.expressInstall || instance.expressInstall,
                    height: 137,
                    width: 214,
                    flashvars: {
                        MMredirectURL: location.href,
                        MMplayerType: (instance.activeX) ? 'ActiveX' : 'PlugIn',
                        MMdoctitle: document.title.slice(0, 47) + ' - Flash Player Installation'
                    }
                };
            }
            attrs = {
                data: obj.swf,
                type: 'application/x-shockwave-flash',
                id: obj.id || 'flash_' + Math.floor(Math.random() * 999999999),
                width: obj.width || 320,
                height: obj.height || 180,
                style: obj.style || ''
            };
            ENCODE = typeof obj.useEncode !== 'undefined' ? obj.useEncode : instance.encodeParams;
            obj.movie = obj.swf;
            obj.wmode = obj.wmode || 'opaque';
            delete obj.fallback;
            delete obj.hasVersion;
            delete obj.hasVersionFail;
            delete obj.height;
            delete obj.id;
            delete obj.swf;
            delete obj.useEncode;
            delete obj.width;
            var flashContainer = document.createElement('div');
            flashContainer.innerHTML = ['<object ', _objectFromObject(attrs), '>', _paramsFromObject(obj), '</object>'].join('');
            return flashContainer.firstChild;
        }
    };
    $.fn[flash] = function (options) {
        var $this = this.find(OBJECT).andSelf().filter(OBJECT);
        if (/string|object/.test(typeof options)) {
            this.each(

            function () {
                var $this = $(this),
                    flashObject;
                options = (typeof options == OBJECT) ? options : {
                    swf: options
                };
                options.fallback = this;
                flashObject = $[flash].create(options);
                if (flashObject) {
                    $this.children().remove();
                    $this.html(flashObject);
                }
            });
        }
        if (typeof options == 'function') {
            $this.each(

            function () {
                var instance = this,
                    jsInteractionTimeoutMs = 'jsInteractionTimeoutMs';
                instance[jsInteractionTimeoutMs] = instance[jsInteractionTimeoutMs] || 0;
                if (instance[jsInteractionTimeoutMs] < 660) {
                    if (instance.clientWidth || instance.clientHeight) {
                        options.call(instance);
                    } else {
                        setTimeout(

                        function () {
                            $(instance)[flash](options);
                        }, instance[jsInteractionTimeoutMs] + 66);
                    }
                }
            });
        }
        return $this;
    };
}(jQuery, 'flash', navigator.plugins['Shockwave Flash'] || window.ActiveXObject));
/*
 * jQuery Templates Plugin 1.0.0pre
 * http://github.com/jquery/jquery-tmpl
 * Requires jQuery 1.4.2+
 *
 * Copyright Software Freedom Conservancy, Inc.
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 */
(function( jQuery, undefined ){
	var oldManip = jQuery.fn.domManip, tmplItmAtt = "_tmplitem", htmlExpr = /^[^<]*(<[\w\W]+>)[^>]*$|\{\{\! /,
		newTmplItems = {}, wrappedItems = {}, appendToTmplItems, topTmplItem = { key: 0, data: {} }, itemKey = 0, cloneIndex = 0, stack = [];

	function newTmplItem( options, parentItem, fn, data ) {
		// Returns a template item data structure for a new rendered instance of a template (a 'template item').
		// The content field is a hierarchical array of strings and nested items (to be
		// removed and replaced by nodes field of dom elements, once inserted in DOM).
		var newItem = {
			data: data || (data === 0 || data === false) ? data : (parentItem ? parentItem.data : {}),
			_wrap: parentItem ? parentItem._wrap : null,
			tmpl: null,
			parent: parentItem || null,
			nodes: [],
			calls: tiCalls,
			nest: tiNest,
			wrap: tiWrap,
			html: tiHtml,
			update: tiUpdate
		};
		if ( options ) {
			jQuery.extend( newItem, options, { nodes: [], parent: parentItem });
		}
		if ( fn ) {
			// Build the hierarchical content to be used during insertion into DOM
			newItem.tmpl = fn;
			newItem._ctnt = newItem._ctnt || newItem.tmpl( jQuery, newItem );
			newItem.key = ++itemKey;
			// Keep track of new template item, until it is stored as jQuery Data on DOM element
			(stack.length ? wrappedItems : newTmplItems)[itemKey] = newItem;
		}
		return newItem;
	}

	// Override appendTo etc., in order to provide support for targeting multiple elements. (This code would disappear if integrated in jquery core).
	jQuery.each({
		appendTo: "append",
		prependTo: "prepend",
		insertBefore: "before",
		insertAfter: "after",
		replaceAll: "replaceWith"
	}, function( name, original ) {
		jQuery.fn[ name ] = function( selector ) {
			var ret = [], insert = jQuery( selector ), elems, i, l, tmplItems,
				parent = this.length === 1 && this[0].parentNode;

			appendToTmplItems = newTmplItems || {};
			if ( parent && parent.nodeType === 11 && parent.childNodes.length === 1 && insert.length === 1 ) {
				insert[ original ]( this[0] );
				ret = this;
			} else {
				for ( i = 0, l = insert.length; i < l; i++ ) {
					cloneIndex = i;
					elems = (i > 0 ? this.clone(true) : this).get();
					jQuery( insert[i] )[ original ]( elems );
					ret = ret.concat( elems );
				}
				cloneIndex = 0;
				ret = this.pushStack( ret, name, insert.selector );
			}
			tmplItems = appendToTmplItems;
			appendToTmplItems = null;
			jQuery.tmpl.complete( tmplItems );
			return ret;
		};
	});

	jQuery.fn.extend({
		// Use first wrapped element as template markup.
		// Return wrapped set of template items, obtained by rendering template against data.
		tmpl: function( data, options, parentItem ) {
			return jQuery.tmpl( this[0], data, options, parentItem );
		},

		// Find which rendered template item the first wrapped DOM element belongs to
		tmplItem: function() {
			return jQuery.tmplItem( this[0] );
		},

		// Consider the first wrapped element as a template declaration, and get the compiled template or store it as a named template.
		template: function( name ) {
			return jQuery.template( name, this[0] );
		},

		domManip: function( args, table, callback, options ) {
			if ( args[0] && jQuery.isArray( args[0] )) {
				var dmArgs = jQuery.makeArray( arguments ), elems = args[0], elemsLength = elems.length, i = 0, tmplItem;
				while ( i < elemsLength && !(tmplItem = jQuery.data( elems[i++], "tmplItem" ))) {}
				if ( tmplItem && cloneIndex ) {
					dmArgs[2] = function( fragClone ) {
						// Handler called by oldManip when rendered template has been inserted into DOM.
						jQuery.tmpl.afterManip( this, fragClone, callback );
					};
				}
				oldManip.apply( this, dmArgs );
			} else {
				oldManip.apply( this, arguments );
			}
			cloneIndex = 0;
			if ( !appendToTmplItems ) {
				jQuery.tmpl.complete( newTmplItems );
			}
			return this;
		}
	});

	jQuery.extend({
		// Return wrapped set of template items, obtained by rendering template against data.
		tmpl: function( tmpl, data, options, parentItem ) {
			var ret, topLevel = !parentItem;
			if ( topLevel ) {
				// This is a top-level tmpl call (not from a nested template using {{tmpl}})
				parentItem = topTmplItem;
				tmpl = jQuery.template[tmpl] || jQuery.template( null, tmpl );
				wrappedItems = {}; // Any wrapped items will be rebuilt, since this is top level
			} else if ( !tmpl ) {
				// The template item is already associated with DOM - this is a refresh.
				// Re-evaluate rendered template for the parentItem
				tmpl = parentItem.tmpl;
				newTmplItems[parentItem.key] = parentItem;
				parentItem.nodes = [];
				if ( parentItem.wrapped ) {
					updateWrapped( parentItem, parentItem.wrapped );
				}
				// Rebuild, without creating a new template item
				return jQuery( build( parentItem, null, parentItem.tmpl( jQuery, parentItem ) ));
			}
			if ( !tmpl ) {
				return []; // Could throw...
			}
			if ( typeof data === "function" ) {
				data = data.call( parentItem || {} );
			}
			if ( options && options.wrapped ) {
				updateWrapped( options, options.wrapped );
			}
			ret = jQuery.isArray( data ) ?
				jQuery.map( data, function( dataItem ) {
					return dataItem ? newTmplItem( options, parentItem, tmpl, dataItem ) : null;
				}) :
				[ newTmplItem( options, parentItem, tmpl, data ) ];
			return topLevel ? jQuery( build( parentItem, null, ret ) ) : ret;
		},

		// Return rendered template item for an element.
		tmplItem: function( elem ) {
			var tmplItem;
			if ( elem instanceof jQuery ) {
				elem = elem[0];
			}
			while ( elem && elem.nodeType === 1 && !(tmplItem = jQuery.data( elem, "tmplItem" )) && (elem = elem.parentNode) ) {}
			return tmplItem || topTmplItem;
		},

		// Set:
		// Use $.template( name, tmpl ) to cache a named template,
		// where tmpl is a template string, a script element or a jQuery instance wrapping a script element, etc.
		// Use $( "selector" ).template( name ) to provide access by name to a script block template declaration.

		// Get:
		// Use $.template( name ) to access a cached template.
		// Also $( selectorToScriptBlock ).template(), or $.template( null, templateString )
		// will return the compiled template, without adding a name reference.
		// If templateString includes at least one HTML tag, $.template( templateString ) is equivalent
		// to $.template( null, templateString )
		template: function( name, tmpl ) {
			if (tmpl) {
				// Compile template and associate with name
				if ( typeof tmpl === "string" ) {
					// This is an HTML string being passed directly in.
					tmpl = buildTmplFn( tmpl );
				} else if ( tmpl instanceof jQuery ) {
					tmpl = tmpl[0] || {};
				}
				if ( tmpl.nodeType ) {
					// If this is a template block, use cached copy, or generate tmpl function and cache.
					tmpl = jQuery.data( tmpl, "tmpl" ) || jQuery.data( tmpl, "tmpl", buildTmplFn( tmpl.innerHTML ));
					// Issue: In IE, if the container element is not a script block, the innerHTML will remove quotes from attribute values whenever the value does not include white space.
					// This means that foo="${x}" will not work if the value of x includes white space: foo="${x}" -> foo=value of x.
					// To correct this, include space in tag: foo="${ x }" -> foo="value of x"
				}
				return typeof name === "string" ? (jQuery.template[name] = tmpl) : tmpl;
			}
			// Return named compiled template
			return name ? (typeof name !== "string" ? jQuery.template( null, name ):
				(jQuery.template[name] ||
					// If not in map, and not containing at least on HTML tag, treat as a selector.
					// (If integrated with core, use quickExpr.exec)
					jQuery.template( null, htmlExpr.test( name ) ? name : jQuery( name )))) : null;
		},

		encode: function( text ) {
			// Do HTML encoding replacing < > & and ' and " by corresponding entities.
			return ("" + text).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;");
		}
	});

	jQuery.extend( jQuery.tmpl, {
		tag: {
			"tmpl": {
				_default: { $2: "null" },
				open: "if($notnull_1){__=__.concat($item.nest($1,$2));}"
				// tmpl target parameter can be of type function, so use $1, not $1a (so not auto detection of functions)
				// This means that {{tmpl foo}} treats foo as a template (which IS a function).
				// Explicit parens can be used if foo is a function that returns a template: {{tmpl foo()}}.
			},
			"wrap": {
				_default: { $2: "null" },
				open: "$item.calls(__,$1,$2);__=[];",
				close: "call=$item.calls();__=call._.concat($item.wrap(call,__));"
			},
			"each": {
				_default: { $2: "$index, $value" },
				open: "if($notnull_1){$.each($1a,function($2){with(this){",
				close: "}});}"
			},
			"if": {
				open: "if(($notnull_1) && $1a){",
				close: "}"
			},
			"else": {
				_default: { $1: "true" },
				open: "}else if(($notnull_1) && $1a){"
			},
			"html": {
				// Unecoded expression evaluation.
				open: "if($notnull_1){__.push($1a);}"
			},
			"=": {
				// Encoded expression evaluation. Abbreviated form is ${}.
				_default: { $1: "$data" },
				open: "if($notnull_1){__.push($.encode($1a));}"
			},
			"!": {
				// Comment tag. Skipped by parser
				open: ""
			}
		},

		// This stub can be overridden, e.g. in jquery.tmplPlus for providing rendered events
		complete: function( items ) {
			newTmplItems = {};
		},

		// Call this from code which overrides domManip, or equivalent
		// Manage cloning/storing template items etc.
		afterManip: function afterManip( elem, fragClone, callback ) {
			// Provides cloned fragment ready for fixup prior to and after insertion into DOM
			var content = fragClone.nodeType === 11 ?
				jQuery.makeArray(fragClone.childNodes) :
				fragClone.nodeType === 1 ? [fragClone] : [];

			// Return fragment to original caller (e.g. append) for DOM insertion
			callback.call( elem, fragClone );

			// Fragment has been inserted:- Add inserted nodes to tmplItem data structure. Replace inserted element annotations by jQuery.data.
			storeTmplItems( content );
			cloneIndex++;
		}
	});

	//========================== Private helper functions, used by code above ==========================

	function build( tmplItem, nested, content ) {
		// Convert hierarchical content into flat string array
		// and finally return array of fragments ready for DOM insertion
		var frag, ret = content ? jQuery.map( content, function( item ) {
			return (typeof item === "string") ?
				// Insert template item annotations, to be converted to jQuery.data( "tmplItem" ) when elems are inserted into DOM.
				(tmplItem.key ? item.replace( /(<\w+)(?=[\s>])(?![^>]*_tmplitem)([^>]*)/g, "$1 " + tmplItmAtt + "=\"" + tmplItem.key + "\" $2" ) : item) :
				// This is a child template item. Build nested template.
				build( item, tmplItem, item._ctnt );
		}) :
		// If content is not defined, insert tmplItem directly. Not a template item. May be a string, or a string array, e.g. from {{html $item.html()}}.
		tmplItem;
		if ( nested ) {
			return ret;
		}

		// top-level template
		ret = ret.join("");

		// Support templates which have initial or final text nodes, or consist only of text
		// Also support HTML entities within the HTML markup.
		ret.replace( /^\s*([^<\s][^<]*)?(<[\w\W]+>)([^>]*[^>\s])?\s*$/, function( all, before, middle, after) {
			frag = jQuery( middle ).get();

			storeTmplItems( frag );
			if ( before ) {
				frag = unencode( before ).concat(frag);
			}
			if ( after ) {
				frag = frag.concat(unencode( after ));
			}
		});
		return frag ? frag : unencode( ret );
	}

	function unencode( text ) {
		// Use createElement, since createTextNode will not render HTML entities correctly
		var el = document.createElement( "div" );
		el.innerHTML = text;
		return jQuery.makeArray(el.childNodes);
	}

	// Generate a reusable function that will serve to render a template against data
	function buildTmplFn( markup ) {
		return new Function("jQuery","$item",
			// Use the variable __ to hold a string array while building the compiled template. (See https://github.com/jquery/jquery-tmpl/issues#issue/10).
			"var $=jQuery,call,__=[],$data=$item.data;" +

			// Introduce the data as local variables using with(){}
			"with($data){__.push('" +

			// Convert the template into pure JavaScript
			jQuery.trim(markup)
				.replace( /([\\'])/g, "\\$1" )
				.replace( /[\r\t\n]/g, " " )
				.replace( /\$\{([^\}]*)\}/g, "{{= $1}}" )
				.replace( /\{\{(\/?)(\w+|.)(?:\(((?:[^\}]|\}(?!\}))*?)?\))?(?:\s+(.*?)?)?(\(((?:[^\}]|\}(?!\}))*?)\))?\s*\}\}/g,
				function( all, slash, type, fnargs, target, parens, args ) {
					var tag = jQuery.tmpl.tag[ type ], def, expr, exprAutoFnDetect;
					if ( !tag ) {
						throw "Unknown template tag: " + type;
					}
					def = tag._default || [];
					if ( parens && !/\w$/.test(target)) {
						target += parens;
						parens = "";
					}
					if ( target ) {
						target = unescape( target );
						args = args ? ("," + unescape( args ) + ")") : (parens ? ")" : "");
						// Support for target being things like a.toLowerCase();
						// In that case don't call with template item as 'this' pointer. Just evaluate...
						expr = parens ? (target.indexOf(".") > -1 ? target + unescape( parens ) : ("(" + target + ").call($item" + args)) : target;
						exprAutoFnDetect = parens ? expr : "(typeof(" + target + ")==='function'?(" + target + ").call($item):(" + target + "))";
					} else {
						exprAutoFnDetect = expr = def.$1 || "null";
					}
					fnargs = unescape( fnargs );
					return "');" +
						tag[ slash ? "close" : "open" ]
							.split( "$notnull_1" ).join( target ? "typeof(" + target + ")!=='undefined' && (" + target + ")!=null" : "true" )
							.split( "$1a" ).join( exprAutoFnDetect )
							.split( "$1" ).join( expr )
							.split( "$2" ).join( fnargs || def.$2 || "" ) +
						"__.push('";
				}) +
			"');}return __;"
		);
	}
	function updateWrapped( options, wrapped ) {
		// Build the wrapped content.
		options._wrap = build( options, true,
			// Suport imperative scenario in which options.wrapped can be set to a selector or an HTML string.
			jQuery.isArray( wrapped ) ? wrapped : [htmlExpr.test( wrapped ) ? wrapped : jQuery( wrapped ).html()]
		).join("");
	}

	function unescape( args ) {
		return args ? args.replace( /\\'/g, "'").replace(/\\\\/g, "\\" ) : null;
	}
	function outerHtml( elem ) {
		var div = document.createElement("div");
		div.appendChild( elem.cloneNode(true) );
		return div.innerHTML;
	}

	// Store template items in jQuery.data(), ensuring a unique tmplItem data data structure for each rendered template instance.
	function storeTmplItems( content ) {
		var keySuffix = "_" + cloneIndex, elem, elems, newClonedItems = {}, i, l, m;
		for ( i = 0, l = content.length; i < l; i++ ) {
			if ( (elem = content[i]).nodeType !== 1 ) {
				continue;
			}
			elems = elem.getElementsByTagName("*");
			for ( m = elems.length - 1; m >= 0; m-- ) {
				processItemKey( elems[m] );
			}
			processItemKey( elem );
		}
		function processItemKey( el ) {
			var pntKey, pntNode = el, pntItem, tmplItem, key;
			// Ensure that each rendered template inserted into the DOM has its own template item,
			if ( (key = el.getAttribute( tmplItmAtt ))) {
				while ( pntNode.parentNode && (pntNode = pntNode.parentNode).nodeType === 1 && !(pntKey = pntNode.getAttribute( tmplItmAtt ))) { }
				if ( pntKey !== key ) {
					// The next ancestor with a _tmplitem expando is on a different key than this one.
					// So this is a top-level element within this template item
					// Set pntNode to the key of the parentNode, or to 0 if pntNode.parentNode is null, or pntNode is a fragment.
					pntNode = pntNode.parentNode ? (pntNode.nodeType === 11 ? 0 : (pntNode.getAttribute( tmplItmAtt ) || 0)) : 0;
					if ( !(tmplItem = newTmplItems[key]) ) {
						// The item is for wrapped content, and was copied from the temporary parent wrappedItem.
						tmplItem = wrappedItems[key];
						tmplItem = newTmplItem( tmplItem, newTmplItems[pntNode]||wrappedItems[pntNode] );
						tmplItem.key = ++itemKey;
						newTmplItems[itemKey] = tmplItem;
					}
					if ( cloneIndex ) {
						cloneTmplItem( key );
					}
				}
				el.removeAttribute( tmplItmAtt );
			} else if ( cloneIndex && (tmplItem = jQuery.data( el, "tmplItem" )) ) {
				// This was a rendered element, cloned during append or appendTo etc.
				// TmplItem stored in jQuery data has already been cloned in cloneCopyEvent. We must replace it with a fresh cloned tmplItem.
				cloneTmplItem( tmplItem.key );
				newTmplItems[tmplItem.key] = tmplItem;
				pntNode = jQuery.data( el.parentNode, "tmplItem" );
				pntNode = pntNode ? pntNode.key : 0;
			}
			if ( tmplItem ) {
				pntItem = tmplItem;
				// Find the template item of the parent element.
				// (Using !=, not !==, since pntItem.key is number, and pntNode may be a string)
				while ( pntItem && pntItem.key != pntNode ) {
					// Add this element as a top-level node for this rendered template item, as well as for any
					// ancestor items between this item and the item of its parent element
					pntItem.nodes.push( el );
					pntItem = pntItem.parent;
				}
				// Delete content built during rendering - reduce API surface area and memory use, and avoid exposing of stale data after rendering...
				delete tmplItem._ctnt;
				delete tmplItem._wrap;
				// Store template item as jQuery data on the element
				jQuery.data( el, "tmplItem", tmplItem );
			}
			function cloneTmplItem( key ) {
				key = key + keySuffix;
				tmplItem = newClonedItems[key] =
					(newClonedItems[key] || newTmplItem( tmplItem, newTmplItems[tmplItem.parent.key + keySuffix] || tmplItem.parent ));
			}
		}
	}

	//---- Helper functions for template item ----

	function tiCalls( content, tmpl, data, options ) {
		if ( !content ) {
			return stack.pop();
		}
		stack.push({ _: content, tmpl: tmpl, item:this, data: data, options: options });
	}

	function tiNest( tmpl, data, options ) {
		// nested template, using {{tmpl}} tag
		return jQuery.tmpl( jQuery.template( tmpl ), data, options, this );
	}

	function tiWrap( call, wrapped ) {
		// nested template, using {{wrap}} tag
		var options = call.options || {};
		options.wrapped = wrapped;
		// Apply the template, which may incorporate wrapped content,
		return jQuery.tmpl( jQuery.template( call.tmpl ), call.data, options, call.item );
	}

	function tiHtml( filter, textOnly ) {
		var wrapped = this._wrap;
		return jQuery.map(
			jQuery( jQuery.isArray( wrapped ) ? wrapped.join("") : wrapped ).filter( filter || "*" ),
			function(e) {
				return textOnly ?
					e.innerText || e.textContent :
					e.outerHTML || outerHtml(e);
			});
	}

	function tiUpdate() {
		var coll = this.nodes;
		jQuery.tmpl( null, null, null, this).insertBefore( coll[0] );
		jQuery( coll ).remove();
	}
})( jQuery );

﻿/**
* Dual licensed under the MIT or GPL Version 2 licenses.
* http://jquery.org/license
*
* http://docs.jquery.com/UI
*/
(function ($) {
    // selectors
    function focusable(element, isTabIndexNotNaN) {
        var nodeName = element.nodeName.toLowerCase();
        if ("area" === nodeName) {
            var map = element.parentNode,
                mapName = map.name,
                img;
            if (!element.href || !mapName || map.nodeName.toLowerCase() !== "map") {
                return false;
            }
            img = $("img[usemap=#" + mapName + "]")[0];
            return !!img && visible(img);
        }
        return (/input|select|textarea|button|object/.test(nodeName) ? !element.disabled : "a" == nodeName ? element.href || isTabIndexNotNaN : isTabIndexNotNaN)
        // the element and all of its ancestors must be visible
        &&
        visible(element);
    }

    function visible(element) {
        return !$(element).parents().andSelf().filter(function () {
            return $.css(this, "visibility") === "hidden" || $.expr.filters.hidden(this);
        }).length;
    }
    $.extend($.expr[":"], {
        data: function (elem, i, match) {
            return !!$.data(elem, match[3]);
        },
        focusable: function (element) {
            return focusable(element, !isNaN($.attr(element, "tabindex")));
        },
        tabbable: function (element) {
            var tabIndex = $.attr(element, "tabindex"),
                isTabIndexNaN = isNaN(tabIndex);
            return (isTabIndexNaN || tabIndex >= 0) && focusable(element, !isTabIndexNaN);
        }
    });
})(jQuery)
